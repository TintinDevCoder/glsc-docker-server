-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: glsc-oms
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `glsc-oms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-oms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-oms`;

--
-- Table structure for table `oms_order`
--

DROP TABLE IF EXISTS `oms_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `order_sn` char(32) DEFAULT NULL COMMENT '订单号',
  `coupon_id` bigint DEFAULT NULL COMMENT '使用的优惠券',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  `member_username` varchar(200) DEFAULT NULL COMMENT '用户名',
  `total_amount` decimal(18,4) DEFAULT NULL COMMENT '订单总额',
  `pay_amount` decimal(18,4) DEFAULT NULL COMMENT '应付总额',
  `freight_amount` decimal(18,4) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(18,4) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(18,4) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(18,4) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(18,4) DEFAULT NULL COMMENT '后台调整订单使用的折扣金额',
  `pay_type` tinyint DEFAULT NULL COMMENT '支付方式【1->支付宝；2->微信；3->银联； 4->货到付款；】',
  `source_type` tinyint DEFAULT NULL COMMENT '订单来源[0->PC订单；1->app订单]',
  `status` tinyint DEFAULT NULL COMMENT '订单状态【0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单】',
  `delivery_company` varchar(64) DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int DEFAULT NULL COMMENT '可以获得的成长值',
  `bill_type` tinyint DEFAULT NULL COMMENT '发票类型[0->不开发票；1->电子发票；2->纸质发票]',
  `bill_header` varchar(255) DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(255) DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) DEFAULT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) DEFAULT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) DEFAULT NULL COMMENT '订单备注',
  `confirm_status` tinyint DEFAULT NULL COMMENT '确认收货状态[0->未确认；1->已确认]',
  `delete_status` tinyint DEFAULT NULL COMMENT '删除状态【0->未删除；1->已删除】',
  `use_integration` int DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order`
--

LOCK TABLES `oms_order` WRITE;
/*!40000 ALTER TABLE `oms_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_order_item`
--

DROP TABLE IF EXISTS `oms_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint DEFAULT NULL COMMENT 'order_id',
  `order_sn` char(32) DEFAULT NULL COMMENT 'order_sn',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT 'spu_name',
  `spu_pic` varchar(500) DEFAULT NULL COMMENT 'spu_pic',
  `spu_brand` varchar(200) DEFAULT NULL COMMENT '品牌',
  `category_id` bigint DEFAULT NULL COMMENT '商品分类id',
  `sku_id` bigint DEFAULT NULL COMMENT '商品sku编号',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '商品sku名字',
  `sku_pic` varchar(500) DEFAULT NULL COMMENT '商品sku图片',
  `sku_price` decimal(18,4) DEFAULT NULL COMMENT '商品sku价格',
  `sku_quantity` int DEFAULT NULL COMMENT '商品购买的数量',
  `sku_attrs_vals` varchar(500) DEFAULT NULL COMMENT '商品销售属性组合（JSON）',
  `promotion_amount` decimal(18,4) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(18,4) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(18,4) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(18,4) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int DEFAULT NULL COMMENT '赠送积分',
  `gift_growth` int DEFAULT NULL COMMENT '赠送成长值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单项信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order_item`
--

LOCK TABLES `oms_order_item` WRITE;
/*!40000 ALTER TABLE `oms_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_order_operate_history`
--

DROP TABLE IF EXISTS `oms_order_operate_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order_operate_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `operate_man` varchar(100) DEFAULT NULL COMMENT '操作人[用户；系统；后台管理员]',
  `create_time` datetime DEFAULT NULL COMMENT '操作时间',
  `order_status` tinyint DEFAULT NULL COMMENT '订单状态【0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单】',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单操作历史记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order_operate_history`
--

LOCK TABLES `oms_order_operate_history` WRITE;
/*!40000 ALTER TABLE `oms_order_operate_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order_operate_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_order_return_apply`
--

DROP TABLE IF EXISTS `oms_order_return_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order_return_apply` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint DEFAULT NULL COMMENT 'order_id',
  `sku_id` bigint DEFAULT NULL COMMENT '退货商品id',
  `order_sn` char(32) DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '申请时间',
  `member_username` varchar(64) DEFAULT NULL COMMENT '会员用户名',
  `return_amount` decimal(18,4) DEFAULT NULL COMMENT '退款金额',
  `return_name` varchar(100) DEFAULT NULL COMMENT '退货人姓名',
  `return_phone` varchar(20) DEFAULT NULL COMMENT '退货人电话',
  `status` tinyint(1) DEFAULT NULL COMMENT '申请状态[0->待处理；1->退货中；2->已完成；3->已拒绝]',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  `sku_img` varchar(500) DEFAULT NULL COMMENT '商品图片',
  `sku_name` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `sku_brand` varchar(200) DEFAULT NULL COMMENT '商品品牌',
  `sku_attrs_vals` varchar(500) DEFAULT NULL COMMENT '商品销售属性(JSON)',
  `sku_count` int DEFAULT NULL COMMENT '退货数量',
  `sku_price` decimal(18,4) DEFAULT NULL COMMENT '商品单价',
  `sku_real_price` decimal(18,4) DEFAULT NULL COMMENT '商品实际支付单价',
  `reason` varchar(200) DEFAULT NULL COMMENT '原因',
  `description述` varchar(500) DEFAULT NULL COMMENT '描述',
  `desc_pics` varchar(2000) DEFAULT NULL COMMENT '凭证图片，以逗号隔开',
  `handle_note` varchar(500) DEFAULT NULL COMMENT '处理备注',
  `handle_man` varchar(200) DEFAULT NULL COMMENT '处理人员',
  `receive_man` varchar(100) DEFAULT NULL COMMENT '收货人',
  `receive_time` datetime DEFAULT NULL COMMENT '收货时间',
  `receive_note` varchar(500) DEFAULT NULL COMMENT '收货备注',
  `receive_phone` varchar(20) DEFAULT NULL COMMENT '收货电话',
  `company_address` varchar(500) DEFAULT NULL COMMENT '公司收货地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单退货申请';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order_return_apply`
--

LOCK TABLES `oms_order_return_apply` WRITE;
/*!40000 ALTER TABLE `oms_order_return_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order_return_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_order_return_reason`
--

DROP TABLE IF EXISTS `oms_order_return_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order_return_reason` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '退货原因名',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '启用状态',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='退货原因';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order_return_reason`
--

LOCK TABLES `oms_order_return_reason` WRITE;
/*!40000 ALTER TABLE `oms_order_return_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order_return_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_order_setting`
--

DROP TABLE IF EXISTS `oms_order_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_order_setting` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `flash_order_overtime` int DEFAULT NULL COMMENT '秒杀订单超时关闭时间(分)',
  `normal_order_overtime` int DEFAULT NULL COMMENT '正常订单超时时间(分)',
  `confirm_overtime` int DEFAULT NULL COMMENT '发货后自动确认收货时间（天）',
  `finish_overtime` int DEFAULT NULL COMMENT '自动完成交易时间，不能申请退货（天）',
  `comment_overtime` int DEFAULT NULL COMMENT '订单完成后自动好评时间（天）',
  `member_level` tinyint DEFAULT NULL COMMENT '会员等级【0-不限会员等级，全部通用；其他-对应的其他会员等级】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单配置信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_order_setting`
--

LOCK TABLES `oms_order_setting` WRITE;
/*!40000 ALTER TABLE `oms_order_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_order_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_payment_info`
--

DROP TABLE IF EXISTS `oms_payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_payment_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_sn` char(32) DEFAULT NULL COMMENT '订单号（对外业务号）',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `alipay_trade_no` varchar(50) DEFAULT NULL COMMENT '支付宝交易流水号',
  `total_amount` decimal(18,4) DEFAULT NULL COMMENT '支付总金额',
  `subject` varchar(200) DEFAULT NULL COMMENT '交易内容',
  `payment_status` varchar(20) DEFAULT NULL COMMENT '支付状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `confirm_time` datetime DEFAULT NULL COMMENT '确认时间',
  `callback_content` varchar(4000) DEFAULT NULL COMMENT '回调内容',
  `callback_time` datetime DEFAULT NULL COMMENT '回调时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_payment_info`
--

LOCK TABLES `oms_payment_info` WRITE;
/*!40000 ALTER TABLE `oms_payment_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_payment_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oms_refund_info`
--

DROP TABLE IF EXISTS `oms_refund_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oms_refund_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_return_id` bigint DEFAULT NULL COMMENT '退款的订单',
  `refund` decimal(18,4) DEFAULT NULL COMMENT '退款金额',
  `refund_sn` varchar(64) DEFAULT NULL COMMENT '退款交易流水号',
  `refund_status` tinyint(1) DEFAULT NULL COMMENT '退款状态',
  `refund_channel` tinyint DEFAULT NULL COMMENT '退款渠道[1-支付宝，2-微信，3-银联，4-汇款]',
  `refund_content` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='退款信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oms_refund_info`
--

LOCK TABLES `oms_refund_info` WRITE;
/*!40000 ALTER TABLE `oms_refund_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `oms_refund_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc-pms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-pms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-pms`;

--
-- Table structure for table `pms_attr`
--

DROP TABLE IF EXISTS `pms_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_attr` (
  `attr_id` bigint NOT NULL AUTO_INCREMENT COMMENT '属性id',
  `attr_name` char(30) DEFAULT NULL COMMENT '属性名',
  `search_type` tinyint DEFAULT NULL COMMENT '是否需要检索[0-不需要，1-需要]',
  `value_type` tinyint DEFAULT NULL COMMENT '值类型[0-为单个值，1-可以选择多个值]',
  `icon` varchar(255) DEFAULT NULL COMMENT '属性图标',
  `value_select` char(255) DEFAULT NULL COMMENT '可选值列表[用逗号分隔]',
  `attr_type` tinyint DEFAULT NULL COMMENT '属性类型[0-销售属性，1-基本属性，2-既是销售属性又是基本属性]',
  `enable` tinyint DEFAULT NULL COMMENT '启用状态[0 - 禁用，1 - 启用]',
  `catelog_id` bigint DEFAULT NULL COMMENT '所属分类',
  `show_desc` tinyint DEFAULT NULL COMMENT '快速展示【是否展示在介绍上；0-否 1-是】，在sku中仍然可以调整',
  PRIMARY KEY (`attr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_attr`
--

LOCK TABLES `pms_attr` WRITE;
/*!40000 ALTER TABLE `pms_attr` DISABLE KEYS */;
INSERT INTO `pms_attr` VALUES (1,'test',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-23_vT8xHrnnmRJiI4mV.png','t1;t2;t3',1,1,165,1),(3,'test2',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-23_vT8xHrnnmRJiI4mV.png','r',1,1,166,0),(4,'rsfqe',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-25_kP9aSHLcw86bU7i4.jpg','q;w',1,0,225,0),(5,'test3',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-26_KtdLlNI6BXSz6vtf.jpg','q',1,0,225,0),(6,'销售属性2',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-26_K980UpEOnPNh8qUv.png','1;2;3',0,1,166,0),(7,'主题',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_voq1zstXksqDMNyg.png','t1;t2',1,1,166,0),(8,'test2',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_wlbDoMpl6CBEX84k.png','',1,1,166,0),(9,'xinzeng1',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_39wzjTInQxWyIRVL.png','',1,1,165,0),(10,'xinzeng2',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_P4WBj7c202H00OSD.png','',1,1,165,0),(11,'t2',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_gcasl1wzjFl4ktHs.png','t1',1,1,165,0),(12,'入网型号',1,0,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_nuZe2LhpMmJWVmxa.avif','A2217;C3J',1,1,225,1),(13,'上市年份',1,0,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_BOlVbFM4IpKtTwbI.avif','2022;2023;2024;2025',1,1,225,1),(14,'机身颜色',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_6x5vQJulhNYaTO2D.avif','红色;白色;黑色',1,1,225,1),(15,'机身材料',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_WPGz1PN4PU7jv0s2.avif','塑料;不锈钢;以官网信息为准',1,1,225,1),(16,'机身材质工艺',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_QJ9mj5KUTwPwOlFC.avif','以官网信息为准',1,1,225,1),(17,'机身长度（mm）',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_FEQMs4vlgLfX4xtq.avif','158.3;135.9;以官网信息为准',1,1,225,1),(18,'芯片工艺',1,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_48FKSOpkRHkYbFQy.avif','以官网信息为准',1,1,225,1),(19,'颜色',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_G4sA2r2Ks47PkOQv.avif','黑色;白色;蓝色',0,1,225,0),(20,'内存',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_BsmU2BQTxESFMSIb.avif','4GB;6GB;8GB;12GB',0,1,225,0),(21,'版本',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_DvhWgojls9dKuEps.avif','',0,1,225,0),(22,'存储空间',0,1,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_Op3MnDaFAsVn5lII.avif','64GB;128GB;256GB;512GB',0,0,225,0);
/*!40000 ALTER TABLE `pms_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_attr_attrgroup_relation`
--

DROP TABLE IF EXISTS `pms_attr_attrgroup_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_attr_attrgroup_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `attr_id` bigint DEFAULT NULL COMMENT '属性id',
  `attr_group_id` bigint DEFAULT NULL COMMENT '属性分组id',
  `attr_sort` int DEFAULT NULL COMMENT '属性组内排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='属性&属性分组关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_attr_attrgroup_relation`
--

LOCK TABLES `pms_attr_attrgroup_relation` WRITE;
/*!40000 ALTER TABLE `pms_attr_attrgroup_relation` DISABLE KEYS */;
INSERT INTO `pms_attr_attrgroup_relation` VALUES (1,1,3,NULL),(11,3,2,NULL),(12,7,2,NULL),(13,8,2,NULL),(18,12,7,NULL),(19,13,7,NULL),(20,14,8,NULL),(21,15,8,NULL),(22,16,8,NULL),(23,17,8,NULL),(24,18,9,NULL);
/*!40000 ALTER TABLE `pms_attr_attrgroup_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_attr_group`
--

DROP TABLE IF EXISTS `pms_attr_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_attr_group` (
  `attr_group_id` bigint NOT NULL AUTO_INCREMENT COMMENT '分组id',
  `attr_group_name` char(20) DEFAULT NULL COMMENT '组名',
  `sort` int DEFAULT NULL COMMENT '排序',
  `descript` varchar(255) DEFAULT NULL COMMENT '描述',
  `icon` varchar(255) DEFAULT NULL COMMENT '组图标',
  `catelog_id` bigint DEFAULT NULL COMMENT '所属分类id',
  PRIMARY KEY (`attr_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='属性分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_attr_group`
--

LOCK TABLES `pms_attr_group` WRITE;
/*!40000 ALTER TABLE `pms_attr_group` DISABLE KEYS */;
INSERT INTO `pms_attr_group` VALUES (1,'主体',0,'1','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_jgL80Dwml06s2OeW.png',228),(2,'描述',1,'2','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_3S186BnLF66NomGU.png',166),(3,'test',3,'t','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_tfzasc1NNzNbbgYS.png',165),(4,'test',1,'1','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-24_QjWtsX8XElUHynOG.png',220),(7,'主体',1,'主体','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_p3uWYT4bwbcMBuDL.avif',225),(8,'基本信息',2,'基本信息','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_93p0VRViLUzPbBMC.avif',225),(9,'主芯片',3,'主芯片','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_gIAh7LDePiuco126.avif',225);
/*!40000 ALTER TABLE `pms_attr_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_brand`
--

DROP TABLE IF EXISTS `pms_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_brand` (
  `brand_id` bigint NOT NULL AUTO_INCREMENT COMMENT '品牌id',
  `name` char(50) DEFAULT NULL COMMENT '品牌名',
  `logo` varchar(2000) DEFAULT NULL COMMENT '品牌logo地址',
  `descript` longtext COMMENT '介绍',
  `show_status` tinyint DEFAULT NULL COMMENT '显示状态[0-不显示；1-显示]',
  `first_letter` char(1) DEFAULT NULL COMMENT '检索首字母',
  `sort` int DEFAULT NULL COMMENT '排序',
  `is_delete` int NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='品牌';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_brand`
--

LOCK TABLES `pms_brand` WRITE;
/*!40000 ALTER TABLE `pms_brand` DISABLE KEYS */;
INSERT INTO `pms_brand` VALUES (1,'xiaomi','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_3JQ4z7Q3dlhpXwbc.png','test',1,'q',1,0),(2,'华为','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-30_Q1jTbNvwIXnxyE6e.png','华为手机',1,'H',2,0),(10,'1','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_KrxqwXVv4bK5Hulm.png','1',0,'q',0,0),(11,'rr','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-23_vT8xHrnnmRJiI4mV.png','2',0,'r',3,0),(12,'小米','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2026-01-06_guvkXmdthhSHOmlB.png','小米',1,'x',2,0);
/*!40000 ALTER TABLE `pms_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_category`
--

DROP TABLE IF EXISTS `pms_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_category` (
  `cat_id` bigint NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `name` char(50) DEFAULT NULL COMMENT '分类名称',
  `parent_cid` bigint DEFAULT NULL COMMENT '父分类id',
  `cat_level` int DEFAULT NULL COMMENT '层级',
  `show_status` tinyint DEFAULT NULL COMMENT '是否显示[0-不显示，1显示]',
  `sort` int DEFAULT NULL COMMENT '排序',
  `icon` char(255) DEFAULT NULL COMMENT '图标地址',
  `product_unit` char(50) DEFAULT NULL COMMENT '计量单位',
  `product_count` int DEFAULT NULL COMMENT '商品数量',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100012 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品三级分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_category`
--

LOCK TABLES `pms_category` WRITE;
/*!40000 ALTER TABLE `pms_category` DISABLE KEYS */;
INSERT INTO `pms_category` VALUES (1,'图书、音像、电子书刊',0,1,1,0,NULL,NULL,0),(2,'手机',0,1,1,1,NULL,NULL,0),(3,'家用电器',0,1,1,3,NULL,NULL,0),(4,'数码',0,1,1,4,NULL,NULL,0),(5,'家居家装',0,1,1,5,NULL,NULL,0),(6,'电脑办公',0,1,1,6,NULL,NULL,0),(7,'厨具',0,1,1,7,NULL,NULL,0),(8,'个护化妆',0,1,1,8,NULL,NULL,0),(9,'服饰内衣',0,1,1,9,NULL,NULL,0),(10,'钟表',0,1,1,10,NULL,NULL,0),(11,'鞋靴',0,1,1,11,NULL,NULL,0),(12,'母婴',0,1,1,12,NULL,NULL,0),(13,'礼品箱包',0,1,1,13,NULL,NULL,0),(14,'食品饮料、保健食品',0,1,1,14,NULL,NULL,0),(15,'珠宝',0,1,1,15,NULL,NULL,0),(16,'汽车用品',0,1,1,16,NULL,NULL,0),(17,'运动健康',0,1,1,17,NULL,NULL,0),(18,'玩具乐器',0,1,1,18,NULL,NULL,0),(19,'彩票、旅行、充值、票务',0,1,1,19,NULL,NULL,0),(20,'生鲜',0,1,1,20,NULL,NULL,0),(21,'整车',0,1,1,21,NULL,NULL,0),(22,'电子书刊',1,2,1,0,NULL,NULL,0),(23,'音像',1,2,1,1,NULL,NULL,0),(24,'英文原版',1,2,1,2,NULL,NULL,0),(25,'文艺',1,2,1,3,NULL,NULL,0),(26,'少儿',1,2,1,4,NULL,NULL,0),(27,'人文社科',1,2,1,5,NULL,NULL,0),(28,'经管励志',1,2,1,6,NULL,NULL,0),(29,'生活',1,2,1,7,NULL,NULL,0),(30,'科技',1,2,1,8,NULL,NULL,0),(31,'教育',1,2,1,9,NULL,NULL,0),(32,'港台图书',1,2,1,10,NULL,NULL,0),(33,'其他',1,2,1,11,NULL,NULL,0),(34,'手机通讯',2,2,1,1,NULL,NULL,0),(35,'运营商',2,2,1,2,NULL,NULL,0),(36,'手机配件',2,2,1,0,NULL,NULL,0),(37,'大 家 电',3,2,1,0,NULL,NULL,0),(38,'厨卫大电',3,2,1,1,NULL,NULL,0),(39,'厨房小电',3,2,1,2,NULL,NULL,0),(40,'生活电器',3,2,1,3,NULL,NULL,0),(41,'个护健康',3,2,1,4,NULL,NULL,0),(42,'五金家装',3,2,1,5,NULL,NULL,0),(43,'摄影摄像',4,2,1,0,NULL,NULL,0),(44,'数码配件',4,2,1,2,NULL,NULL,0),(45,'智能设备',4,2,1,1,NULL,NULL,0),(46,'影音娱乐',4,2,1,3,NULL,NULL,0),(47,'电子教育',4,2,1,4,NULL,NULL,0),(48,'虚拟商品',4,2,1,5,NULL,NULL,0),(49,'家纺',5,2,1,0,NULL,NULL,0),(50,'灯具',5,2,1,0,NULL,NULL,0),(51,'生活日用',5,2,1,0,NULL,NULL,0),(52,'家装软饰',5,2,1,0,NULL,NULL,0),(53,'宠物生活',5,2,1,0,NULL,NULL,0),(54,'电脑整机',6,2,1,0,NULL,NULL,0),(55,'电脑配件',6,2,1,0,NULL,NULL,0),(56,'外设产品',6,2,1,0,NULL,NULL,0),(57,'游戏设备',6,2,1,0,NULL,NULL,0),(58,'网络产品',6,2,1,0,NULL,NULL,0),(59,'办公设备',6,2,1,0,NULL,NULL,0),(60,'文具/耗材',6,2,1,0,NULL,NULL,0),(61,'服务产品',6,2,1,0,NULL,NULL,0),(62,'烹饪锅具',7,2,1,0,NULL,NULL,0),(63,'刀剪菜板',7,2,1,0,NULL,NULL,0),(64,'厨房配件',7,2,1,0,NULL,NULL,0),(65,'水具酒具',7,2,1,0,NULL,NULL,0),(66,'餐具',7,2,1,0,NULL,NULL,0),(67,'酒店用品',7,2,1,0,NULL,NULL,0),(68,'茶具/咖啡具',7,2,1,0,NULL,NULL,0),(69,'清洁用品',8,2,1,0,NULL,NULL,0),(70,'面部护肤',8,2,1,0,NULL,NULL,0),(71,'身体护理',8,2,1,0,NULL,NULL,0),(72,'口腔护理',8,2,1,0,NULL,NULL,0),(73,'女性护理',8,2,1,0,NULL,NULL,0),(74,'洗发护发',8,2,1,0,NULL,NULL,0),(75,'香水彩妆',8,2,1,0,NULL,NULL,0),(76,'女装',9,2,1,0,NULL,NULL,0),(77,'男装',9,2,1,0,NULL,NULL,0),(78,'内衣',9,2,1,0,NULL,NULL,0),(79,'洗衣服务',9,2,1,0,NULL,NULL,0),(80,'服饰配件',9,2,1,0,NULL,NULL,0),(81,'钟表',10,2,1,0,NULL,NULL,0),(82,'流行男鞋',11,2,1,0,NULL,NULL,0),(83,'时尚女鞋',11,2,1,0,NULL,NULL,0),(84,'奶粉',12,2,1,0,NULL,NULL,0),(85,'营养辅食',12,2,1,0,NULL,NULL,0),(86,'尿裤湿巾',12,2,1,0,NULL,NULL,0),(87,'喂养用品',12,2,1,0,NULL,NULL,0),(88,'洗护用品',12,2,1,0,NULL,NULL,0),(89,'童车童床',12,2,1,0,NULL,NULL,0),(90,'寝居服饰',12,2,1,0,NULL,NULL,0),(91,'妈妈专区',12,2,1,0,NULL,NULL,0),(92,'童装童鞋',12,2,1,0,NULL,NULL,0),(93,'安全座椅',12,2,1,0,NULL,NULL,0),(94,'潮流女包',13,2,1,0,NULL,NULL,0),(95,'精品男包',13,2,1,0,NULL,NULL,0),(96,'功能箱包',13,2,1,0,NULL,NULL,0),(97,'礼品',13,2,1,0,NULL,NULL,0),(98,'奢侈品',13,2,1,0,NULL,NULL,0),(99,'婚庆',13,2,1,0,NULL,NULL,0),(100,'进口食品',14,2,1,0,NULL,NULL,0),(101,'地方特产',14,2,1,0,NULL,NULL,0),(102,'休闲食品',14,2,1,0,NULL,NULL,0),(103,'粮油调味',14,2,1,0,NULL,NULL,0),(104,'饮料冲调',14,2,1,0,NULL,NULL,0),(105,'食品礼券',14,2,1,0,NULL,NULL,0),(106,'茗茶',14,2,1,0,NULL,NULL,0),(107,'时尚饰品',15,2,1,0,NULL,NULL,0),(108,'黄金',15,2,1,0,NULL,NULL,0),(109,'K金饰品',15,2,1,0,NULL,NULL,0),(110,'金银投资',15,2,1,0,NULL,NULL,0),(111,'银饰',15,2,1,0,NULL,NULL,0),(112,'钻石',15,2,1,0,NULL,NULL,0),(113,'翡翠玉石',15,2,1,0,NULL,NULL,0),(114,'水晶玛瑙',15,2,1,0,NULL,NULL,0),(115,'彩宝',15,2,1,0,NULL,NULL,0),(116,'铂金',15,2,1,0,NULL,NULL,0),(117,'木手串/把件',15,2,1,0,NULL,NULL,0),(118,'珍珠',15,2,1,0,NULL,NULL,0),(119,'维修保养',16,2,1,0,NULL,NULL,0),(120,'车载电器',16,2,1,0,NULL,NULL,0),(121,'美容清洗',16,2,1,0,NULL,NULL,0),(122,'汽车装饰',16,2,1,0,NULL,NULL,0),(123,'安全自驾',16,2,1,0,NULL,NULL,0),(124,'汽车服务',16,2,1,0,NULL,NULL,0),(125,'赛事改装',16,2,1,0,NULL,NULL,0),(126,'运动鞋包',17,2,1,0,NULL,NULL,0),(127,'运动服饰',17,2,1,0,NULL,NULL,0),(128,'骑行运动',17,2,1,0,NULL,NULL,0),(129,'垂钓用品',17,2,1,0,NULL,NULL,0),(130,'游泳用品',17,2,1,0,NULL,NULL,0),(131,'户外鞋服',17,2,1,0,NULL,NULL,0),(132,'户外装备',17,2,1,0,NULL,NULL,0),(133,'健身训练',17,2,1,0,NULL,NULL,0),(134,'体育用品',17,2,1,0,NULL,NULL,0),(135,'适用年龄',18,2,1,0,NULL,NULL,0),(136,'遥控/电动',18,2,1,0,NULL,NULL,0),(137,'毛绒布艺',18,2,1,0,NULL,NULL,0),(138,'娃娃玩具',18,2,1,0,NULL,NULL,0),(139,'模型玩具',18,2,1,0,NULL,NULL,0),(140,'健身玩具',18,2,1,0,NULL,NULL,0),(141,'动漫玩具',18,2,1,0,NULL,NULL,0),(142,'益智玩具',18,2,1,0,NULL,NULL,0),(143,'积木拼插',18,2,1,0,NULL,NULL,0),(144,'DIY玩具',18,2,1,0,NULL,NULL,0),(145,'创意减压',18,2,1,0,NULL,NULL,0),(146,'乐器',18,2,1,0,NULL,NULL,0),(147,'彩票',19,2,1,0,NULL,NULL,0),(148,'机票',19,2,1,0,NULL,NULL,0),(149,'酒店',19,2,1,0,NULL,NULL,0),(150,'旅行',19,2,1,0,NULL,NULL,0),(151,'充值',19,2,1,0,NULL,NULL,0),(152,'游戏',19,2,1,0,NULL,NULL,0),(153,'票务',19,2,1,0,NULL,NULL,0),(154,'产地直供',20,2,1,0,NULL,NULL,0),(155,'水果',20,2,1,0,NULL,NULL,0),(156,'猪牛羊肉',20,2,1,0,NULL,NULL,0),(157,'海鲜水产',20,2,1,0,NULL,NULL,0),(158,'禽肉蛋品',20,2,1,0,NULL,NULL,0),(159,'冷冻食品',20,2,1,0,NULL,NULL,0),(160,'熟食腊味',20,2,1,0,NULL,NULL,0),(161,'饮品甜品',20,2,1,0,NULL,NULL,0),(162,'蔬菜',20,2,1,0,NULL,NULL,0),(163,'全新整车',21,2,1,0,NULL,NULL,0),(164,'二手车',21,2,1,0,NULL,NULL,0),(165,'电子书',22,3,1,0,NULL,NULL,0),(166,'网络原创',22,3,1,0,NULL,NULL,0),(167,'数字杂志',22,3,1,0,NULL,NULL,0),(168,'多媒体图书',22,3,1,0,NULL,NULL,0),(169,'音乐',23,3,1,0,NULL,NULL,0),(170,'影视',23,3,1,0,NULL,NULL,0),(171,'教育音像',23,3,1,0,NULL,NULL,0),(172,'少儿',24,3,1,0,NULL,NULL,0),(173,'商务投资',24,3,1,0,NULL,NULL,0),(174,'英语学习与考试',24,3,1,0,NULL,NULL,0),(175,'文学',24,3,1,0,NULL,NULL,0),(176,'传记',24,3,1,0,NULL,NULL,0),(177,'励志',24,3,1,0,NULL,NULL,0),(178,'小说',25,3,1,0,NULL,NULL,0),(179,'文学',25,3,1,0,NULL,NULL,0),(180,'青春文学',25,3,1,0,NULL,NULL,0),(181,'传记',25,3,1,0,NULL,NULL,0),(182,'艺术',25,3,1,0,NULL,NULL,0),(183,'少儿',26,3,1,0,NULL,NULL,0),(184,'0-2岁',26,3,1,0,NULL,NULL,0),(185,'3-6岁',26,3,1,0,NULL,NULL,0),(186,'7-10岁',26,3,1,0,NULL,NULL,0),(187,'11-14岁',26,3,1,0,NULL,NULL,0),(188,'历史',27,3,1,0,NULL,NULL,0),(189,'哲学',27,3,1,0,NULL,NULL,0),(190,'国学',27,3,1,0,NULL,NULL,0),(191,'政治/军事',27,3,1,0,NULL,NULL,0),(192,'法律',27,3,1,0,NULL,NULL,0),(193,'人文社科',27,3,1,0,NULL,NULL,0),(194,'心理学',27,3,1,0,NULL,NULL,0),(195,'文化',27,3,1,0,NULL,NULL,0),(196,'社会科学',27,3,1,0,NULL,NULL,0),(197,'经济',28,3,1,0,NULL,NULL,0),(198,'金融与投资',28,3,1,0,NULL,NULL,0),(199,'管理',28,3,1,0,NULL,NULL,0),(200,'励志与成功',28,3,1,0,NULL,NULL,0),(201,'生活',29,3,1,0,NULL,NULL,0),(202,'健身与保健',29,3,1,0,NULL,NULL,0),(203,'家庭与育儿',29,3,1,0,NULL,NULL,0),(204,'旅游',29,3,1,0,NULL,NULL,0),(205,'烹饪美食',29,3,1,0,NULL,NULL,0),(206,'工业技术',30,3,1,0,NULL,NULL,0),(207,'科普读物',30,3,1,0,NULL,NULL,0),(208,'建筑',30,3,1,0,NULL,NULL,0),(209,'医学',30,3,1,0,NULL,NULL,0),(210,'科学与自然',30,3,1,0,NULL,NULL,0),(211,'计算机与互联网',30,3,1,0,NULL,NULL,0),(212,'电子通信',30,3,1,0,NULL,NULL,0),(213,'中小学教辅',31,3,1,0,NULL,NULL,0),(214,'教育与考试',31,3,1,0,NULL,NULL,0),(215,'外语学习',31,3,1,0,NULL,NULL,0),(216,'大中专教材',31,3,1,0,NULL,NULL,0),(217,'字典词典',31,3,1,0,NULL,NULL,0),(218,'艺术/设计/收藏',32,3,1,0,NULL,NULL,0),(219,'经济管理',32,3,1,0,NULL,NULL,0),(220,'文化/学术',32,3,1,0,NULL,NULL,0),(221,'少儿',32,3,1,0,NULL,NULL,0),(222,'工具书',33,3,1,0,NULL,NULL,0),(223,'杂志/期刊',33,3,1,0,NULL,NULL,0),(224,'套装书',33,3,1,0,NULL,NULL,0),(225,'手机',34,3,1,0,NULL,NULL,0),(226,'对讲机',34,3,1,0,NULL,NULL,0),(227,'合约机',35,3,1,0,NULL,NULL,0),(228,'选号中心',35,3,1,0,NULL,NULL,0),(229,'装宽带',35,3,1,0,NULL,NULL,0),(230,'办套餐',35,3,1,0,NULL,NULL,0),(231,'移动电源',36,3,1,0,NULL,NULL,0),(232,'电池/移动电源',36,3,1,0,NULL,NULL,0),(233,'蓝牙耳机',36,3,1,0,NULL,NULL,0),(234,'充电器/数据线',36,3,1,0,NULL,NULL,0),(235,'苹果周边',36,3,1,0,NULL,NULL,0),(236,'手机耳机',36,3,1,0,NULL,NULL,0),(237,'手机贴膜',36,3,1,0,NULL,NULL,0),(238,'手机存储卡',36,3,1,0,NULL,NULL,0),(239,'充电器',36,3,1,0,NULL,NULL,0),(240,'数据线',36,3,1,0,NULL,NULL,0),(241,'手机保护套',36,3,1,0,NULL,NULL,0),(242,'车载配件',36,3,1,0,NULL,NULL,0),(243,'iPhone 配件',36,3,1,0,NULL,NULL,0),(244,'手机电池',36,3,1,0,NULL,NULL,0),(245,'创意配件',36,3,1,0,NULL,NULL,0),(246,'便携/无线音响',36,3,1,0,NULL,NULL,0),(247,'手机饰品',36,3,1,0,NULL,NULL,0),(248,'拍照配件',36,3,1,0,NULL,NULL,0),(249,'手机支架',36,3,1,0,NULL,NULL,0),(250,'平板电视',37,3,1,0,NULL,NULL,0),(251,'空调',37,3,1,0,NULL,NULL,0),(252,'冰箱',37,3,1,0,NULL,NULL,0),(253,'洗衣机',37,3,1,0,NULL,NULL,0),(254,'家庭影院',37,3,1,0,NULL,NULL,0),(255,'DVD/电视盒子',37,3,1,0,NULL,NULL,0),(256,'迷你音响',37,3,1,0,NULL,NULL,0),(257,'冷柜/冰吧',37,3,1,0,NULL,NULL,0),(258,'家电配件',37,3,1,0,NULL,NULL,0),(259,'功放',37,3,1,0,NULL,NULL,0),(260,'回音壁/Soundbar',37,3,1,0,NULL,NULL,0),(261,'Hi-Fi专区',37,3,1,0,NULL,NULL,0),(262,'电视盒子',37,3,1,0,NULL,NULL,0),(263,'酒柜',37,3,1,0,NULL,NULL,0),(264,'燃气灶',38,3,1,0,NULL,NULL,0),(265,'油烟机',38,3,1,0,NULL,NULL,0),(266,'热水器',38,3,1,0,NULL,NULL,0),(267,'消毒柜',38,3,1,0,NULL,NULL,0),(268,'洗碗机',38,3,1,0,NULL,NULL,0),(269,'料理机',39,3,1,0,NULL,NULL,0),(270,'榨汁机',39,3,1,0,NULL,NULL,0),(271,'电饭煲',39,3,1,0,NULL,NULL,0),(272,'电压力锅',39,3,1,0,NULL,NULL,0),(273,'豆浆机',39,3,1,0,NULL,NULL,0),(274,'咖啡机',39,3,1,0,NULL,NULL,0),(275,'微波炉',39,3,1,0,NULL,NULL,0),(276,'电烤箱',39,3,1,0,NULL,NULL,0),(277,'电磁炉',39,3,1,0,NULL,NULL,0),(278,'面包机',39,3,1,0,NULL,NULL,0),(279,'煮蛋器',39,3,1,0,NULL,NULL,0),(280,'酸奶机',39,3,1,0,NULL,NULL,0),(281,'电炖锅',39,3,1,0,NULL,NULL,0),(282,'电水壶/热水瓶',39,3,1,0,NULL,NULL,0),(283,'电饼铛',39,3,1,0,NULL,NULL,0),(284,'多用途锅',39,3,1,0,NULL,NULL,0),(285,'电烧烤炉',39,3,1,0,NULL,NULL,0),(286,'果蔬解毒机',39,3,1,0,NULL,NULL,0),(287,'其它厨房电器',39,3,1,0,NULL,NULL,0),(288,'养生壶/煎药壶',39,3,1,0,NULL,NULL,0),(289,'电热饭盒',39,3,1,0,NULL,NULL,0),(290,'取暖电器',40,3,1,0,NULL,NULL,0),(291,'净化器',40,3,1,0,NULL,NULL,0),(292,'加湿器',40,3,1,0,NULL,NULL,0),(293,'扫地机器人',40,3,1,0,NULL,NULL,0),(294,'吸尘器',40,3,1,0,NULL,NULL,0),(295,'挂烫机/熨斗',40,3,1,0,NULL,NULL,0),(296,'插座',40,3,1,0,NULL,NULL,0),(297,'电话机',40,3,1,0,NULL,NULL,0),(298,'清洁机',40,3,1,0,NULL,NULL,0),(299,'除湿机',40,3,1,0,NULL,NULL,0),(300,'干衣机',40,3,1,0,NULL,NULL,0),(301,'收录/音机',40,3,1,0,NULL,NULL,0),(302,'电风扇',40,3,1,0,NULL,NULL,0),(303,'冷风扇',40,3,1,0,NULL,NULL,0),(304,'其它生活电器',40,3,1,0,NULL,NULL,0),(305,'生活电器配件',40,3,1,0,NULL,NULL,0),(306,'净水器',40,3,1,0,NULL,NULL,0),(307,'饮水机',40,3,1,0,NULL,NULL,0),(308,'剃须刀',41,3,1,0,NULL,NULL,0),(309,'剃/脱毛器',41,3,1,0,NULL,NULL,0),(310,'口腔护理',41,3,1,0,NULL,NULL,0),(311,'电吹风',41,3,1,0,NULL,NULL,0),(312,'美容器',41,3,1,0,NULL,NULL,0),(313,'理发器',41,3,1,0,NULL,NULL,0),(314,'卷/直发器',41,3,1,0,NULL,NULL,0),(315,'按摩椅',41,3,1,0,NULL,NULL,0),(316,'按摩器',41,3,1,0,NULL,NULL,0),(317,'足浴盆',41,3,1,0,NULL,NULL,0),(318,'血压计',41,3,1,0,NULL,NULL,0),(319,'电子秤/厨房秤',41,3,1,0,NULL,NULL,0),(320,'血糖仪',41,3,1,0,NULL,NULL,0),(321,'体温计',41,3,1,0,NULL,NULL,0),(322,'其它健康电器',41,3,1,0,NULL,NULL,0),(323,'计步器/脂肪检测仪',41,3,1,0,NULL,NULL,0),(324,'电动工具',42,3,1,0,NULL,NULL,0),(325,'手动工具',42,3,1,0,NULL,NULL,0),(326,'仪器仪表',42,3,1,0,NULL,NULL,0),(327,'浴霸/排气扇',42,3,1,0,NULL,NULL,0),(328,'灯具',42,3,1,0,NULL,NULL,0),(329,'LED灯',42,3,1,0,NULL,NULL,0),(330,'洁身器',42,3,1,0,NULL,NULL,0),(331,'水槽',42,3,1,0,NULL,NULL,0),(332,'龙头',42,3,1,0,NULL,NULL,0),(333,'淋浴花洒',42,3,1,0,NULL,NULL,0),(334,'厨卫五金',42,3,1,0,NULL,NULL,0),(335,'家具五金',42,3,1,0,NULL,NULL,0),(336,'门铃',42,3,1,0,NULL,NULL,0),(337,'电气开关',42,3,1,0,NULL,NULL,0),(338,'插座',42,3,1,0,NULL,NULL,0),(339,'电工电料',42,3,1,0,NULL,NULL,0),(340,'监控安防',42,3,1,0,NULL,NULL,0),(341,'电线/线缆',42,3,1,0,NULL,NULL,0),(342,'数码相机',43,3,1,0,NULL,NULL,0),(343,'单电/微单相机',43,3,1,0,NULL,NULL,0),(344,'单反相机',43,3,1,0,NULL,NULL,0),(345,'摄像机',43,3,1,0,NULL,NULL,0),(346,'拍立得',43,3,1,0,NULL,NULL,0),(347,'运动相机',43,3,1,0,NULL,NULL,0),(348,'镜头',43,3,1,0,NULL,NULL,0),(349,'户外器材',43,3,1,0,NULL,NULL,0),(350,'影棚器材',43,3,1,0,NULL,NULL,0),(351,'冲印服务',43,3,1,0,NULL,NULL,0),(352,'数码相框',43,3,1,0,NULL,NULL,0),(353,'存储卡',44,3,1,0,NULL,NULL,0),(354,'读卡器',44,3,1,0,NULL,NULL,0),(355,'滤镜',44,3,1,0,NULL,NULL,0),(356,'闪光灯/手柄',44,3,1,0,NULL,NULL,0),(357,'相机包',44,3,1,0,NULL,NULL,0),(358,'三脚架/云台',44,3,1,0,NULL,NULL,0),(359,'相机清洁/贴膜',44,3,1,0,NULL,NULL,0),(360,'机身附件',44,3,1,0,NULL,NULL,0),(361,'镜头附件',44,3,1,0,NULL,NULL,0),(362,'电池/充电器',44,3,1,0,NULL,NULL,0),(363,'移动电源',44,3,1,0,NULL,NULL,0),(364,'数码支架',44,3,1,0,NULL,NULL,0),(365,'智能手环',45,3,1,0,NULL,NULL,0),(366,'智能手表',45,3,1,0,NULL,NULL,0),(367,'智能眼镜',45,3,1,0,NULL,NULL,0),(368,'运动跟踪器',45,3,1,0,NULL,NULL,0),(369,'健康监测',45,3,1,0,NULL,NULL,0),(370,'智能配饰',45,3,1,0,NULL,NULL,0),(371,'智能家居',45,3,1,0,NULL,NULL,0),(372,'体感车',45,3,1,0,NULL,NULL,0),(373,'其他配件',45,3,1,0,NULL,NULL,0),(374,'智能机器人',45,3,1,0,NULL,NULL,0),(375,'无人机',45,3,1,0,NULL,NULL,0),(376,'MP3/MP4',46,3,1,0,NULL,NULL,0),(377,'智能设备',46,3,1,0,NULL,NULL,0),(378,'耳机/耳麦',46,3,1,0,NULL,NULL,0),(379,'便携/无线音箱',46,3,1,0,NULL,NULL,0),(380,'音箱/音响',46,3,1,0,NULL,NULL,0),(381,'高清播放器',46,3,1,0,NULL,NULL,0),(382,'收音机',46,3,1,0,NULL,NULL,0),(383,'MP3/MP4配件',46,3,1,0,NULL,NULL,0),(384,'麦克风',46,3,1,0,NULL,NULL,0),(385,'专业音频',46,3,1,0,NULL,NULL,0),(386,'苹果配件',46,3,1,0,NULL,NULL,0),(387,'学生平板',47,3,1,0,NULL,NULL,0),(388,'点读机/笔',47,3,1,0,NULL,NULL,0),(389,'早教益智',47,3,1,0,NULL,NULL,0),(390,'录音笔',47,3,1,0,NULL,NULL,0),(391,'电纸书',47,3,1,0,NULL,NULL,0),(392,'电子词典',47,3,1,0,NULL,NULL,0),(393,'复读机',47,3,1,0,NULL,NULL,0),(394,'延保服务',48,3,1,0,NULL,NULL,0),(395,'杀毒软件',48,3,1,0,NULL,NULL,0),(396,'积分商品',48,3,1,0,NULL,NULL,0),(397,'桌布/罩件',49,3,1,0,NULL,NULL,0),(398,'地毯地垫',49,3,1,0,NULL,NULL,0),(399,'沙发垫套/椅垫',49,3,1,0,NULL,NULL,0),(400,'床品套件',49,3,1,0,NULL,NULL,0),(401,'被子',49,3,1,0,NULL,NULL,0),(402,'枕芯',49,3,1,0,NULL,NULL,0),(403,'床单被罩',49,3,1,0,NULL,NULL,0),(404,'毯子',49,3,1,0,NULL,NULL,0),(405,'床垫/床褥',49,3,1,0,NULL,NULL,0),(406,'蚊帐',49,3,1,0,NULL,NULL,0),(407,'抱枕靠垫',49,3,1,0,NULL,NULL,0),(408,'毛巾浴巾',49,3,1,0,NULL,NULL,0),(409,'电热毯',49,3,1,0,NULL,NULL,0),(410,'窗帘/窗纱',49,3,1,0,NULL,NULL,0),(411,'布艺软饰',49,3,1,0,NULL,NULL,0),(412,'凉席',49,3,1,0,NULL,NULL,0),(413,'台灯',50,3,1,0,NULL,NULL,0),(414,'节能灯',50,3,1,0,NULL,NULL,0),(415,'装饰灯',50,3,1,0,NULL,NULL,0),(416,'落地灯',50,3,1,0,NULL,NULL,0),(417,'应急灯/手电',50,3,1,0,NULL,NULL,0),(418,'LED灯',50,3,1,0,NULL,NULL,0),(419,'吸顶灯',50,3,1,0,NULL,NULL,0),(420,'五金电器',50,3,1,0,NULL,NULL,0),(421,'筒灯射灯',50,3,1,0,NULL,NULL,0),(422,'吊灯',50,3,1,0,NULL,NULL,0),(423,'氛围照明',50,3,1,0,NULL,NULL,0),(424,'保暖防护',51,3,1,0,NULL,NULL,0),(425,'收纳用品',51,3,1,0,NULL,NULL,0),(426,'雨伞雨具',51,3,1,0,NULL,NULL,0),(427,'浴室用品',51,3,1,0,NULL,NULL,0),(428,'缝纫/针织用品',51,3,1,0,NULL,NULL,0),(429,'洗晒/熨烫',51,3,1,0,NULL,NULL,0),(430,'净化除味',51,3,1,0,NULL,NULL,0),(431,'相框/照片墙',52,3,1,0,NULL,NULL,0),(432,'装饰字画',52,3,1,0,NULL,NULL,0),(433,'节庆饰品',52,3,1,0,NULL,NULL,0),(434,'手工/十字绣',52,3,1,0,NULL,NULL,0),(435,'装饰摆件',52,3,1,0,NULL,NULL,0),(436,'帘艺隔断',52,3,1,0,NULL,NULL,0),(437,'墙贴/装饰贴',52,3,1,0,NULL,NULL,0),(438,'钟饰',52,3,1,0,NULL,NULL,0),(439,'花瓶花艺',52,3,1,0,NULL,NULL,0),(440,'香薰蜡烛',52,3,1,0,NULL,NULL,0),(441,'创意家居',52,3,1,0,NULL,NULL,0),(442,'宠物主粮',53,3,1,0,NULL,NULL,0),(443,'宠物零食',53,3,1,0,NULL,NULL,0),(444,'医疗保健',53,3,1,0,NULL,NULL,0),(445,'家居日用',53,3,1,0,NULL,NULL,0),(446,'宠物玩具',53,3,1,0,NULL,NULL,0),(447,'出行装备',53,3,1,0,NULL,NULL,0),(448,'洗护美容',53,3,1,0,NULL,NULL,0),(449,'笔记本',54,3,1,0,NULL,NULL,0),(450,'超极本',54,3,1,0,NULL,NULL,0),(451,'游戏本',54,3,1,0,NULL,NULL,0),(452,'平板电脑',54,3,1,0,NULL,NULL,0),(453,'平板电脑配件',54,3,1,0,NULL,NULL,0),(454,'台式机',54,3,1,0,NULL,NULL,0),(455,'服务器/工作站',54,3,1,0,NULL,NULL,0),(456,'笔记本配件',54,3,1,0,NULL,NULL,0),(457,'一体机',54,3,1,0,NULL,NULL,0),(458,'CPU',55,3,1,0,NULL,NULL,0),(459,'主板',55,3,1,0,NULL,NULL,0),(460,'显卡',55,3,1,0,NULL,NULL,0),(461,'硬盘',55,3,1,0,NULL,NULL,0),(462,'SSD固态硬盘',55,3,1,0,NULL,NULL,0),(463,'内存',55,3,1,0,NULL,NULL,0),(464,'机箱',55,3,1,0,NULL,NULL,0),(465,'电源',55,3,1,0,NULL,NULL,0),(466,'显示器',55,3,1,0,NULL,NULL,0),(467,'刻录机/光驱',55,3,1,0,NULL,NULL,0),(468,'散热器',55,3,1,0,NULL,NULL,0),(469,'声卡/扩展卡',55,3,1,0,NULL,NULL,0),(470,'装机配件',55,3,1,0,NULL,NULL,0),(471,'组装电脑',55,3,1,0,NULL,NULL,0),(472,'移动硬盘',56,3,1,0,NULL,NULL,0),(473,'U盘',56,3,1,0,NULL,NULL,0),(474,'鼠标',56,3,1,0,NULL,NULL,0),(475,'键盘',56,3,1,0,NULL,NULL,0),(476,'鼠标垫',56,3,1,0,NULL,NULL,0),(477,'摄像头',56,3,1,0,NULL,NULL,0),(478,'手写板',56,3,1,0,NULL,NULL,0),(479,'硬盘盒',56,3,1,0,NULL,NULL,0),(480,'插座',56,3,1,0,NULL,NULL,0),(481,'线缆',56,3,1,0,NULL,NULL,0),(482,'UPS电源',56,3,1,0,NULL,NULL,0),(483,'电脑工具',56,3,1,0,NULL,NULL,0),(484,'游戏设备',56,3,1,0,NULL,NULL,0),(485,'电玩',56,3,1,0,NULL,NULL,0),(486,'电脑清洁',56,3,1,0,NULL,NULL,0),(487,'网络仪表仪器',56,3,1,0,NULL,NULL,0),(488,'游戏机',57,3,1,0,NULL,NULL,0),(489,'游戏耳机',57,3,1,0,NULL,NULL,0),(490,'手柄/方向盘',57,3,1,0,NULL,NULL,0),(491,'游戏软件',57,3,1,0,NULL,NULL,0),(492,'游戏周边',57,3,1,0,NULL,NULL,0),(493,'路由器',58,3,1,0,NULL,NULL,0),(494,'网卡',58,3,1,0,NULL,NULL,0),(495,'交换机',58,3,1,0,NULL,NULL,0),(496,'网络存储',58,3,1,0,NULL,NULL,0),(497,'4G/3G上网',58,3,1,0,NULL,NULL,0),(498,'网络盒子',58,3,1,0,NULL,NULL,0),(499,'网络配件',58,3,1,0,NULL,NULL,0),(500,'投影机',59,3,1,0,NULL,NULL,0),(501,'投影配件',59,3,1,0,NULL,NULL,0),(502,'多功能一体机',59,3,1,0,NULL,NULL,0),(503,'打印机',59,3,1,0,NULL,NULL,0),(504,'传真设备',59,3,1,0,NULL,NULL,0),(505,'验钞/点钞机',59,3,1,0,NULL,NULL,0),(506,'扫描设备',59,3,1,0,NULL,NULL,0),(507,'复合机',59,3,1,0,NULL,NULL,0),(508,'碎纸机',59,3,1,0,NULL,NULL,0),(509,'考勤机',59,3,1,0,NULL,NULL,0),(510,'收款/POS机',59,3,1,0,NULL,NULL,0),(511,'会议音频视频',59,3,1,0,NULL,NULL,0),(512,'保险柜',59,3,1,0,NULL,NULL,0),(513,'装订/封装机',59,3,1,0,NULL,NULL,0),(514,'安防监控',59,3,1,0,NULL,NULL,0),(515,'办公家具',59,3,1,0,NULL,NULL,0),(516,'白板',59,3,1,0,NULL,NULL,0),(517,'硒鼓/墨粉',60,3,1,0,NULL,NULL,0),(518,'墨盒',60,3,1,0,NULL,NULL,0),(519,'色带',60,3,1,0,NULL,NULL,0),(520,'纸类',60,3,1,0,NULL,NULL,0),(521,'办公文具',60,3,1,0,NULL,NULL,0),(522,'学生文具',60,3,1,0,NULL,NULL,0),(523,'财会用品',60,3,1,0,NULL,NULL,0),(524,'文件管理',60,3,1,0,NULL,NULL,0),(525,'本册/便签',60,3,1,0,NULL,NULL,0),(526,'计算器',60,3,1,0,NULL,NULL,0),(527,'笔类',60,3,1,0,NULL,NULL,0),(528,'画具画材',60,3,1,0,NULL,NULL,0),(529,'刻录碟片/附件',60,3,1,0,NULL,NULL,0),(530,'上门安装',61,3,1,0,NULL,NULL,0),(531,'延保服务',61,3,1,0,NULL,NULL,0),(532,'维修保养',61,3,1,0,NULL,NULL,0),(533,'电脑软件',61,3,1,0,NULL,NULL,0),(534,'京东服务',61,3,1,0,NULL,NULL,0),(535,'炒锅',62,3,1,0,NULL,NULL,0),(536,'煎锅',62,3,1,0,NULL,NULL,0),(537,'压力锅',62,3,1,0,NULL,NULL,0),(538,'蒸锅',62,3,1,0,NULL,NULL,0),(539,'汤锅',62,3,1,0,NULL,NULL,0),(540,'奶锅',62,3,1,0,NULL,NULL,0),(541,'锅具套装',62,3,1,0,NULL,NULL,0),(542,'煲类',62,3,1,0,NULL,NULL,0),(543,'水壶',62,3,1,0,NULL,NULL,0),(544,'火锅',62,3,1,0,NULL,NULL,0),(545,'菜刀',63,3,1,0,NULL,NULL,0),(546,'剪刀',63,3,1,0,NULL,NULL,0),(547,'刀具套装',63,3,1,0,NULL,NULL,0),(548,'砧板',63,3,1,0,NULL,NULL,0),(549,'瓜果刀/刨',63,3,1,0,NULL,NULL,0),(550,'多功能刀',63,3,1,0,NULL,NULL,0),(551,'保鲜盒',64,3,1,0,NULL,NULL,0),(552,'烘焙/烧烤',64,3,1,0,NULL,NULL,0),(553,'饭盒/提锅',64,3,1,0,NULL,NULL,0),(554,'储物/置物架',64,3,1,0,NULL,NULL,0),(555,'厨房DIY/小工具',64,3,1,0,NULL,NULL,0),(556,'塑料杯',65,3,1,0,NULL,NULL,0),(557,'运动水壶',65,3,1,0,NULL,NULL,0),(558,'玻璃杯',65,3,1,0,NULL,NULL,0),(559,'陶瓷/马克杯',65,3,1,0,NULL,NULL,0),(560,'保温杯',65,3,1,0,NULL,NULL,0),(561,'保温壶',65,3,1,0,NULL,NULL,0),(562,'酒杯/酒具',65,3,1,0,NULL,NULL,0),(563,'杯具套装',65,3,1,0,NULL,NULL,0),(564,'餐具套装',66,3,1,0,NULL,NULL,0),(565,'碗/碟/盘',66,3,1,0,NULL,NULL,0),(566,'筷勺/刀叉',66,3,1,0,NULL,NULL,0),(567,'一次性用品',66,3,1,0,NULL,NULL,0),(568,'果盘/果篮',66,3,1,0,NULL,NULL,0),(569,'自助餐炉',67,3,1,0,NULL,NULL,0),(570,'酒店餐具',67,3,1,0,NULL,NULL,0),(571,'酒店水具',67,3,1,0,NULL,NULL,0),(572,'整套茶具',68,3,1,0,NULL,NULL,0),(573,'茶杯',68,3,1,0,NULL,NULL,0),(574,'茶壶',68,3,1,0,NULL,NULL,0),(575,'茶盘茶托',68,3,1,0,NULL,NULL,0),(576,'茶叶罐',68,3,1,0,NULL,NULL,0),(577,'茶具配件',68,3,1,0,NULL,NULL,0),(578,'茶宠摆件',68,3,1,0,NULL,NULL,0),(579,'咖啡具',68,3,1,0,NULL,NULL,0),(580,'其他',68,3,1,0,NULL,NULL,0),(581,'纸品湿巾',69,3,1,0,NULL,NULL,0),(582,'衣物清洁',69,3,1,0,NULL,NULL,0),(583,'清洁工具',69,3,1,0,NULL,NULL,0),(584,'驱虫用品',69,3,1,0,NULL,NULL,0),(585,'家庭清洁',69,3,1,0,NULL,NULL,0),(586,'皮具护理',69,3,1,0,NULL,NULL,0),(587,'一次性用品',69,3,1,0,NULL,NULL,0),(588,'洁面',70,3,1,0,NULL,NULL,0),(589,'乳液面霜',70,3,1,0,NULL,NULL,0),(590,'面膜',70,3,1,0,NULL,NULL,0),(591,'剃须',70,3,1,0,NULL,NULL,0),(592,'套装',70,3,1,0,NULL,NULL,0),(593,'精华',70,3,1,0,NULL,NULL,0),(594,'眼霜',70,3,1,0,NULL,NULL,0),(595,'卸妆',70,3,1,0,NULL,NULL,0),(596,'防晒',70,3,1,0,NULL,NULL,0),(597,'防晒隔离',70,3,1,0,NULL,NULL,0),(598,'T区护理',70,3,1,0,NULL,NULL,0),(599,'眼部护理',70,3,1,0,NULL,NULL,0),(600,'精华露',70,3,1,0,NULL,NULL,0),(601,'爽肤水',70,3,1,0,NULL,NULL,0),(602,'沐浴',71,3,1,0,NULL,NULL,0),(603,'润肤',71,3,1,0,NULL,NULL,0),(604,'颈部',71,3,1,0,NULL,NULL,0),(605,'手足',71,3,1,0,NULL,NULL,0),(606,'纤体塑形',71,3,1,0,NULL,NULL,0),(607,'美胸',71,3,1,0,NULL,NULL,0),(608,'套装',71,3,1,0,NULL,NULL,0),(609,'精油',71,3,1,0,NULL,NULL,0),(610,'洗发护发',71,3,1,0,NULL,NULL,0),(611,'染发/造型',71,3,1,0,NULL,NULL,0),(612,'香薰精油',71,3,1,0,NULL,NULL,0),(613,'磨砂/浴盐',71,3,1,0,NULL,NULL,0),(614,'手工/香皂',71,3,1,0,NULL,NULL,0),(615,'洗发',71,3,1,0,NULL,NULL,0),(616,'护发',71,3,1,0,NULL,NULL,0),(617,'染发',71,3,1,0,NULL,NULL,0),(618,'磨砂膏',71,3,1,0,NULL,NULL,0),(619,'香皂',71,3,1,0,NULL,NULL,0),(620,'牙膏/牙粉',72,3,1,0,NULL,NULL,0),(621,'牙刷/牙线',72,3,1,0,NULL,NULL,0),(622,'漱口水',72,3,1,0,NULL,NULL,0),(623,'套装',72,3,1,0,NULL,NULL,0),(624,'卫生巾',73,3,1,0,NULL,NULL,0),(625,'卫生护垫',73,3,1,0,NULL,NULL,0),(626,'私密护理',73,3,1,0,NULL,NULL,0),(627,'脱毛膏',73,3,1,0,NULL,NULL,0),(628,'其他',73,3,1,0,NULL,NULL,0),(629,'洗发',74,3,1,0,NULL,NULL,0),(630,'护发',74,3,1,0,NULL,NULL,0),(631,'染发',74,3,1,0,NULL,NULL,0),(632,'造型',74,3,1,0,NULL,NULL,0),(633,'假发',74,3,1,0,NULL,NULL,0),(634,'套装',74,3,1,0,NULL,NULL,0),(635,'美发工具',74,3,1,0,NULL,NULL,0),(636,'脸部护理',74,3,1,0,NULL,NULL,0),(637,'香水',75,3,1,0,NULL,NULL,0),(638,'底妆',75,3,1,0,NULL,NULL,0),(639,'腮红',75,3,1,0,NULL,NULL,0),(640,'眼影',75,3,1,0,NULL,NULL,0),(641,'唇部',75,3,1,0,NULL,NULL,0),(642,'美甲',75,3,1,0,NULL,NULL,0),(643,'眼线',75,3,1,0,NULL,NULL,0),(644,'美妆工具',75,3,1,0,NULL,NULL,0),(645,'套装',75,3,1,0,NULL,NULL,0),(646,'防晒隔离',75,3,1,0,NULL,NULL,0),(647,'卸妆',75,3,1,0,NULL,NULL,0),(648,'眉笔',75,3,1,0,NULL,NULL,0),(649,'睫毛膏',75,3,1,0,NULL,NULL,0),(650,'T恤',76,3,1,0,NULL,NULL,0),(651,'衬衫',76,3,1,0,NULL,NULL,0),(652,'针织衫',76,3,1,0,NULL,NULL,0),(653,'雪纺衫',76,3,1,0,NULL,NULL,0),(654,'卫衣',76,3,1,0,NULL,NULL,0),(655,'马甲',76,3,1,0,NULL,NULL,0),(656,'连衣裙',76,3,1,0,NULL,NULL,0),(657,'半身裙',76,3,1,0,NULL,NULL,0),(658,'牛仔裤',76,3,1,0,NULL,NULL,0),(659,'休闲裤',76,3,1,0,NULL,NULL,0),(660,'打底裤',76,3,1,0,NULL,NULL,0),(661,'正装裤',76,3,1,0,NULL,NULL,0),(662,'小西装',76,3,1,0,NULL,NULL,0),(663,'短外套',76,3,1,0,NULL,NULL,0),(664,'风衣',76,3,1,0,NULL,NULL,0),(665,'毛呢大衣',76,3,1,0,NULL,NULL,0),(666,'真皮皮衣',76,3,1,0,NULL,NULL,0),(667,'棉服',76,3,1,0,NULL,NULL,0),(668,'羽绒服',76,3,1,0,NULL,NULL,0),(669,'大码女装',76,3,1,0,NULL,NULL,0),(670,'中老年女装',76,3,1,0,NULL,NULL,0),(671,'婚纱',76,3,1,0,NULL,NULL,0),(672,'打底衫',76,3,1,0,NULL,NULL,0),(673,'旗袍/唐装',76,3,1,0,NULL,NULL,0),(674,'加绒裤',76,3,1,0,NULL,NULL,0),(675,'吊带/背心',76,3,1,0,NULL,NULL,0),(676,'羊绒衫',76,3,1,0,NULL,NULL,0),(677,'短裤',76,3,1,0,NULL,NULL,0),(678,'皮草',76,3,1,0,NULL,NULL,0),(679,'礼服',76,3,1,0,NULL,NULL,0),(680,'仿皮皮衣',76,3,1,0,NULL,NULL,0),(681,'羊毛衫',76,3,1,0,NULL,NULL,0),(682,'设计师/潮牌',76,3,1,0,NULL,NULL,0),(683,'衬衫',77,3,1,0,NULL,NULL,0),(684,'T恤',77,3,1,0,NULL,NULL,0),(685,'POLO衫',77,3,1,0,NULL,NULL,0),(686,'针织衫',77,3,1,0,NULL,NULL,0),(687,'羊绒衫',77,3,1,0,NULL,NULL,0),(688,'卫衣',77,3,1,0,NULL,NULL,0),(689,'马甲/背心',77,3,1,0,NULL,NULL,0),(690,'夹克',77,3,1,0,NULL,NULL,0),(691,'风衣',77,3,1,0,NULL,NULL,0),(692,'毛呢大衣',77,3,1,0,NULL,NULL,0),(693,'仿皮皮衣',77,3,1,0,NULL,NULL,0),(694,'西服',77,3,1,0,NULL,NULL,0),(695,'棉服',77,3,1,0,NULL,NULL,0),(696,'羽绒服',77,3,1,0,NULL,NULL,0),(697,'牛仔裤',77,3,1,0,NULL,NULL,0),(698,'休闲裤',77,3,1,0,NULL,NULL,0),(699,'西裤',77,3,1,0,NULL,NULL,0),(700,'西服套装',77,3,1,0,NULL,NULL,0),(701,'大码男装',77,3,1,0,NULL,NULL,0),(702,'中老年男装',77,3,1,0,NULL,NULL,0),(703,'唐装/中山装',77,3,1,0,NULL,NULL,0),(704,'工装',77,3,1,0,NULL,NULL,0),(705,'真皮皮衣',77,3,1,0,NULL,NULL,0),(706,'加绒裤',77,3,1,0,NULL,NULL,0),(707,'卫裤/运动裤',77,3,1,0,NULL,NULL,0),(708,'短裤',77,3,1,0,NULL,NULL,0),(709,'设计师/潮牌',77,3,1,0,NULL,NULL,0),(710,'羊毛衫',77,3,1,0,NULL,NULL,0),(711,'文胸',78,3,1,0,NULL,NULL,0),(712,'女式内裤',78,3,1,0,NULL,NULL,0),(713,'男式内裤',78,3,1,0,NULL,NULL,0),(714,'睡衣/家居服',78,3,1,0,NULL,NULL,0),(715,'塑身美体',78,3,1,0,NULL,NULL,0),(716,'泳衣',78,3,1,0,NULL,NULL,0),(717,'吊带/背心',78,3,1,0,NULL,NULL,0),(718,'抹胸',78,3,1,0,NULL,NULL,0),(719,'连裤袜/丝袜',78,3,1,0,NULL,NULL,0),(720,'美腿袜',78,3,1,0,NULL,NULL,0),(721,'商务男袜',78,3,1,0,NULL,NULL,0),(722,'保暖内衣',78,3,1,0,NULL,NULL,0),(723,'情侣睡衣',78,3,1,0,NULL,NULL,0),(724,'文胸套装',78,3,1,0,NULL,NULL,0),(725,'少女文胸',78,3,1,0,NULL,NULL,0),(726,'休闲棉袜',78,3,1,0,NULL,NULL,0),(727,'大码内衣',78,3,1,0,NULL,NULL,0),(728,'内衣配件',78,3,1,0,NULL,NULL,0),(729,'打底裤袜',78,3,1,0,NULL,NULL,0),(730,'打底衫',78,3,1,0,NULL,NULL,0),(731,'秋衣秋裤',78,3,1,0,NULL,NULL,0),(732,'情趣内衣',78,3,1,0,NULL,NULL,0),(733,'服装洗护',79,3,1,0,NULL,NULL,0),(734,'太阳镜',80,3,1,0,NULL,NULL,0),(735,'光学镜架/镜片',80,3,1,0,NULL,NULL,0),(736,'围巾/手套/帽子套装',80,3,1,0,NULL,NULL,0),(737,'袖扣',80,3,1,0,NULL,NULL,0),(738,'棒球帽',80,3,1,0,NULL,NULL,0),(739,'毛线帽',80,3,1,0,NULL,NULL,0),(740,'遮阳帽',80,3,1,0,NULL,NULL,0),(741,'老花镜',80,3,1,0,NULL,NULL,0),(742,'装饰眼镜',80,3,1,0,NULL,NULL,0),(743,'防辐射眼镜',80,3,1,0,NULL,NULL,0),(744,'游泳镜',80,3,1,0,NULL,NULL,0),(745,'女士丝巾/围巾/披肩',80,3,1,0,NULL,NULL,0),(746,'男士丝巾/围巾',80,3,1,0,NULL,NULL,0),(747,'鸭舌帽',80,3,1,0,NULL,NULL,0),(748,'贝雷帽',80,3,1,0,NULL,NULL,0),(749,'礼帽',80,3,1,0,NULL,NULL,0),(750,'真皮手套',80,3,1,0,NULL,NULL,0),(751,'毛线手套',80,3,1,0,NULL,NULL,0),(752,'防晒手套',80,3,1,0,NULL,NULL,0),(753,'男士腰带/礼盒',80,3,1,0,NULL,NULL,0),(754,'女士腰带/礼盒',80,3,1,0,NULL,NULL,0),(755,'钥匙扣',80,3,1,0,NULL,NULL,0),(756,'遮阳伞/雨伞',80,3,1,0,NULL,NULL,0),(757,'口罩',80,3,1,0,NULL,NULL,0),(758,'耳罩/耳包',80,3,1,0,NULL,NULL,0),(759,'假领',80,3,1,0,NULL,NULL,0),(760,'毛线/布面料',80,3,1,0,NULL,NULL,0),(761,'领带/领结/领带夹',80,3,1,0,NULL,NULL,0),(762,'男表',81,3,1,0,NULL,NULL,0),(763,'瑞表',81,3,1,0,NULL,NULL,0),(764,'女表',81,3,1,0,NULL,NULL,0),(765,'国表',81,3,1,0,NULL,NULL,0),(766,'日韩表',81,3,1,0,NULL,NULL,0),(767,'欧美表',81,3,1,0,NULL,NULL,0),(768,'德表',81,3,1,0,NULL,NULL,0),(769,'儿童手表',81,3,1,0,NULL,NULL,0),(770,'智能手表',81,3,1,0,NULL,NULL,0),(771,'闹钟',81,3,1,0,NULL,NULL,0),(772,'座钟挂钟',81,3,1,0,NULL,NULL,0),(773,'钟表配件',81,3,1,0,NULL,NULL,0),(774,'商务休闲鞋',82,3,1,0,NULL,NULL,0),(775,'正装鞋',82,3,1,0,NULL,NULL,0),(776,'休闲鞋',82,3,1,0,NULL,NULL,0),(777,'凉鞋/沙滩鞋',82,3,1,0,NULL,NULL,0),(778,'男靴',82,3,1,0,NULL,NULL,0),(779,'功能鞋',82,3,1,0,NULL,NULL,0),(780,'拖鞋/人字拖',82,3,1,0,NULL,NULL,0),(781,'雨鞋/雨靴',82,3,1,0,NULL,NULL,0),(782,'传统布鞋',82,3,1,0,NULL,NULL,0),(783,'鞋配件',82,3,1,0,NULL,NULL,0),(784,'帆布鞋',82,3,1,0,NULL,NULL,0),(785,'增高鞋',82,3,1,0,NULL,NULL,0),(786,'工装鞋',82,3,1,0,NULL,NULL,0),(787,'定制鞋',82,3,1,0,NULL,NULL,0),(788,'高跟鞋',83,3,1,0,NULL,NULL,0),(789,'单鞋',83,3,1,0,NULL,NULL,0),(790,'休闲鞋',83,3,1,0,NULL,NULL,0),(791,'凉鞋',83,3,1,0,NULL,NULL,0),(792,'女靴',83,3,1,0,NULL,NULL,0),(793,'雪地靴',83,3,1,0,NULL,NULL,0),(794,'拖鞋/人字拖',83,3,1,0,NULL,NULL,0),(795,'踝靴',83,3,1,0,NULL,NULL,0),(796,'筒靴',83,3,1,0,NULL,NULL,0),(797,'帆布鞋',83,3,1,0,NULL,NULL,0),(798,'雨鞋/雨靴',83,3,1,0,NULL,NULL,0),(799,'妈妈鞋',83,3,1,0,NULL,NULL,0),(800,'鞋配件',83,3,1,0,NULL,NULL,0),(801,'特色鞋',83,3,1,0,NULL,NULL,0),(802,'鱼嘴鞋',83,3,1,0,NULL,NULL,0),(803,'布鞋/绣花鞋',83,3,1,0,NULL,NULL,0),(804,'马丁靴',83,3,1,0,NULL,NULL,0),(805,'坡跟鞋',83,3,1,0,NULL,NULL,0),(806,'松糕鞋',83,3,1,0,NULL,NULL,0),(807,'内增高',83,3,1,0,NULL,NULL,0),(808,'防水台',83,3,1,0,NULL,NULL,0),(809,'婴幼奶粉',84,3,1,0,NULL,NULL,0),(810,'孕妈奶粉',84,3,1,0,NULL,NULL,0),(811,'益生菌/初乳',85,3,1,0,NULL,NULL,0),(812,'米粉/菜粉',85,3,1,0,NULL,NULL,0),(813,'果泥/果汁',85,3,1,0,NULL,NULL,0),(814,'DHA',85,3,1,0,NULL,NULL,0),(815,'宝宝零食',85,3,1,0,NULL,NULL,0),(816,'钙铁锌/维生素',85,3,1,0,NULL,NULL,0),(817,'清火/开胃',85,3,1,0,NULL,NULL,0),(818,'面条/粥',85,3,1,0,NULL,NULL,0),(819,'婴儿尿裤',86,3,1,0,NULL,NULL,0),(820,'拉拉裤',86,3,1,0,NULL,NULL,0),(821,'婴儿湿巾',86,3,1,0,NULL,NULL,0),(822,'成人尿裤',86,3,1,0,NULL,NULL,0),(823,'奶瓶奶嘴',87,3,1,0,NULL,NULL,0),(824,'吸奶器',87,3,1,0,NULL,NULL,0),(825,'暖奶消毒',87,3,1,0,NULL,NULL,0),(826,'儿童餐具',87,3,1,0,NULL,NULL,0),(827,'水壶/水杯',87,3,1,0,NULL,NULL,0),(828,'牙胶安抚',87,3,1,0,NULL,NULL,0),(829,'围兜/防溅衣',87,3,1,0,NULL,NULL,0),(830,'辅食料理机',87,3,1,0,NULL,NULL,0),(831,'食物存储',87,3,1,0,NULL,NULL,0),(832,'宝宝护肤',88,3,1,0,NULL,NULL,0),(833,'洗发沐浴',88,3,1,0,NULL,NULL,0),(834,'奶瓶清洗',88,3,1,0,NULL,NULL,0),(835,'驱蚊防晒',88,3,1,0,NULL,NULL,0),(836,'理发器',88,3,1,0,NULL,NULL,0),(837,'洗澡用具',88,3,1,0,NULL,NULL,0),(838,'婴儿口腔清洁',88,3,1,0,NULL,NULL,0),(839,'洗衣液/皂',88,3,1,0,NULL,NULL,0),(840,'日常护理',88,3,1,0,NULL,NULL,0),(841,'座便器',88,3,1,0,NULL,NULL,0),(842,'婴儿推车',89,3,1,0,NULL,NULL,0),(843,'餐椅摇椅',89,3,1,0,NULL,NULL,0),(844,'婴儿床',89,3,1,0,NULL,NULL,0),(845,'学步车',89,3,1,0,NULL,NULL,0),(846,'三轮车',89,3,1,0,NULL,NULL,0),(847,'自行车',89,3,1,0,NULL,NULL,0),(848,'电动车',89,3,1,0,NULL,NULL,0),(849,'扭扭车',89,3,1,0,NULL,NULL,0),(850,'滑板车',89,3,1,0,NULL,NULL,0),(851,'婴儿床垫',89,3,1,0,NULL,NULL,0),(852,'婴儿外出服',90,3,1,0,NULL,NULL,0),(853,'婴儿内衣',90,3,1,0,NULL,NULL,0),(854,'婴儿礼盒',90,3,1,0,NULL,NULL,0),(855,'婴儿鞋帽袜',90,3,1,0,NULL,NULL,0),(856,'安全防护',90,3,1,0,NULL,NULL,0),(857,'家居床品',90,3,1,0,NULL,NULL,0),(858,'睡袋/抱被',90,3,1,0,NULL,NULL,0),(859,'爬行垫',90,3,1,0,NULL,NULL,0),(860,'妈咪包/背婴带',91,3,1,0,NULL,NULL,0),(861,'产后塑身',91,3,1,0,NULL,NULL,0),(862,'文胸/内裤',91,3,1,0,NULL,NULL,0),(863,'防辐射服',91,3,1,0,NULL,NULL,0),(864,'孕妈装',91,3,1,0,NULL,NULL,0),(865,'孕期营养',91,3,1,0,NULL,NULL,0),(866,'孕妇护肤',91,3,1,0,NULL,NULL,0),(867,'待产护理',91,3,1,0,NULL,NULL,0),(868,'月子装',91,3,1,0,NULL,NULL,0),(869,'防溢乳垫',91,3,1,0,NULL,NULL,0),(870,'套装',92,3,1,0,NULL,NULL,0),(871,'上衣',92,3,1,0,NULL,NULL,0),(872,'裤子',92,3,1,0,NULL,NULL,0),(873,'裙子',92,3,1,0,NULL,NULL,0),(874,'内衣/家居服',92,3,1,0,NULL,NULL,0),(875,'羽绒服/棉服',92,3,1,0,NULL,NULL,0),(876,'亲子装',92,3,1,0,NULL,NULL,0),(877,'儿童配饰',92,3,1,0,NULL,NULL,0),(878,'礼服/演出服',92,3,1,0,NULL,NULL,0),(879,'运动鞋',92,3,1,0,NULL,NULL,0),(880,'皮鞋/帆布鞋',92,3,1,0,NULL,NULL,0),(881,'靴子',92,3,1,0,NULL,NULL,0),(882,'凉鞋',92,3,1,0,NULL,NULL,0),(883,'功能鞋',92,3,1,0,NULL,NULL,0),(884,'户外/运动服',92,3,1,0,NULL,NULL,0),(885,'提篮式',93,3,1,0,NULL,NULL,0),(886,'安全座椅',93,3,1,0,NULL,NULL,0),(887,'增高垫',93,3,1,0,NULL,NULL,0),(888,'钱包',94,3,1,0,NULL,NULL,0),(889,'手拿包',94,3,1,0,NULL,NULL,0),(890,'单肩包',94,3,1,0,NULL,NULL,0),(891,'双肩包',94,3,1,0,NULL,NULL,0),(892,'手提包',94,3,1,0,NULL,NULL,0),(893,'斜挎包',94,3,1,0,NULL,NULL,0),(894,'钥匙包',94,3,1,0,NULL,NULL,0),(895,'卡包/零钱包',94,3,1,0,NULL,NULL,0),(896,'男士钱包',95,3,1,0,NULL,NULL,0),(897,'男士手包',95,3,1,0,NULL,NULL,0),(898,'卡包名片夹',95,3,1,0,NULL,NULL,0),(899,'商务公文包',95,3,1,0,NULL,NULL,0),(900,'双肩包',95,3,1,0,NULL,NULL,0),(901,'单肩/斜挎包',95,3,1,0,NULL,NULL,0),(902,'钥匙包',95,3,1,0,NULL,NULL,0),(903,'电脑包',96,3,1,0,NULL,NULL,0),(904,'拉杆箱',96,3,1,0,NULL,NULL,0),(905,'旅行包',96,3,1,0,NULL,NULL,0),(906,'旅行配件',96,3,1,0,NULL,NULL,0),(907,'休闲运动包',96,3,1,0,NULL,NULL,0),(908,'拉杆包',96,3,1,0,NULL,NULL,0),(909,'登山包',96,3,1,0,NULL,NULL,0),(910,'妈咪包',96,3,1,0,NULL,NULL,0),(911,'书包',96,3,1,0,NULL,NULL,0),(912,'相机包',96,3,1,0,NULL,NULL,0),(913,'腰包/胸包',96,3,1,0,NULL,NULL,0),(914,'火机烟具',97,3,1,0,NULL,NULL,0),(915,'礼品文具',97,3,1,0,NULL,NULL,0),(916,'军刀军具',97,3,1,0,NULL,NULL,0),(917,'收藏品',97,3,1,0,NULL,NULL,0),(918,'工艺礼品',97,3,1,0,NULL,NULL,0),(919,'创意礼品',97,3,1,0,NULL,NULL,0),(920,'礼盒礼券',97,3,1,0,NULL,NULL,0),(921,'鲜花绿植',97,3,1,0,NULL,NULL,0),(922,'婚庆节庆',97,3,1,0,NULL,NULL,0),(923,'京东卡',97,3,1,0,NULL,NULL,0),(924,'美妆礼品',97,3,1,0,NULL,NULL,0),(925,'礼品定制',97,3,1,0,NULL,NULL,0),(926,'京东福卡',97,3,1,0,NULL,NULL,0),(927,'古董文玩',97,3,1,0,NULL,NULL,0),(928,'箱包',98,3,1,0,NULL,NULL,0),(929,'钱包',98,3,1,0,NULL,NULL,0),(930,'服饰',98,3,1,0,NULL,NULL,0),(931,'腰带',98,3,1,0,NULL,NULL,0),(932,'太阳镜/眼镜框',98,3,1,0,NULL,NULL,0),(933,'配件',98,3,1,0,NULL,NULL,0),(934,'鞋靴',98,3,1,0,NULL,NULL,0),(935,'饰品',98,3,1,0,NULL,NULL,0),(936,'名品腕表',98,3,1,0,NULL,NULL,0),(937,'高档化妆品',98,3,1,0,NULL,NULL,0),(938,'婚嫁首饰',99,3,1,0,NULL,NULL,0),(939,'婚纱摄影',99,3,1,0,NULL,NULL,0),(940,'婚纱礼服',99,3,1,0,NULL,NULL,0),(941,'婚庆服务',99,3,1,0,NULL,NULL,0),(942,'婚庆礼品/用品',99,3,1,0,NULL,NULL,0),(943,'婚宴',99,3,1,0,NULL,NULL,0),(944,'饼干蛋糕',100,3,1,0,NULL,NULL,0),(945,'糖果/巧克力',100,3,1,0,NULL,NULL,0),(946,'休闲零食',100,3,1,0,NULL,NULL,0),(947,'冲调饮品',100,3,1,0,NULL,NULL,0),(948,'粮油调味',100,3,1,0,NULL,NULL,0),(949,'牛奶',100,3,1,0,NULL,NULL,0),(950,'其他特产',101,3,1,0,NULL,NULL,0),(951,'新疆',101,3,1,0,NULL,NULL,0),(952,'北京',101,3,1,0,NULL,NULL,0),(953,'山西',101,3,1,0,NULL,NULL,0),(954,'内蒙古',101,3,1,0,NULL,NULL,0),(955,'福建',101,3,1,0,NULL,NULL,0),(956,'湖南',101,3,1,0,NULL,NULL,0),(957,'四川',101,3,1,0,NULL,NULL,0),(958,'云南',101,3,1,0,NULL,NULL,0),(959,'东北',101,3,1,0,NULL,NULL,0),(960,'休闲零食',102,3,1,0,NULL,NULL,0),(961,'坚果炒货',102,3,1,0,NULL,NULL,0),(962,'肉干肉脯',102,3,1,0,NULL,NULL,0),(963,'蜜饯果干',102,3,1,0,NULL,NULL,0),(964,'糖果/巧克力',102,3,1,0,NULL,NULL,0),(965,'饼干蛋糕',102,3,1,0,NULL,NULL,0),(966,'无糖食品',102,3,1,0,NULL,NULL,0),(967,'米面杂粮',103,3,1,0,NULL,NULL,0),(968,'食用油',103,3,1,0,NULL,NULL,0),(969,'调味品',103,3,1,0,NULL,NULL,0),(970,'南北干货',103,3,1,0,NULL,NULL,0),(971,'方便食品',103,3,1,0,NULL,NULL,0),(972,'有机食品',103,3,1,0,NULL,NULL,0),(973,'饮用水',104,3,1,0,NULL,NULL,0),(974,'饮料',104,3,1,0,NULL,NULL,0),(975,'牛奶乳品',104,3,1,0,NULL,NULL,0),(976,'咖啡/奶茶',104,3,1,0,NULL,NULL,0),(977,'冲饮谷物',104,3,1,0,NULL,NULL,0),(978,'蜂蜜/柚子茶',104,3,1,0,NULL,NULL,0),(979,'成人奶粉',104,3,1,0,NULL,NULL,0),(980,'月饼',105,3,1,0,NULL,NULL,0),(981,'大闸蟹',105,3,1,0,NULL,NULL,0),(982,'粽子',105,3,1,0,NULL,NULL,0),(983,'卡券',105,3,1,0,NULL,NULL,0),(984,'铁观音',106,3,1,0,NULL,NULL,0),(985,'普洱',106,3,1,0,NULL,NULL,0),(986,'龙井',106,3,1,0,NULL,NULL,0),(987,'绿茶',106,3,1,0,NULL,NULL,0),(988,'红茶',106,3,1,0,NULL,NULL,0),(989,'乌龙茶',106,3,1,0,NULL,NULL,0),(990,'花草茶',106,3,1,0,NULL,NULL,0),(991,'花果茶',106,3,1,0,NULL,NULL,0),(992,'养生茶',106,3,1,0,NULL,NULL,0),(993,'黑茶',106,3,1,0,NULL,NULL,0),(994,'白茶',106,3,1,0,NULL,NULL,0),(995,'其它茶',106,3,1,0,NULL,NULL,0),(996,'项链',107,3,1,0,NULL,NULL,0),(997,'手链/脚链',107,3,1,0,NULL,NULL,0),(998,'戒指',107,3,1,0,NULL,NULL,0),(999,'耳饰',107,3,1,0,NULL,NULL,0),(1000,'毛衣链',107,3,1,0,NULL,NULL,0),(1001,'发饰/发卡',107,3,1,0,NULL,NULL,0),(1002,'胸针',107,3,1,0,NULL,NULL,0),(1003,'饰品配件',107,3,1,0,NULL,NULL,0),(1004,'婚庆饰品',107,3,1,0,NULL,NULL,0),(1005,'黄金吊坠',108,3,1,0,NULL,NULL,0),(1006,'黄金项链',108,3,1,0,NULL,NULL,0),(1007,'黄金转运珠',108,3,1,0,NULL,NULL,0),(1008,'黄金手镯/手链/脚链',108,3,1,0,NULL,NULL,0),(1009,'黄金耳饰',108,3,1,0,NULL,NULL,0),(1010,'黄金戒指',108,3,1,0,NULL,NULL,0),(1011,'K金吊坠',109,3,1,0,NULL,NULL,0),(1012,'K金项链',109,3,1,0,NULL,NULL,0),(1013,'K金手镯/手链/脚链',109,3,1,0,NULL,NULL,0),(1014,'K金戒指',109,3,1,0,NULL,NULL,0),(1015,'K金耳饰',109,3,1,0,NULL,NULL,0),(1016,'投资金',110,3,1,0,NULL,NULL,0),(1017,'投资银',110,3,1,0,NULL,NULL,0),(1018,'投资收藏',110,3,1,0,NULL,NULL,0),(1019,'银吊坠/项链',111,3,1,0,NULL,NULL,0),(1020,'银手镯/手链/脚链',111,3,1,0,NULL,NULL,0),(1021,'银戒指',111,3,1,0,NULL,NULL,0),(1022,'银耳饰',111,3,1,0,NULL,NULL,0),(1023,'足银手镯',111,3,1,0,NULL,NULL,0),(1024,'宝宝银饰',111,3,1,0,NULL,NULL,0),(1025,'裸钻',112,3,1,0,NULL,NULL,0),(1026,'钻戒',112,3,1,0,NULL,NULL,0),(1027,'钻石项链/吊坠',112,3,1,0,NULL,NULL,0),(1028,'钻石耳饰',112,3,1,0,NULL,NULL,0),(1029,'钻石手镯/手链',112,3,1,0,NULL,NULL,0),(1030,'项链/吊坠',113,3,1,0,NULL,NULL,0),(1031,'手镯/手串',113,3,1,0,NULL,NULL,0),(1032,'戒指',113,3,1,0,NULL,NULL,0),(1033,'耳饰',113,3,1,0,NULL,NULL,0),(1034,'挂件/摆件/把件',113,3,1,0,NULL,NULL,0),(1035,'玉石孤品',113,3,1,0,NULL,NULL,0),(1036,'项链/吊坠',114,3,1,0,NULL,NULL,0),(1037,'耳饰',114,3,1,0,NULL,NULL,0),(1038,'手镯/手链/脚链',114,3,1,0,NULL,NULL,0),(1039,'戒指',114,3,1,0,NULL,NULL,0),(1040,'头饰/胸针',114,3,1,0,NULL,NULL,0),(1041,'摆件/挂件',114,3,1,0,NULL,NULL,0),(1042,'琥珀/蜜蜡',115,3,1,0,NULL,NULL,0),(1043,'碧玺',115,3,1,0,NULL,NULL,0),(1044,'红宝石/蓝宝石',115,3,1,0,NULL,NULL,0),(1045,'坦桑石',115,3,1,0,NULL,NULL,0),(1046,'珊瑚',115,3,1,0,NULL,NULL,0),(1047,'祖母绿',115,3,1,0,NULL,NULL,0),(1048,'葡萄石',115,3,1,0,NULL,NULL,0),(1049,'其他天然宝石',115,3,1,0,NULL,NULL,0),(1050,'项链/吊坠',115,3,1,0,NULL,NULL,0),(1051,'耳饰',115,3,1,0,NULL,NULL,0),(1052,'手镯/手链',115,3,1,0,NULL,NULL,0),(1053,'戒指',115,3,1,0,NULL,NULL,0),(1054,'铂金项链/吊坠',116,3,1,0,NULL,NULL,0),(1055,'铂金手镯/手链/脚链',116,3,1,0,NULL,NULL,0),(1056,'铂金戒指',116,3,1,0,NULL,NULL,0),(1057,'铂金耳饰',116,3,1,0,NULL,NULL,0),(1058,'小叶紫檀',117,3,1,0,NULL,NULL,0),(1059,'黄花梨',117,3,1,0,NULL,NULL,0),(1060,'沉香木',117,3,1,0,NULL,NULL,0),(1061,'金丝楠',117,3,1,0,NULL,NULL,0),(1062,'菩提',117,3,1,0,NULL,NULL,0),(1063,'其他',117,3,1,0,NULL,NULL,0),(1064,'橄榄核/核桃',117,3,1,0,NULL,NULL,0),(1065,'檀香',117,3,1,0,NULL,NULL,0),(1066,'珍珠项链',118,3,1,0,NULL,NULL,0),(1067,'珍珠吊坠',118,3,1,0,NULL,NULL,0),(1068,'珍珠耳饰',118,3,1,0,NULL,NULL,0),(1069,'珍珠手链',118,3,1,0,NULL,NULL,0),(1070,'珍珠戒指',118,3,1,0,NULL,NULL,0),(1071,'珍珠胸针',118,3,1,0,NULL,NULL,0),(1072,'机油',119,3,1,0,NULL,NULL,0),(1073,'正时皮带',119,3,1,0,NULL,NULL,0),(1074,'添加剂',119,3,1,0,NULL,NULL,0),(1075,'汽车喇叭',119,3,1,0,NULL,NULL,0),(1076,'防冻液',119,3,1,0,NULL,NULL,0),(1077,'汽车玻璃',119,3,1,0,NULL,NULL,0),(1078,'滤清器',119,3,1,0,NULL,NULL,0),(1079,'火花塞',119,3,1,0,NULL,NULL,0),(1080,'减震器',119,3,1,0,NULL,NULL,0),(1081,'柴机油/辅助油',119,3,1,0,NULL,NULL,0),(1082,'雨刷',119,3,1,0,NULL,NULL,0),(1083,'车灯',119,3,1,0,NULL,NULL,0),(1084,'后视镜',119,3,1,0,NULL,NULL,0),(1085,'轮胎',119,3,1,0,NULL,NULL,0),(1086,'轮毂',119,3,1,0,NULL,NULL,0),(1087,'刹车片/盘',119,3,1,0,NULL,NULL,0),(1088,'维修配件',119,3,1,0,NULL,NULL,0),(1089,'蓄电池',119,3,1,0,NULL,NULL,0),(1090,'底盘装甲/护板',119,3,1,0,NULL,NULL,0),(1091,'贴膜',119,3,1,0,NULL,NULL,0),(1092,'汽修工具',119,3,1,0,NULL,NULL,0),(1093,'改装配件',119,3,1,0,NULL,NULL,0),(1094,'导航仪',120,3,1,0,NULL,NULL,0),(1095,'安全预警仪',120,3,1,0,NULL,NULL,0),(1096,'行车记录仪',120,3,1,0,NULL,NULL,0),(1097,'倒车雷达',120,3,1,0,NULL,NULL,0),(1098,'蓝牙设备',120,3,1,0,NULL,NULL,0),(1099,'车载影音',120,3,1,0,NULL,NULL,0),(1100,'净化器',120,3,1,0,NULL,NULL,0),(1101,'电源',120,3,1,0,NULL,NULL,0),(1102,'智能驾驶',120,3,1,0,NULL,NULL,0),(1103,'车载电台',120,3,1,0,NULL,NULL,0),(1104,'车载电器配件',120,3,1,0,NULL,NULL,0),(1105,'吸尘器',120,3,1,0,NULL,NULL,0),(1106,'智能车机',120,3,1,0,NULL,NULL,0),(1107,'冰箱',120,3,1,0,NULL,NULL,0),(1108,'汽车音响',120,3,1,0,NULL,NULL,0),(1109,'车载生活电器',120,3,1,0,NULL,NULL,0),(1110,'车蜡',121,3,1,0,NULL,NULL,0),(1111,'补漆笔',121,3,1,0,NULL,NULL,0),(1112,'玻璃水',121,3,1,0,NULL,NULL,0),(1113,'清洁剂',121,3,1,0,NULL,NULL,0),(1114,'洗车工具',121,3,1,0,NULL,NULL,0),(1115,'镀晶镀膜',121,3,1,0,NULL,NULL,0),(1116,'打蜡机',121,3,1,0,NULL,NULL,0),(1117,'洗车配件',121,3,1,0,NULL,NULL,0),(1118,'洗车机',121,3,1,0,NULL,NULL,0),(1119,'洗车水枪',121,3,1,0,NULL,NULL,0),(1120,'毛巾掸子',121,3,1,0,NULL,NULL,0),(1121,'脚垫',122,3,1,0,NULL,NULL,0),(1122,'座垫',122,3,1,0,NULL,NULL,0),(1123,'座套',122,3,1,0,NULL,NULL,0),(1124,'后备箱垫',122,3,1,0,NULL,NULL,0),(1125,'头枕腰靠',122,3,1,0,NULL,NULL,0),(1126,'方向盘套',122,3,1,0,NULL,NULL,0),(1127,'香水',122,3,1,0,NULL,NULL,0),(1128,'空气净化',122,3,1,0,NULL,NULL,0),(1129,'挂件摆件',122,3,1,0,NULL,NULL,0),(1130,'功能小件',122,3,1,0,NULL,NULL,0),(1131,'车身装饰件',122,3,1,0,NULL,NULL,0),(1132,'车衣',122,3,1,0,NULL,NULL,0),(1133,'安全座椅',123,3,1,0,NULL,NULL,0),(1134,'胎压监测',123,3,1,0,NULL,NULL,0),(1135,'防盗设备',123,3,1,0,NULL,NULL,0),(1136,'应急救援',123,3,1,0,NULL,NULL,0),(1137,'保温箱',123,3,1,0,NULL,NULL,0),(1138,'地锁',123,3,1,0,NULL,NULL,0),(1139,'摩托车',123,3,1,0,NULL,NULL,0),(1140,'充气泵',123,3,1,0,NULL,NULL,0),(1141,'储物箱',123,3,1,0,NULL,NULL,0),(1142,'自驾野营',123,3,1,0,NULL,NULL,0),(1143,'摩托车装备',123,3,1,0,NULL,NULL,0),(1144,'清洗美容',124,3,1,0,NULL,NULL,0),(1145,'功能升级',124,3,1,0,NULL,NULL,0),(1146,'保养维修',124,3,1,0,NULL,NULL,0),(1147,'油卡充值',124,3,1,0,NULL,NULL,0),(1148,'车险',124,3,1,0,NULL,NULL,0),(1149,'加油卡',124,3,1,0,NULL,NULL,0),(1150,'ETC',124,3,1,0,NULL,NULL,0),(1151,'驾驶培训',124,3,1,0,NULL,NULL,0),(1152,'赛事服装',125,3,1,0,NULL,NULL,0),(1153,'赛事用品',125,3,1,0,NULL,NULL,0),(1154,'制动系统',125,3,1,0,NULL,NULL,0),(1155,'悬挂系统',125,3,1,0,NULL,NULL,0),(1156,'进气系统',125,3,1,0,NULL,NULL,0),(1157,'排气系统',125,3,1,0,NULL,NULL,0),(1158,'电子管理',125,3,1,0,NULL,NULL,0),(1159,'车身强化',125,3,1,0,NULL,NULL,0),(1160,'赛事座椅',125,3,1,0,NULL,NULL,0),(1161,'跑步鞋',126,3,1,0,NULL,NULL,0),(1162,'休闲鞋',126,3,1,0,NULL,NULL,0),(1163,'篮球鞋',126,3,1,0,NULL,NULL,0),(1164,'板鞋',126,3,1,0,NULL,NULL,0),(1165,'帆布鞋',126,3,1,0,NULL,NULL,0),(1166,'足球鞋',126,3,1,0,NULL,NULL,0),(1167,'乒羽网鞋',126,3,1,0,NULL,NULL,0),(1168,'专项运动鞋',126,3,1,0,NULL,NULL,0),(1169,'训练鞋',126,3,1,0,NULL,NULL,0),(1170,'拖鞋',126,3,1,0,NULL,NULL,0),(1171,'运动包',126,3,1,0,NULL,NULL,0),(1172,'羽绒服',127,3,1,0,NULL,NULL,0),(1173,'棉服',127,3,1,0,NULL,NULL,0),(1174,'运动裤',127,3,1,0,NULL,NULL,0),(1175,'夹克/风衣',127,3,1,0,NULL,NULL,0),(1176,'卫衣/套头衫',127,3,1,0,NULL,NULL,0),(1177,'T恤',127,3,1,0,NULL,NULL,0),(1178,'套装',127,3,1,0,NULL,NULL,0),(1179,'乒羽网服',127,3,1,0,NULL,NULL,0),(1180,'健身服',127,3,1,0,NULL,NULL,0),(1181,'运动背心',127,3,1,0,NULL,NULL,0),(1182,'毛衫/线衫',127,3,1,0,NULL,NULL,0),(1183,'运动配饰',127,3,1,0,NULL,NULL,0),(1184,'折叠车',128,3,1,0,NULL,NULL,0),(1185,'山地车/公路车',128,3,1,0,NULL,NULL,0),(1186,'电动车',128,3,1,0,NULL,NULL,0),(1187,'其他整车',128,3,1,0,NULL,NULL,0),(1188,'骑行服',128,3,1,0,NULL,NULL,0),(1189,'骑行装备',128,3,1,0,NULL,NULL,0),(1190,'平衡车',128,3,1,0,NULL,NULL,0),(1191,'鱼竿鱼线',129,3,1,0,NULL,NULL,0),(1192,'浮漂鱼饵',129,3,1,0,NULL,NULL,0),(1193,'钓鱼桌椅',129,3,1,0,NULL,NULL,0),(1194,'钓鱼配件',129,3,1,0,NULL,NULL,0),(1195,'钓箱鱼包',129,3,1,0,NULL,NULL,0),(1196,'其它',129,3,1,0,NULL,NULL,0),(1197,'泳镜',130,3,1,0,NULL,NULL,0),(1198,'泳帽',130,3,1,0,NULL,NULL,0),(1199,'游泳包防水包',130,3,1,0,NULL,NULL,0),(1200,'女士泳衣',130,3,1,0,NULL,NULL,0),(1201,'男士泳衣',130,3,1,0,NULL,NULL,0),(1202,'比基尼',130,3,1,0,NULL,NULL,0),(1203,'其它',130,3,1,0,NULL,NULL,0),(1204,'冲锋衣裤',131,3,1,0,NULL,NULL,0),(1205,'速干衣裤',131,3,1,0,NULL,NULL,0),(1206,'滑雪服',131,3,1,0,NULL,NULL,0),(1207,'羽绒服/棉服',131,3,1,0,NULL,NULL,0),(1208,'休闲衣裤',131,3,1,0,NULL,NULL,0),(1209,'抓绒衣裤',131,3,1,0,NULL,NULL,0),(1210,'软壳衣裤',131,3,1,0,NULL,NULL,0),(1211,'T恤',131,3,1,0,NULL,NULL,0),(1212,'户外风衣',131,3,1,0,NULL,NULL,0),(1213,'功能内衣',131,3,1,0,NULL,NULL,0),(1214,'军迷服饰',131,3,1,0,NULL,NULL,0),(1215,'登山鞋',131,3,1,0,NULL,NULL,0),(1216,'雪地靴',131,3,1,0,NULL,NULL,0),(1217,'徒步鞋',131,3,1,0,NULL,NULL,0),(1218,'越野跑鞋',131,3,1,0,NULL,NULL,0),(1219,'休闲鞋',131,3,1,0,NULL,NULL,0),(1220,'工装鞋',131,3,1,0,NULL,NULL,0),(1221,'溯溪鞋',131,3,1,0,NULL,NULL,0),(1222,'沙滩/凉拖',131,3,1,0,NULL,NULL,0),(1223,'户外袜',131,3,1,0,NULL,NULL,0),(1224,'帐篷/垫子',132,3,1,0,NULL,NULL,0),(1225,'睡袋/吊床',132,3,1,0,NULL,NULL,0),(1226,'登山攀岩',132,3,1,0,NULL,NULL,0),(1227,'户外配饰',132,3,1,0,NULL,NULL,0),(1228,'背包',132,3,1,0,NULL,NULL,0),(1229,'户外照明',132,3,1,0,NULL,NULL,0),(1230,'户外仪表',132,3,1,0,NULL,NULL,0),(1231,'户外工具',132,3,1,0,NULL,NULL,0),(1232,'望远镜',132,3,1,0,NULL,NULL,0),(1233,'旅游用品',132,3,1,0,NULL,NULL,0),(1234,'便携桌椅床',132,3,1,0,NULL,NULL,0),(1235,'野餐烧烤',132,3,1,0,NULL,NULL,0),(1236,'军迷用品',132,3,1,0,NULL,NULL,0),(1237,'救援装备',132,3,1,0,NULL,NULL,0),(1238,'滑雪装备',132,3,1,0,NULL,NULL,0),(1239,'极限户外',132,3,1,0,NULL,NULL,0),(1240,'冲浪潜水',132,3,1,0,NULL,NULL,0),(1241,'综合训练器',133,3,1,0,NULL,NULL,0),(1242,'其他大型器械',133,3,1,0,NULL,NULL,0),(1243,'哑铃',133,3,1,0,NULL,NULL,0),(1244,'仰卧板/收腹机',133,3,1,0,NULL,NULL,0),(1245,'其他中小型器材',133,3,1,0,NULL,NULL,0),(1246,'瑜伽舞蹈',133,3,1,0,NULL,NULL,0),(1247,'甩脂机',133,3,1,0,NULL,NULL,0),(1248,'踏步机',133,3,1,0,NULL,NULL,0),(1249,'武术搏击',133,3,1,0,NULL,NULL,0),(1250,'健身车/动感单车',133,3,1,0,NULL,NULL,0),(1251,'跑步机',133,3,1,0,NULL,NULL,0),(1252,'运动护具',133,3,1,0,NULL,NULL,0),(1253,'羽毛球',134,3,1,0,NULL,NULL,0),(1254,'乒乓球',134,3,1,0,NULL,NULL,0),(1255,'篮球',134,3,1,0,NULL,NULL,0),(1256,'足球',134,3,1,0,NULL,NULL,0),(1257,'网球',134,3,1,0,NULL,NULL,0),(1258,'排球',134,3,1,0,NULL,NULL,0),(1259,'高尔夫',134,3,1,0,NULL,NULL,0),(1260,'台球',134,3,1,0,NULL,NULL,0),(1261,'棋牌麻将',134,3,1,0,NULL,NULL,0),(1262,'轮滑滑板',134,3,1,0,NULL,NULL,0),(1263,'其他',134,3,1,0,NULL,NULL,0),(1264,'0-6个月',135,3,1,0,NULL,NULL,0),(1265,'6-12个月',135,3,1,0,NULL,NULL,0),(1266,'1-3岁',135,3,1,0,NULL,NULL,0),(1267,'3-6岁',135,3,1,0,NULL,NULL,0),(1268,'6-14岁',135,3,1,0,NULL,NULL,0),(1269,'14岁以上',135,3,1,0,NULL,NULL,0),(1270,'遥控车',136,3,1,0,NULL,NULL,0),(1271,'遥控飞机',136,3,1,0,NULL,NULL,0),(1272,'遥控船',136,3,1,0,NULL,NULL,0),(1273,'机器人',136,3,1,0,NULL,NULL,0),(1274,'轨道/助力',136,3,1,0,NULL,NULL,0),(1275,'毛绒/布艺',137,3,1,0,NULL,NULL,0),(1276,'靠垫/抱枕',137,3,1,0,NULL,NULL,0),(1277,'芭比娃娃',138,3,1,0,NULL,NULL,0),(1278,'卡通娃娃',138,3,1,0,NULL,NULL,0),(1279,'智能娃娃',138,3,1,0,NULL,NULL,0),(1280,'仿真模型',139,3,1,0,NULL,NULL,0),(1281,'拼插模型',139,3,1,0,NULL,NULL,0),(1282,'收藏爱好',139,3,1,0,NULL,NULL,0),(1283,'炫舞毯',140,3,1,0,NULL,NULL,0),(1284,'爬行垫/毯',140,3,1,0,NULL,NULL,0),(1285,'户外玩具',140,3,1,0,NULL,NULL,0),(1286,'戏水玩具',140,3,1,0,NULL,NULL,0),(1287,'电影周边',141,3,1,0,NULL,NULL,0),(1288,'卡通周边',141,3,1,0,NULL,NULL,0),(1289,'网游周边',141,3,1,0,NULL,NULL,0),(1290,'摇铃/床铃',142,3,1,0,NULL,NULL,0),(1291,'健身架',142,3,1,0,NULL,NULL,0),(1292,'早教启智',142,3,1,0,NULL,NULL,0),(1293,'拖拉玩具',142,3,1,0,NULL,NULL,0),(1294,'积木',143,3,1,0,NULL,NULL,0),(1295,'拼图',143,3,1,0,NULL,NULL,0),(1296,'磁力棒',143,3,1,0,NULL,NULL,0),(1297,'立体拼插',143,3,1,0,NULL,NULL,0),(1298,'手工彩泥',144,3,1,0,NULL,NULL,0),(1299,'绘画工具',144,3,1,0,NULL,NULL,0),(1300,'情景玩具',144,3,1,0,NULL,NULL,0),(1301,'减压玩具',145,3,1,0,NULL,NULL,0),(1302,'创意玩具',145,3,1,0,NULL,NULL,0),(1303,'钢琴',146,3,1,0,NULL,NULL,0),(1304,'电子琴/电钢琴',146,3,1,0,NULL,NULL,0),(1305,'吉他/尤克里里',146,3,1,0,NULL,NULL,0),(1306,'打击乐器',146,3,1,0,NULL,NULL,0),(1307,'西洋管弦',146,3,1,0,NULL,NULL,0),(1308,'民族管弦乐器',146,3,1,0,NULL,NULL,0),(1309,'乐器配件',146,3,1,0,NULL,NULL,0),(1310,'电脑音乐',146,3,1,0,NULL,NULL,0),(1311,'工艺礼品乐器',146,3,1,0,NULL,NULL,0),(1312,'口琴/口风琴/竖笛',146,3,1,0,NULL,NULL,0),(1313,'手风琴',146,3,1,0,NULL,NULL,0),(1314,'双色球',147,3,1,0,NULL,NULL,0),(1315,'大乐透',147,3,1,0,NULL,NULL,0),(1316,'福彩3D',147,3,1,0,NULL,NULL,0),(1317,'排列三',147,3,1,0,NULL,NULL,0),(1318,'排列五',147,3,1,0,NULL,NULL,0),(1319,'七星彩',147,3,1,0,NULL,NULL,0),(1320,'七乐彩',147,3,1,0,NULL,NULL,0),(1321,'竞彩足球',147,3,1,0,NULL,NULL,0),(1322,'竞彩篮球',147,3,1,0,NULL,NULL,0),(1323,'新时时彩',147,3,1,0,NULL,NULL,0),(1324,'国内机票',148,3,1,0,NULL,NULL,0),(1325,'国内酒店',149,3,1,0,NULL,NULL,0),(1326,'酒店团购',149,3,1,0,NULL,NULL,0),(1327,'度假',150,3,1,0,NULL,NULL,0),(1328,'景点',150,3,1,0,NULL,NULL,0),(1329,'租车',150,3,1,0,NULL,NULL,0),(1330,'火车票',150,3,1,0,NULL,NULL,0),(1331,'旅游团购',150,3,1,0,NULL,NULL,0),(1332,'手机充值',151,3,1,0,NULL,NULL,0),(1333,'游戏点卡',152,3,1,0,NULL,NULL,0),(1334,'QQ充值',152,3,1,0,NULL,NULL,0),(1335,'电影票',153,3,1,0,NULL,NULL,0),(1336,'演唱会',153,3,1,0,NULL,NULL,0),(1337,'话剧歌剧',153,3,1,0,NULL,NULL,0),(1338,'音乐会',153,3,1,0,NULL,NULL,0),(1339,'体育赛事',153,3,1,0,NULL,NULL,0),(1340,'舞蹈芭蕾',153,3,1,0,NULL,NULL,0),(1341,'戏曲综艺',153,3,1,0,NULL,NULL,0),(1342,'东北',154,3,1,0,NULL,NULL,0),(1343,'华北',154,3,1,0,NULL,NULL,0),(1344,'西北',154,3,1,0,NULL,NULL,0),(1345,'华中',154,3,1,0,NULL,NULL,0),(1346,'华东',154,3,1,0,NULL,NULL,0),(1347,'华南',154,3,1,0,NULL,NULL,0),(1348,'西南',154,3,1,0,NULL,NULL,0),(1349,'苹果',155,3,1,0,NULL,NULL,0),(1350,'橙子',155,3,1,0,NULL,NULL,0),(1351,'奇异果/猕猴桃',155,3,1,0,NULL,NULL,0),(1352,'车厘子/樱桃',155,3,1,0,NULL,NULL,0),(1353,'芒果',155,3,1,0,NULL,NULL,0),(1354,'蓝莓',155,3,1,0,NULL,NULL,0),(1355,'火龙果',155,3,1,0,NULL,NULL,0),(1356,'葡萄/提子',155,3,1,0,NULL,NULL,0),(1357,'柚子',155,3,1,0,NULL,NULL,0),(1358,'香蕉',155,3,1,0,NULL,NULL,0),(1359,'牛油果',155,3,1,0,NULL,NULL,0),(1360,'梨',155,3,1,0,NULL,NULL,0),(1361,'菠萝/凤梨',155,3,1,0,NULL,NULL,0),(1362,'桔/橘',155,3,1,0,NULL,NULL,0),(1363,'柠檬',155,3,1,0,NULL,NULL,0),(1364,'草莓',155,3,1,0,NULL,NULL,0),(1365,'桃/李/杏',155,3,1,0,NULL,NULL,0),(1366,'更多水果',155,3,1,0,NULL,NULL,0),(1367,'水果礼盒/券',155,3,1,0,NULL,NULL,0),(1368,'牛肉',156,3,1,0,NULL,NULL,0),(1369,'羊肉',156,3,1,0,NULL,NULL,0),(1370,'猪肉',156,3,1,0,NULL,NULL,0),(1371,'内脏类',156,3,1,0,NULL,NULL,0),(1372,'鱼类',157,3,1,0,NULL,NULL,0),(1373,'虾类',157,3,1,0,NULL,NULL,0),(1374,'蟹类',157,3,1,0,NULL,NULL,0),(1375,'贝类',157,3,1,0,NULL,NULL,0),(1376,'海参',157,3,1,0,NULL,NULL,0),(1377,'海产干货',157,3,1,0,NULL,NULL,0),(1378,'其他水产',157,3,1,0,NULL,NULL,0),(1379,'海产礼盒',157,3,1,0,NULL,NULL,0),(1380,'鸡肉',158,3,1,0,NULL,NULL,0),(1381,'鸭肉',158,3,1,0,NULL,NULL,0),(1382,'蛋类',158,3,1,0,NULL,NULL,0),(1383,'其他禽类',158,3,1,0,NULL,NULL,0),(1384,'水饺/馄饨',159,3,1,0,NULL,NULL,0),(1385,'汤圆/元宵',159,3,1,0,NULL,NULL,0),(1386,'面点',159,3,1,0,NULL,NULL,0),(1387,'火锅丸串',159,3,1,0,NULL,NULL,0),(1388,'速冻半成品',159,3,1,0,NULL,NULL,0),(1389,'奶酪黄油',159,3,1,0,NULL,NULL,0),(1390,'熟食',160,3,1,0,NULL,NULL,0),(1391,'腊肠/腊肉',160,3,1,0,NULL,NULL,0),(1392,'火腿',160,3,1,0,NULL,NULL,0),(1393,'糕点',160,3,1,0,NULL,NULL,0),(1394,'礼品卡券',160,3,1,0,NULL,NULL,0),(1395,'冷藏果蔬汁',161,3,1,0,NULL,NULL,0),(1396,'冰激凌',161,3,1,0,NULL,NULL,0),(1397,'其他',161,3,1,0,NULL,NULL,0),(1398,'叶菜类',162,3,1,0,NULL,NULL,0),(1399,'茄果瓜类',162,3,1,0,NULL,NULL,0),(1400,'根茎类',162,3,1,0,NULL,NULL,0),(1401,'鲜菌菇',162,3,1,0,NULL,NULL,0),(1402,'葱姜蒜椒',162,3,1,0,NULL,NULL,0),(1403,'半加工蔬菜',162,3,1,0,NULL,NULL,0),(1404,'微型车',163,3,1,0,NULL,NULL,0),(1405,'小型车',163,3,1,0,NULL,NULL,0),(1406,'紧凑型车',163,3,1,0,NULL,NULL,0),(1407,'中型车',163,3,1,0,NULL,NULL,0),(1408,'中大型车',163,3,1,0,NULL,NULL,0),(1409,'豪华车',163,3,1,0,NULL,NULL,0),(1410,'MPV',163,3,1,0,NULL,NULL,0),(1411,'SUV',163,3,1,0,NULL,NULL,0),(1412,'跑车',163,3,1,0,NULL,NULL,0),(1413,'微型车（二手）',164,3,1,0,NULL,NULL,0),(1414,'小型车（二手）',164,3,1,0,NULL,NULL,0),(1415,'紧凑型车（二手）',164,3,1,0,NULL,NULL,0),(1416,'中型车（二手）',164,3,1,0,NULL,NULL,0),(1417,'中大型车（二手）',164,3,1,0,NULL,NULL,0),(1418,'豪华车（二手）',164,3,1,0,NULL,NULL,0),(1419,'MPV（二手）',164,3,1,0,NULL,NULL,0),(1420,'SUV（二手）',164,3,1,0,NULL,NULL,0),(1421,'跑车（二手）',164,3,1,0,NULL,NULL,0),(1422,'皮卡（二手）',164,3,1,0,NULL,NULL,0),(1423,'面包车（二手）',164,3,1,0,NULL,NULL,0),(1431,'dsa323',1,2,1,12,NULL,NULL,NULL),(1432,'fdsffdsadddd大萨达',1431,3,1,NULL,NULL,NULL,NULL),(100003,'122',0,0,1,22,NULL,NULL,NULL),(100004,'23',100004,2,1,0,NULL,NULL,NULL),(100005,'2',100003,1,1,0,NULL,NULL,NULL),(100006,'322',100005,3,0,3,NULL,NULL,NULL),(100007,'4444',100005,2,0,0,NULL,NULL,NULL),(100008,'5',100005,2,0,1,NULL,NULL,NULL),(100009,'6',100005,2,0,2,NULL,NULL,NULL),(100010,'1234',0,2,0,24,NULL,NULL,NULL),(100011,'33',100005,3,0,4,'1','1',NULL);
/*!40000 ALTER TABLE `pms_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_category_brand_relation`
--

DROP TABLE IF EXISTS `pms_category_brand_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_category_brand_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `brand_id` bigint DEFAULT NULL COMMENT '品牌id',
  `catelog_id` bigint DEFAULT NULL COMMENT '分类id',
  `brand_name` varchar(255) DEFAULT NULL,
  `catelog_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='品牌分类关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_category_brand_relation`
--

LOCK TABLES `pms_category_brand_relation` WRITE;
/*!40000 ALTER TABLE `pms_category_brand_relation` DISABLE KEYS */;
INSERT INTO `pms_category_brand_relation` VALUES (4,2,225,'华为','手机'),(5,12,225,'小米','手机');
/*!40000 ALTER TABLE `pms_category_brand_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_comment_replay`
--

DROP TABLE IF EXISTS `pms_comment_replay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_comment_replay` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `comment_id` bigint DEFAULT NULL COMMENT '评论id',
  `reply_id` bigint DEFAULT NULL COMMENT '回复id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价回复关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_comment_replay`
--

LOCK TABLES `pms_comment_replay` WRITE;
/*!40000 ALTER TABLE `pms_comment_replay` DISABLE KEYS */;
/*!40000 ALTER TABLE `pms_comment_replay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_product_attr_value`
--

DROP TABLE IF EXISTS `pms_product_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_product_attr_value` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint DEFAULT NULL COMMENT '商品id',
  `attr_id` bigint DEFAULT NULL COMMENT '属性id',
  `attr_name` varchar(200) DEFAULT NULL COMMENT '属性名',
  `attr_value` varchar(200) DEFAULT NULL COMMENT '属性值',
  `attr_sort` int DEFAULT NULL COMMENT '顺序',
  `quick_show` tinyint DEFAULT NULL COMMENT '快速展示【是否展示在介绍上；0-否 1-是】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='spu属性值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_product_attr_value`
--

LOCK TABLES `pms_product_attr_value` WRITE;
/*!40000 ALTER TABLE `pms_product_attr_value` DISABLE KEYS */;
INSERT INTO `pms_product_attr_value` VALUES (162,24,12,'入网型号','C3J',NULL,1),(163,24,13,'上市年份','2025',NULL,1),(164,24,14,'机身颜色','白色;黑色;冷烟紫;森野绿',NULL,1),(165,24,15,'机身材料','以官网信息为准',NULL,1),(166,24,16,'机身材质工艺','以官网信息为准',NULL,1),(167,24,17,'机身长度（mm）','以官网信息为准',NULL,1),(168,24,18,'芯片工艺','以官网信息为准',NULL,1),(193,17,12,'入网型号','C3J',NULL,1),(194,17,13,'上市年份','2025',NULL,1),(195,17,14,'机身颜色','曜石黑; 雪域白; 云杉绿;晨曦金',NULL,1),(196,17,16,'机身材质工艺','以官网信息为准',NULL,1),(197,17,17,'机身长度（mm）','以官网信息为准',NULL,1),(198,17,18,'芯片工艺','以官网信息为准',NULL,1);
/*!40000 ALTER TABLE `pms_product_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_sku_images`
--

DROP TABLE IF EXISTS `pms_sku_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_sku_images` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `img_sort` int DEFAULT NULL COMMENT '排序',
  `default_img` int DEFAULT NULL COMMENT '默认图[0 - 不是默认图，1 - 是默认图]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='sku图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_sku_images`
--

LOCK TABLES `pms_sku_images` WRITE;
/*!40000 ALTER TABLE `pms_sku_images` DISABLE KEYS */;
INSERT INTO `pms_sku_images` VALUES (28,50,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif',NULL,1),(29,51,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif',NULL,1),(30,52,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif',NULL,1),(31,53,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif',NULL,1),(32,54,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif',NULL,1),(33,55,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif',NULL,1),(34,56,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif',NULL,1),(35,57,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif',NULL,1),(36,58,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif',NULL,1),(37,59,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif',NULL,1),(38,60,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif',NULL,1),(39,61,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif',NULL,1),(46,68,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,1),(47,69,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,1),(48,70,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,1),(49,71,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,1),(50,72,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,1),(51,73,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,1),(52,74,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,1),(53,75,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,1),(54,76,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,1),(55,77,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,1),(56,78,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,1),(57,79,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,1),(58,80,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,1),(59,81,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,1),(60,82,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,1),(61,83,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,1);
/*!40000 ALTER TABLE `pms_sku_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_sku_info`
--

DROP TABLE IF EXISTS `pms_sku_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_sku_info` (
  `sku_id` bigint NOT NULL AUTO_INCREMENT COMMENT 'skuId',
  `spu_id` bigint DEFAULT NULL COMMENT 'spuId',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku名称',
  `sku_desc` varchar(2000) DEFAULT NULL COMMENT 'sku介绍描述',
  `catalog_id` bigint DEFAULT NULL COMMENT '所属分类id',
  `brand_id` bigint DEFAULT NULL COMMENT '品牌id',
  `sku_default_img` varchar(255) DEFAULT NULL COMMENT '默认图片',
  `sku_title` varchar(255) DEFAULT NULL COMMENT '标题',
  `sku_subtitle` varchar(2000) DEFAULT NULL COMMENT '副标题',
  `price` decimal(18,4) DEFAULT NULL COMMENT '价格',
  `sale_count` bigint DEFAULT NULL COMMENT '销量',
  PRIMARY KEY (`sku_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='sku信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_sku_info`
--

LOCK TABLES `pms_sku_info` WRITE;
/*!40000 ALTER TABLE `pms_sku_info` DISABLE KEYS */;
INSERT INTO `pms_sku_info` VALUES (50,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5499.0000,NULL),(51,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 12GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 12GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5199.0000,NULL),(52,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 12GB+256GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 12GB+256GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',4999.0000,NULL),(53,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 16GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 16GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5499.0000,NULL),(54,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 12GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 12GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5199.0000,NULL),(55,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 12GB+256GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  雪域白 12GB+256GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',4999.0000,NULL),(56,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 16GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 16GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5499.0000,NULL),(57,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 12GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 12GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5199.0000,NULL),(58,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 12GB+256GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机  云杉绿 12GB+256GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',4999.0000,NULL),(59,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 16GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 16GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5499.0000,NULL),(60,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 12GB+512GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 12GB+512GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',5199.0000,NULL),(61,17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 12GB+256GB',NULL,225,2,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 晨曦金 12GB+256GB','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 ',4999.0000,NULL),(68,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色  12GB+256GB','白色, 12GB+256GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色  12GB+256GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(69,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 12GB+512GB ','白色,12GB+512GB ',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 12GB+512GB ','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(70,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 16GB+512GB','白色,16GB+512GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 16GB+512GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(71,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 16GB+1TB','白色,16GB+1TB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 白色 16GB+1TB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(72,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色  12GB+256GB','黑色, 12GB+256GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色  12GB+256GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(73,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 12GB+512GB ','黑色,12GB+512GB ',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 12GB+512GB ','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(74,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 16GB+512GB','黑色,16GB+512GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 16GB+512GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(75,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 16GB+1TB','黑色,16GB+1TB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 黑色 16GB+1TB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(76,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫  12GB+256GB','冷烟紫, 12GB+256GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫  12GB+256GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(77,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 12GB+512GB ','冷烟紫,12GB+512GB ',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 12GB+512GB ','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(78,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 16GB+512GB','冷烟紫,16GB+512GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 16GB+512GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(79,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 16GB+1TB','冷烟紫,16GB+1TB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 冷烟紫 16GB+1TB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(80,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿  12GB+256GB','森野绿, 12GB+256GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿  12GB+256GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(81,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 12GB+512GB ','森野绿,12GB+512GB ',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 12GB+512GB ','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(82,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 16GB+512GB','森野绿,16GB+512GB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 16GB+512GB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL),(83,24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 16GB+1TB','森野绿,16GB+1TB',225,12,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 森野绿 16GB+1TB','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机 ',5099.0000,NULL);
/*!40000 ALTER TABLE `pms_sku_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_sku_sale_attr_value`
--

DROP TABLE IF EXISTS `pms_sku_sale_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_sku_sale_attr_value` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `attr_id` bigint DEFAULT NULL COMMENT 'attr_id',
  `attr_name` varchar(200) DEFAULT NULL COMMENT '销售属性名',
  `attr_value` varchar(200) DEFAULT NULL COMMENT '销售属性值',
  `attr_sort` int DEFAULT NULL COMMENT '顺序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='sku销售属性&值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_sku_sale_attr_value`
--

LOCK TABLES `pms_sku_sale_attr_value` WRITE;
/*!40000 ALTER TABLE `pms_sku_sale_attr_value` DISABLE KEYS */;
INSERT INTO `pms_sku_sale_attr_value` VALUES (99,50,19,'颜色','曜石黑',NULL),(100,50,21,'版本','16GB+512GB',NULL),(101,51,19,'颜色','曜石黑',NULL),(102,51,21,'版本','12GB+512GB',NULL),(103,52,19,'颜色','曜石黑',NULL),(104,52,21,'版本','12GB+256GB',NULL),(105,53,19,'颜色',' 雪域白',NULL),(106,53,21,'版本','16GB+512GB',NULL),(107,54,19,'颜色',' 雪域白',NULL),(108,54,21,'版本','12GB+512GB',NULL),(109,55,19,'颜色',' 雪域白',NULL),(110,55,21,'版本','12GB+256GB',NULL),(111,56,19,'颜色',' 云杉绿',NULL),(112,56,21,'版本','16GB+512GB',NULL),(113,57,19,'颜色',' 云杉绿',NULL),(114,57,21,'版本','12GB+512GB',NULL),(115,58,19,'颜色',' 云杉绿',NULL),(116,58,21,'版本','12GB+256GB',NULL),(117,59,19,'颜色','晨曦金',NULL),(118,59,21,'版本','16GB+512GB',NULL),(119,60,19,'颜色','晨曦金',NULL),(120,60,21,'版本','12GB+512GB',NULL),(121,61,19,'颜色','晨曦金',NULL),(122,61,21,'版本','12GB+256GB',NULL),(135,68,19,'颜色','白色',NULL),(136,68,21,'版本',' 12GB+256GB',NULL),(137,69,19,'颜色','白色',NULL),(138,69,21,'版本','12GB+512GB ',NULL),(139,70,19,'颜色','白色',NULL),(140,70,21,'版本','16GB+512GB',NULL),(141,71,19,'颜色','白色',NULL),(142,71,21,'版本','16GB+1TB',NULL),(143,72,19,'颜色','黑色',NULL),(144,72,21,'版本',' 12GB+256GB',NULL),(145,73,19,'颜色','黑色',NULL),(146,73,21,'版本','12GB+512GB ',NULL),(147,74,19,'颜色','黑色',NULL),(148,74,21,'版本','16GB+512GB',NULL),(149,75,19,'颜色','黑色',NULL),(150,75,21,'版本','16GB+1TB',NULL),(151,76,19,'颜色','冷烟紫',NULL),(152,76,21,'版本',' 12GB+256GB',NULL),(153,77,19,'颜色','冷烟紫',NULL),(154,77,21,'版本','12GB+512GB ',NULL),(155,78,19,'颜色','冷烟紫',NULL),(156,78,21,'版本','16GB+512GB',NULL),(157,79,19,'颜色','冷烟紫',NULL),(158,79,21,'版本','16GB+1TB',NULL),(159,80,19,'颜色','森野绿',NULL),(160,80,21,'版本',' 12GB+256GB',NULL),(161,81,19,'颜色','森野绿',NULL),(162,81,21,'版本','12GB+512GB ',NULL),(163,82,19,'颜色','森野绿',NULL),(164,82,21,'版本','16GB+512GB',NULL),(165,83,19,'颜色','森野绿',NULL),(166,83,21,'版本','16GB+1TB',NULL);
/*!40000 ALTER TABLE `pms_sku_sale_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_spu_comment`
--

DROP TABLE IF EXISTS `pms_spu_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_spu_comment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `member_nick_name` varchar(255) DEFAULT NULL COMMENT '会员昵称',
  `star` tinyint(1) DEFAULT NULL COMMENT '星级',
  `member_ip` varchar(64) DEFAULT NULL COMMENT '会员ip',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `show_status` tinyint(1) DEFAULT NULL COMMENT '显示状态[0-不显示，1-显示]',
  `spu_attributes` varchar(255) DEFAULT NULL COMMENT '购买时属性组合',
  `likes_count` int DEFAULT NULL COMMENT '点赞数',
  `reply_count` int DEFAULT NULL COMMENT '回复数',
  `resources` varchar(1000) DEFAULT NULL COMMENT '评论图片/视频[json数据；[{type:文件类型,url:资源路径}]]',
  `content` text COMMENT '内容',
  `member_icon` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `comment_type` tinyint DEFAULT NULL COMMENT '评论类型[0 - 对商品的直接评论，1 - 对评论的回复]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_spu_comment`
--

LOCK TABLES `pms_spu_comment` WRITE;
/*!40000 ALTER TABLE `pms_spu_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `pms_spu_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_spu_images`
--

DROP TABLE IF EXISTS `pms_spu_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_spu_images` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `img_name` varchar(200) DEFAULT NULL COMMENT '图片名',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `img_sort` int DEFAULT NULL COMMENT '顺序',
  `default_img` tinyint DEFAULT NULL COMMENT '是否默认图',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='spu图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_spu_images`
--

LOCK TABLES `pms_spu_images` WRITE;
/*!40000 ALTER TABLE `pms_spu_images` DISABLE KEYS */;
INSERT INTO `pms_spu_images` VALUES (65,17,'2026-01-05_rQ7emuUiX0K3Oh9p.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif',NULL,NULL),(66,17,'2026-01-05_8caYZgSIgideUjxT.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif',NULL,NULL),(67,17,'2026-01-05_LJTVTW1p97UavkCA.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif',NULL,NULL),(68,17,'2026-01-05_cvK8jcQbexVEEONX.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif',NULL,NULL),(93,24,'2026-01-07_XPxSWjrnS9Tpmw0f.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,NULL),(94,24,'2026-01-07_2xXUsmHZXjsMLLVq.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,NULL),(95,24,'2026-01-07_rkdjjdA1M2MGBJc0.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,NULL),(96,24,'2026-01-07_pUHWUVVmBsEu2rKC.avif','https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,NULL);
/*!40000 ALTER TABLE `pms_spu_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_spu_info`
--

DROP TABLE IF EXISTS `pms_spu_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_spu_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `spu_name` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `spu_description` varchar(1000) DEFAULT NULL COMMENT '商品描述',
  `catalog_id` bigint DEFAULT NULL COMMENT '所属分类id',
  `brand_id` bigint DEFAULT NULL COMMENT '品牌id',
  `weight` decimal(18,4) DEFAULT NULL,
  `publish_status` tinyint DEFAULT NULL COMMENT '上架状态[0 - 下架，1 - 上架]',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='spu信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_spu_info`
--

LOCK TABLES `pms_spu_info` WRITE;
/*!40000 ALTER TABLE `pms_spu_info` DISABLE KEYS */;
INSERT INTO `pms_spu_info` VALUES (17,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机','HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机',225,2,1.0000,0,'2026-01-06 13:43:52','2026-01-06 13:43:52'),(24,'小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机','小米（MI）小米 17 Pro 妙享背屏 光影大师 第五代骁龙8至尊版 5G手机',225,12,1.0000,0,'2026-01-07 13:51:32','2026-01-07 13:51:32');
/*!40000 ALTER TABLE `pms_spu_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pms_spu_info_desc`
--

DROP TABLE IF EXISTS `pms_spu_info_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pms_spu_info_desc` (
  `spu_id` bigint NOT NULL COMMENT '商品id',
  `decript` longtext COMMENT '商品介绍',
  PRIMARY KEY (`spu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='spu信息介绍';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pms_spu_info_desc`
--

LOCK TABLES `pms_spu_info_desc` WRITE;
/*!40000 ALTER TABLE `pms_spu_info_desc` DISABLE KEYS */;
INSERT INTO `pms_spu_info_desc` VALUES (17,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_lKd8Vk7N1BRpZqkL.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_fSs8SEcBtFLYtABE.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_5u0SuwKN4wcCpiX5.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_ZGTTHIyLbKfhwQRT.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_7vO03SlJZ0BwnWNq.avif'),(24,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_51azfdyCZzRj0Lbp.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_dzdE2OuhbI8OA2aG.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_ZJt3i4b77ZRyWsAP.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_M3ZeCV9Rje0xUEJP.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_WDoP0iQrtAn4eUme.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_uFoon0ndy1epUI8C.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_8XPwDYQ2hMBgwUIV.avif,https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_tmIl6qJGBLPqfcvm.avif');
/*!40000 ALTER TABLE `pms_spu_info_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc-sms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-sms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-sms`;

--
-- Table structure for table `sms_coupon`
--

DROP TABLE IF EXISTS `sms_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_type` tinyint(1) DEFAULT NULL COMMENT '优惠卷类型[0->全场赠券；1->会员赠券；2->购物赠券；3->注册赠券]',
  `coupon_img` varchar(2000) DEFAULT NULL COMMENT '优惠券图片',
  `coupon_name` varchar(100) DEFAULT NULL COMMENT '优惠卷名字',
  `num` int DEFAULT NULL COMMENT '数量',
  `amount` decimal(18,4) DEFAULT NULL COMMENT '金额',
  `per_limit` int DEFAULT NULL COMMENT '每人限领张数',
  `min_point` decimal(18,4) DEFAULT NULL COMMENT '使用门槛',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `use_type` tinyint(1) DEFAULT NULL COMMENT '使用类型[0->全场通用；1->指定分类；2->指定商品]',
  `note` varchar(200) DEFAULT NULL COMMENT '备注',
  `publish_count` int DEFAULT NULL COMMENT '发行数量',
  `use_count` int DEFAULT NULL COMMENT '已使用数量',
  `receive_count` int DEFAULT NULL COMMENT '领取数量',
  `enable_start_time` datetime DEFAULT NULL COMMENT '可以领取的开始日期',
  `enable_end_time` datetime DEFAULT NULL COMMENT '可以领取的结束日期',
  `code` varchar(64) DEFAULT NULL COMMENT '优惠码',
  `member_level` tinyint(1) DEFAULT NULL COMMENT '可以领取的会员等级[0->不限等级，其他-对应等级]',
  `publish` tinyint(1) DEFAULT NULL COMMENT '发布状态[0-未发布，1-已发布]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_coupon`
--

LOCK TABLES `sms_coupon` WRITE;
/*!40000 ALTER TABLE `sms_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_coupon_history`
--

DROP TABLE IF EXISTS `sms_coupon_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_coupon_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint DEFAULT NULL COMMENT '优惠券id',
  `member_id` bigint DEFAULT NULL COMMENT '会员id',
  `member_nick_name` varchar(64) DEFAULT NULL COMMENT '会员名字',
  `get_type` tinyint(1) DEFAULT NULL COMMENT '获取方式[0->后台赠送；1->主动领取]',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `use_type` tinyint(1) DEFAULT NULL COMMENT '使用状态[0->未使用；1->已使用；2->已过期]',
  `use_time` datetime DEFAULT NULL COMMENT '使用时间',
  `order_id` bigint DEFAULT NULL COMMENT '订单id',
  `order_sn` bigint DEFAULT NULL COMMENT '订单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券领取历史记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_coupon_history`
--

LOCK TABLES `sms_coupon_history` WRITE;
/*!40000 ALTER TABLE `sms_coupon_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_coupon_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_coupon_spu_category_relation`
--

DROP TABLE IF EXISTS `sms_coupon_spu_category_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_coupon_spu_category_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint DEFAULT NULL COMMENT '优惠券id',
  `category_id` bigint DEFAULT NULL COMMENT '产品分类id',
  `category_name` varchar(64) DEFAULT NULL COMMENT '产品分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券分类关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_coupon_spu_category_relation`
--

LOCK TABLES `sms_coupon_spu_category_relation` WRITE;
/*!40000 ALTER TABLE `sms_coupon_spu_category_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_coupon_spu_category_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_coupon_spu_relation`
--

DROP TABLE IF EXISTS `sms_coupon_spu_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_coupon_spu_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint DEFAULT NULL COMMENT '优惠券id',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT 'spu_name',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券与产品关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_coupon_spu_relation`
--

LOCK TABLES `sms_coupon_spu_relation` WRITE;
/*!40000 ALTER TABLE `sms_coupon_spu_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_coupon_spu_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_home_adv`
--

DROP TABLE IF EXISTS `sms_home_adv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_home_adv` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(100) DEFAULT NULL COMMENT '名字',
  `pic` varchar(500) DEFAULT NULL COMMENT '图片地址',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `click_count` int DEFAULT NULL COMMENT '点击数',
  `url` varchar(500) DEFAULT NULL COMMENT '广告详情连接地址',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  `sort` int DEFAULT NULL COMMENT '排序',
  `publisher_id` bigint DEFAULT NULL COMMENT '发布者',
  `auth_id` bigint DEFAULT NULL COMMENT '审核者',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='首页轮播广告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_home_adv`
--

LOCK TABLES `sms_home_adv` WRITE;
/*!40000 ALTER TABLE `sms_home_adv` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_home_adv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_home_subject`
--

DROP TABLE IF EXISTS `sms_home_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_home_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '专题名字',
  `title` varchar(255) DEFAULT NULL COMMENT '专题标题',
  `sub_title` varchar(255) DEFAULT NULL COMMENT '专题副标题',
  `status` tinyint(1) DEFAULT NULL COMMENT '显示状态',
  `url` varchar(500) DEFAULT NULL COMMENT '详情连接',
  `sort` int DEFAULT NULL COMMENT '排序',
  `img` varchar(500) DEFAULT NULL COMMENT '专题图片地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='首页专题表【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_home_subject`
--

LOCK TABLES `sms_home_subject` WRITE;
/*!40000 ALTER TABLE `sms_home_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_home_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_home_subject_spu`
--

DROP TABLE IF EXISTS `sms_home_subject_spu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_home_subject_spu` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '专题名字',
  `subject_id` bigint DEFAULT NULL COMMENT '专题id',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `sort` int DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='专题商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_home_subject_spu`
--

LOCK TABLES `sms_home_subject_spu` WRITE;
/*!40000 ALTER TABLE `sms_home_subject_spu` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_home_subject_spu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_member_price`
--

DROP TABLE IF EXISTS `sms_member_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_member_price` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `member_level_id` bigint DEFAULT NULL COMMENT '会员等级id',
  `member_level_name` varchar(100) DEFAULT NULL COMMENT '会员等级名',
  `member_price` decimal(18,4) DEFAULT NULL COMMENT '会员对应价格',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '可否叠加其他优惠[0-不可叠加优惠，1-可叠加]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品会员价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_member_price`
--

LOCK TABLES `sms_member_price` WRITE;
/*!40000 ALTER TABLE `sms_member_price` DISABLE KEYS */;
INSERT INTO `sms_member_price` VALUES (4,68,2,'铜牌会员',4999.0000,1),(5,68,3,'银牌会员',4899.0000,1),(6,68,4,'铂金会员',4799.0000,1),(7,69,2,'铜牌会员',4999.0000,1),(8,69,3,'银牌会员',4899.0000,1),(9,69,4,'铂金会员',4799.0000,1),(10,70,2,'铜牌会员',4999.0000,1),(11,70,3,'银牌会员',4899.0000,1),(12,70,4,'铂金会员',4799.0000,1),(13,71,2,'铜牌会员',4999.0000,1),(14,71,3,'银牌会员',4899.0000,1),(15,71,4,'铂金会员',4799.0000,1),(16,72,2,'铜牌会员',4999.0000,1),(17,72,3,'银牌会员',4899.0000,1),(18,72,4,'铂金会员',4799.0000,1),(19,73,2,'铜牌会员',4999.0000,1),(20,73,3,'银牌会员',4899.0000,1),(21,73,4,'铂金会员',4799.0000,1),(22,74,2,'铜牌会员',4999.0000,1),(23,74,3,'银牌会员',4899.0000,1),(24,74,4,'铂金会员',4799.0000,1),(25,75,2,'铜牌会员',4999.0000,1),(26,75,3,'银牌会员',4899.0000,1),(27,75,4,'铂金会员',4799.0000,1),(28,76,2,'铜牌会员',4999.0000,1),(29,76,3,'银牌会员',4899.0000,1),(30,76,4,'铂金会员',4799.0000,1),(31,77,2,'铜牌会员',4999.0000,1),(32,77,3,'银牌会员',4899.0000,1),(33,77,4,'铂金会员',4799.0000,1),(34,78,2,'铜牌会员',4999.0000,1),(35,78,3,'银牌会员',4899.0000,1),(36,78,4,'铂金会员',4799.0000,1),(37,79,2,'铜牌会员',4999.0000,1),(38,79,3,'银牌会员',4899.0000,1),(39,79,4,'铂金会员',4799.0000,1);
/*!40000 ALTER TABLE `sms_member_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_seckill_promotion`
--

DROP TABLE IF EXISTS `sms_seckill_promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_seckill_promotion` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(255) DEFAULT NULL COMMENT '活动标题',
  `start_time` datetime DEFAULT NULL COMMENT '开始日期',
  `end_time` datetime DEFAULT NULL COMMENT '结束日期',
  `status` tinyint DEFAULT NULL COMMENT '上下线状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `user_id` bigint DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_seckill_promotion`
--

LOCK TABLES `sms_seckill_promotion` WRITE;
/*!40000 ALTER TABLE `sms_seckill_promotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_seckill_promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_seckill_session`
--

DROP TABLE IF EXISTS `sms_seckill_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_seckill_session` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '场次名称',
  `start_time` datetime DEFAULT NULL COMMENT '每日开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '每日结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '启用状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀活动场次';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_seckill_session`
--

LOCK TABLES `sms_seckill_session` WRITE;
/*!40000 ALTER TABLE `sms_seckill_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_seckill_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_seckill_sku_notice`
--

DROP TABLE IF EXISTS `sms_seckill_sku_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_seckill_sku_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `session_id` bigint DEFAULT NULL COMMENT '活动场次id',
  `subcribe_time` datetime DEFAULT NULL COMMENT '订阅时间',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `notice_type` tinyint(1) DEFAULT NULL COMMENT '通知方式[0-短信，1-邮件]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀商品通知订阅';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_seckill_sku_notice`
--

LOCK TABLES `sms_seckill_sku_notice` WRITE;
/*!40000 ALTER TABLE `sms_seckill_sku_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_seckill_sku_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_seckill_sku_relation`
--

DROP TABLE IF EXISTS `sms_seckill_sku_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_seckill_sku_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `promotion_id` bigint DEFAULT NULL COMMENT '活动id',
  `promotion_session_id` bigint DEFAULT NULL COMMENT '活动场次id',
  `sku_id` bigint DEFAULT NULL COMMENT '商品id',
  `seckill_price` decimal(10,0) DEFAULT NULL COMMENT '秒杀价格',
  `seckill_count` decimal(10,0) DEFAULT NULL COMMENT '秒杀总量',
  `seckill_limit` decimal(10,0) DEFAULT NULL COMMENT '每人限购数量',
  `seckill_sort` int DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀活动商品关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_seckill_sku_relation`
--

LOCK TABLES `sms_seckill_sku_relation` WRITE;
/*!40000 ALTER TABLE `sms_seckill_sku_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_seckill_sku_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_sku_full_reduction`
--

DROP TABLE IF EXISTS `sms_sku_full_reduction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_sku_full_reduction` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `full_price` decimal(18,4) DEFAULT NULL COMMENT '满多少',
  `reduce_price` decimal(18,4) DEFAULT NULL COMMENT '减多少',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '是否参与其他优惠',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品满减信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_sku_full_reduction`
--

LOCK TABLES `sms_sku_full_reduction` WRITE;
/*!40000 ALTER TABLE `sms_sku_full_reduction` DISABLE KEYS */;
INSERT INTO `sms_sku_full_reduction` VALUES (49,50,10000.0000,50.0000,1),(50,51,10000.0000,50.0000,1),(51,52,10000.0000,50.0000,1),(52,53,10000.0000,50.0000,1),(53,54,10000.0000,50.0000,1),(54,55,10000.0000,50.0000,1),(55,56,10000.0000,50.0000,1),(56,57,10000.0000,50.0000,1),(57,58,10000.0000,50.0000,0),(58,59,10000.0000,50.0000,1),(59,60,10000.0000,50.0000,1),(60,61,10000.0000,50.0000,1),(62,68,10000.0000,10.0000,1),(63,69,10000.0000,10.0000,1),(64,70,10000.0000,10.0000,0),(65,71,10000.0000,10.0000,0),(66,72,10000.0000,10.0000,1),(67,73,10000.0000,10.0000,0),(68,74,10000.0000,10.0000,1),(69,75,10000.0000,10.0000,1);
/*!40000 ALTER TABLE `sms_sku_full_reduction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_sku_ladder`
--

DROP TABLE IF EXISTS `sms_sku_ladder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_sku_ladder` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `full_count` int DEFAULT NULL COMMENT '满几件',
  `discount` decimal(4,2) DEFAULT NULL COMMENT '打几折',
  `price` decimal(18,4) DEFAULT NULL COMMENT '折后价',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '是否叠加其他优惠[0-不可叠加，1-可叠加]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品阶梯价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_sku_ladder`
--

LOCK TABLES `sms_sku_ladder` WRITE;
/*!40000 ALTER TABLE `sms_sku_ladder` DISABLE KEYS */;
INSERT INTO `sms_sku_ladder` VALUES (49,50,3,0.98,NULL,1),(50,51,3,0.98,NULL,1),(51,52,3,0.98,NULL,1),(52,53,3,0.98,NULL,1),(53,54,3,0.98,NULL,1),(54,55,3,0.98,NULL,1),(55,56,3,0.98,NULL,1),(56,57,3,0.98,NULL,1),(57,58,3,0.98,NULL,1),(58,59,3,0.98,NULL,1),(59,60,3,0.98,NULL,1),(60,61,3,0.98,NULL,1);
/*!40000 ALTER TABLE `sms_sku_ladder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_spu_bounds`
--

DROP TABLE IF EXISTS `sms_spu_bounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_spu_bounds` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint DEFAULT NULL,
  `grow_bounds` decimal(18,4) DEFAULT NULL COMMENT '成长积分',
  `buy_bounds` decimal(18,4) DEFAULT NULL COMMENT '购物积分',
  `work` tinyint(1) DEFAULT NULL COMMENT '优惠生效情况[1111（四个状态位，从右到左）;0 - 无优惠，成长积分是否赠送;1 - 无优惠，购物积分是否赠送;2 - 有优惠，成长积分是否赠送;3 - 有优惠，购物积分是否赠送【状态位0：不赠送，1：赠送】]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品spu积分设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_spu_bounds`
--

LOCK TABLES `sms_spu_bounds` WRITE;
/*!40000 ALTER TABLE `sms_spu_bounds` DISABLE KEYS */;
INSERT INTO `sms_spu_bounds` VALUES (4,17,500.0000,500.0000,NULL),(5,24,500.0000,500.0000,NULL);
/*!40000 ALTER TABLE `sms_spu_bounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc-third-party`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-third-party` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-third-party`;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `picture` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `pic_name` varchar(255) NOT NULL,
  `introduction` text,
  `category` varchar(100) DEFAULT NULL,
  `pic_size` bigint DEFAULT NULL,
  `pic_width` int DEFAULT NULL,
  `pic_height` int DEFAULT NULL,
  `pic_scale` double DEFAULT NULL,
  `pic_format` varchar(50) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `edit_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_delete` tinyint DEFAULT '0' COMMENT '是否被删除（1:删除，2:未删除）',
  `is_used` int DEFAULT NULL COMMENT '是否被使用（1:使用，2:未使用）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
INSERT INTO `picture` VALUES (17,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_ZvZQAW11nyKw9bS9.png','2025-12-22_ZvZQAW11nyKw9bS9.png',NULL,NULL,94926,1186,790,1.5,'PNG',NULL,'2025-12-22 13:41:43','2025-12-22 13:41:43','2025-12-22 13:41:43',0,0),(18,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_mSeFQdax9NqrbqfR.png','2025-12-22_mSeFQdax9NqrbqfR.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-22 14:00:57','2025-12-22 14:05:03','2025-12-22 14:00:57',0,1),(34,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_3JQ4z7Q3dlhpXwbc.png','2025-12-22_3JQ4z7Q3dlhpXwbc.png',NULL,NULL,46420,1344,485,2.77,'PNG',NULL,'2025-12-22 15:12:53','2025-12-22 15:12:53','2025-12-22 15:12:53',0,1),(35,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_xZsfZ94wTzVVjreG.png','2025-12-22_xZsfZ94wTzVVjreG.png',NULL,NULL,81532,1618,923,1.75,'PNG',NULL,'2025-12-22 15:13:00','2025-12-22 15:13:00','2025-12-22 15:12:59',0,1),(36,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-22_KrxqwXVv4bK5Hulm.png','2025-12-22_KrxqwXVv4bK5Hulm.png',NULL,NULL,16460,450,226,1.99,'PNG',NULL,'2025-12-22 18:30:07','2025-12-22 18:30:07','2025-12-22 18:30:07',0,1),(37,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2025-12-23_L17ISmLtiwRx60Cv.png','2025-12-23_L17ISmLtiwRx60Cv.png',NULL,NULL,30424,940,526,1.79,'PNG',NULL,'2025-12-23 15:42:39','2025-12-23 15:42:39','2025-12-23 15:42:39',0,1),(38,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-23_vT8xHrnnmRJiI4mV.png','2025-12-23_vT8xHrnnmRJiI4mV.png',NULL,NULL,46420,1344,485,2.77,'PNG',NULL,'2025-12-23 15:43:57','2025-12-23 15:43:57','2025-12-23 15:43:56',0,1),(39,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_25GRfuCeBiTXPSmA.png','2025-12-23_25GRfuCeBiTXPSmA.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-23 15:45:22','2025-12-23 15:45:22','2025-12-23 15:45:22',0,1),(40,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_gNAwROBRKVl7RNBH.png','2025-12-23_gNAwROBRKVl7RNBH.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-23 15:45:53','2025-12-23 15:45:53','2025-12-23 15:45:52',0,1),(41,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_Ms5LhR9HptwHV1jV.png','2025-12-23_Ms5LhR9HptwHV1jV.png',NULL,NULL,135196,1275,963,1.32,'PNG',NULL,'2025-12-23 15:47:57','2025-12-23 15:47:57','2025-12-23 15:47:57',0,1),(42,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_tfzasc1NNzNbbgYS.png','2025-12-23_tfzasc1NNzNbbgYS.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-23 15:48:03','2025-12-23 15:48:03','2025-12-23 15:48:03',0,1),(43,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_jgL80Dwml06s2OeW.png','2025-12-23_jgL80Dwml06s2OeW.png',NULL,NULL,35976,357,912,0.39,'PNG',NULL,'2025-12-23 15:55:20','2025-12-23 15:55:20','2025-12-23 15:55:19',0,1),(44,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-23_3S186BnLF66NomGU.png','2025-12-23_3S186BnLF66NomGU.png',NULL,NULL,46420,1344,485,2.77,'PNG',NULL,'2025-12-23 15:55:30','2025-12-23 15:55:30','2025-12-23 15:55:29',0,1),(45,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-24_QjWtsX8XElUHynOG.png','2025-12-24_QjWtsX8XElUHynOG.png',NULL,NULL,102356,1342,710,1.89,'PNG',NULL,'2025-12-24 13:54:27','2025-12-24 13:54:27','2025-12-24 13:54:26',0,1),(46,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-24_8GexNZX6D0YlBkej.png','2025-12-24_8GexNZX6D0YlBkej.png',NULL,NULL,16460,450,226,1.99,'PNG',NULL,'2025-12-24 13:55:15','2025-12-24 13:55:15','2025-12-24 13:55:14',0,1),(47,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-24_szFXLe7DRrnE0qDo.png','2025-12-24_szFXLe7DRrnE0qDo.png',NULL,NULL,16460,450,226,1.99,'PNG',NULL,'2025-12-24 13:55:42','2025-12-24 13:55:42','2025-12-24 13:55:42',0,1),(48,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-24_QpAuReVNQWp3IB8z.png','2025-12-24_QpAuReVNQWp3IB8z.png',NULL,NULL,150282,1432,910,1.57,'PNG',NULL,'2025-12-24 13:55:46','2025-12-24 13:55:46','2025-12-24 13:55:46',0,1),(49,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-25_y2OU3UiP5YY7gXDQ.jpg','2025-12-25_y2OU3UiP5YY7gXDQ.jpg',NULL,NULL,26518,833,278,3,'PNG',NULL,'2025-12-25 17:52:23','2025-12-25 17:52:23','2025-12-25 17:52:23',0,1),(50,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-25_tI9Nhk7WwD7mdcrV.jpg','2025-12-25_tI9Nhk7WwD7mdcrV.jpg',NULL,NULL,26518,833,278,3,'PNG',NULL,'2025-12-25 17:52:39','2025-12-25 17:52:39','2025-12-25 17:52:41',0,1),(51,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-25_kP9aSHLcw86bU7i4.jpg','2025-12-25_kP9aSHLcw86bU7i4.jpg',NULL,NULL,26518,833,278,3,'PNG',NULL,'2025-12-25 17:53:41','2025-12-25 17:53:41','2025-12-25 17:53:43',0,1),(52,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-26_28GfkoYkyVtcR0fX.png','2025-12-26_28GfkoYkyVtcR0fX.png',NULL,NULL,135196,1275,963,1.32,'PNG',NULL,'2025-12-26 16:14:29','2025-12-26 16:14:29','2025-12-26 16:14:28',0,1),(53,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-26_tniZRpVg8mYqoAnb.png','2025-12-26_tniZRpVg8mYqoAnb.png',NULL,NULL,36078,1670,351,4.76,'PNG',NULL,'2025-12-26 16:15:00','2025-12-26 16:15:00','2025-12-26 16:14:59',0,1),(54,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-26_KtdLlNI6BXSz6vtf.jpg','2025-12-26_KtdLlNI6BXSz6vtf.jpg',NULL,NULL,26518,833,278,3,'PNG',NULL,'2025-12-26 16:22:10','2025-12-26 16:22:10','2025-12-26 16:22:09',0,1),(55,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-26_K980UpEOnPNh8qUv.png','2025-12-26_K980UpEOnPNh8qUv.png',NULL,NULL,204836,1312,1188,1.1,'PNG',NULL,'2025-12-26 16:34:45','2025-12-26 16:34:45','2025-12-26 16:34:44',0,1),(56,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_voq1zstXksqDMNyg.png','2025-12-29_voq1zstXksqDMNyg.png',NULL,NULL,30424,940,526,1.79,'PNG',NULL,'2025-12-29 16:02:27','2025-12-29 16:02:27','2025-12-29 16:02:27',0,1),(57,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_wlbDoMpl6CBEX84k.png','2025-12-29_wlbDoMpl6CBEX84k.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-29 16:35:44','2025-12-29 16:35:44','2025-12-29 16:35:46',0,1),(58,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_39wzjTInQxWyIRVL.png','2025-12-29_39wzjTInQxWyIRVL.png',NULL,NULL,70931,639,658,0.97,'PNG',NULL,'2025-12-29 17:01:25','2025-12-29 17:01:25','2025-12-29 17:01:25',0,1),(59,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-29_P4WBj7c202H00OSD.png','2025-12-29_P4WBj7c202H00OSD.png',NULL,NULL,79557,1608,899,1.79,'PNG',NULL,'2025-12-29 17:01:42','2025-12-29 17:01:42','2025-12-29 17:01:41',0,1),(60,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_gcasl1wzjFl4ktHs.png','2025-12-30_gcasl1wzjFl4ktHs.png',NULL,NULL,135196,1275,963,1.32,'PNG',NULL,'2025-12-30 14:23:31','2025-12-30 14:23:31','2025-12-30 14:23:30',0,1),(61,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2025-12-30_Q1jTbNvwIXnxyE6e.png','2025-12-30_Q1jTbNvwIXnxyE6e.png',NULL,NULL,28554,300,300,1,'PNG',NULL,'2025-12-30 16:04:06','2025-12-30 16:04:06','2025-12-30 16:04:06',0,1),(62,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_rzdsGYaXELteeuSr.avif','2025-12-30_rzdsGYaXELteeuSr.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 16:56:06','2025-12-30 16:56:06','2025-12-30 16:56:07',0,1),(63,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_8clFajQIheuf5lOg.avif','2025-12-30_8clFajQIheuf5lOg.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2025-12-30 16:56:10','2025-12-30 16:56:10','2025-12-30 16:56:11',0,1),(64,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_1ZmHq3V1giG3TPBV.avif','2025-12-30_1ZmHq3V1giG3TPBV.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2025-12-30 16:56:10','2025-12-30 16:56:10','2025-12-30 16:56:11',0,1),(65,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_4uIDs8RFnFd1WjXV.avif','2025-12-30_4uIDs8RFnFd1WjXV.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 16:56:10','2025-12-30 16:56:10','2025-12-30 16:56:11',0,1),(66,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_ZSC0bPXtBalZiblg.avif','2025-12-30_ZSC0bPXtBalZiblg.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2025-12-30 16:56:10','2025-12-30 16:56:10','2025-12-30 16:56:11',0,1),(67,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_aas5mMyc7KFC0aR4.avif','2025-12-30_aas5mMyc7KFC0aR4.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 17:05:33','2025-12-30 17:05:33','2025-12-30 17:05:34',0,1),(68,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_WB6CWzoqpEFdF2ix.avif','2025-12-30_WB6CWzoqpEFdF2ix.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2025-12-30 17:05:39','2025-12-30 17:05:39','2025-12-30 17:05:38',0,1),(69,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_h7sFFAmImW7jVFjT.avif','2025-12-30_h7sFFAmImW7jVFjT.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2025-12-30 17:05:39','2025-12-30 17:05:39','2025-12-30 17:05:38',0,1),(70,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_YB8LvrmymoAWgJqZ.avif','2025-12-30_YB8LvrmymoAWgJqZ.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2025-12-30 17:05:39','2025-12-30 17:05:39','2025-12-30 17:05:38',0,1),(71,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_qyfbV1HoBb7n6qEq.avif','2025-12-30_qyfbV1HoBb7n6qEq.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 17:05:39','2025-12-30 17:05:39','2025-12-30 17:05:38',0,1),(72,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_VcgzWVfL0I63x0tj.jpg','2025-12-30_VcgzWVfL0I63x0tj.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 17:06:04','2025-12-30 17:06:04','2025-12-30 17:06:04',0,1),(73,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_MyeEouEUqZWpJ9Fx.avif','2025-12-30_MyeEouEUqZWpJ9Fx.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 17:14:38','2025-12-30 17:14:38','2025-12-30 17:14:36',0,1),(74,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_7wLVe5FZ6KUJnBcy.jpg','2025-12-30_7wLVe5FZ6KUJnBcy.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 17:14:42','2025-12-30 17:14:42','2025-12-30 17:14:40',0,1),(75,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_p3uWYT4bwbcMBuDL.avif','2025-12-30_p3uWYT4bwbcMBuDL.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:15:06','2025-12-30 18:15:06','2025-12-30 18:15:07',0,1),(76,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_IzcsVBVatD8hmCDr.jpg','2025-12-30_IzcsVBVatD8hmCDr.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 18:15:42','2025-12-30 18:15:42','2025-12-30 18:15:42',0,1),(77,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_93p0VRViLUzPbBMC.avif','2025-12-30_93p0VRViLUzPbBMC.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:15:47','2025-12-30 18:15:47','2025-12-30 18:15:47',0,1),(78,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//groupicon/2025-12-30_gIAh7LDePiuco126.avif','2025-12-30_gIAh7LDePiuco126.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:16:01','2025-12-30 18:16:01','2025-12-30 18:16:00',0,1),(79,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_nuZe2LhpMmJWVmxa.avif','2025-12-30_nuZe2LhpMmJWVmxa.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:17:36','2025-12-30 18:17:36','2025-12-30 18:17:36',0,1),(80,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_BOlVbFM4IpKtTwbI.avif','2025-12-30_BOlVbFM4IpKtTwbI.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:18:04','2025-12-30 18:18:04','2025-12-30 18:18:05',0,1),(81,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_6x5vQJulhNYaTO2D.avif','2025-12-30_6x5vQJulhNYaTO2D.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:20:22','2025-12-30 18:20:22','2025-12-30 18:20:23',0,1),(82,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_WPGz1PN4PU7jv0s2.avif','2025-12-30_WPGz1PN4PU7jv0s2.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:20:57','2025-12-30 18:20:57','2025-12-30 18:20:58',0,1),(83,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_QJ9mj5KUTwPwOlFC.avif','2025-12-30_QJ9mj5KUTwPwOlFC.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:21:52','2025-12-30 18:21:52','2025-12-30 18:21:51',0,1),(84,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_FEQMs4vlgLfX4xtq.avif','2025-12-30_FEQMs4vlgLfX4xtq.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:24:26','2025-12-30 18:24:26','2025-12-30 18:24:27',0,1),(85,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_48FKSOpkRHkYbFQy.avif','2025-12-30_48FKSOpkRHkYbFQy.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:24:53','2025-12-30 18:24:53','2025-12-30 18:24:51',0,1),(86,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_g7Owx4rNS7wZywEu.avif','2025-12-30_g7Owx4rNS7wZywEu.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:26:08','2025-12-30 18:26:08','2025-12-30 18:26:09',0,1),(87,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_7Gx9cXLzRHFPqNtB.avif','2025-12-30_7Gx9cXLzRHFPqNtB.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:26:10','2025-12-30 18:26:10','2025-12-30 18:26:11',0,1),(88,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_88syFiSiS8kdnJ4N.avif','2025-12-30_88syFiSiS8kdnJ4N.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:39:42','2025-12-30 18:39:42','2025-12-30 18:39:43',0,1),(89,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_6kI2FZTU5jXlUGyw.avif','2025-12-30_6kI2FZTU5jXlUGyw.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:39:43','2025-12-30 18:39:43','2025-12-30 18:39:44',0,1),(90,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_Z8Iiogq32HQrCc5C.avif','2025-12-30_Z8Iiogq32HQrCc5C.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:51:08','2025-12-30 18:51:08','2025-12-30 18:51:08',0,1),(91,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_mFPmYxjOj5eWSD2L.jpg','2025-12-30_mFPmYxjOj5eWSD2L.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 18:51:10','2025-12-30 18:51:10','2025-12-30 18:51:10',0,1),(92,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_G4sA2r2Ks47PkOQv.avif','2025-12-30_G4sA2r2Ks47PkOQv.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:52:32','2025-12-30 18:52:32','2025-12-30 18:52:31',0,1),(93,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_BsmU2BQTxESFMSIb.avif','2025-12-30_BsmU2BQTxESFMSIb.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:53:02','2025-12-30 18:53:02','2025-12-30 18:53:01',0,1),(94,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_DvhWgojls9dKuEps.avif','2025-12-30_DvhWgojls9dKuEps.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:53:22','2025-12-30 18:53:22','2025-12-30 18:53:23',0,1),(95,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_4ruS3hRkCNFv6vJi.avif','2025-12-30_4ruS3hRkCNFv6vJi.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:58:19','2025-12-30 18:58:19','2025-12-30 18:58:18',0,1),(96,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_3MT5g7KM9C7TbGKd.avif','2025-12-30_3MT5g7KM9C7TbGKd.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 18:58:20','2025-12-30 18:58:20','2025-12-30 18:58:19',0,1),(97,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//arricon/2025-12-30_Op3MnDaFAsVn5lII.avif','2025-12-30_Op3MnDaFAsVn5lII.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:00:35','2025-12-30 19:00:35','2025-12-30 19:00:35',0,1),(98,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_pHyKMb8ttHlAXspG.avif','2025-12-30_pHyKMb8ttHlAXspG.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:01:43','2025-12-30 19:01:43','2025-12-30 19:01:43',0,1),(99,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_HkQTI4uR38fOgkRw.avif','2025-12-30_HkQTI4uR38fOgkRw.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:01:44','2025-12-30 19:01:44','2025-12-30 19:01:44',0,1),(100,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_9y47txMbGizVm1kD.avif','2025-12-30_9y47txMbGizVm1kD.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:05','2025-12-30 19:10:05','2025-12-30 19:10:06',0,1),(101,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_Sj1zX0yE0yUAn5La.avif','2025-12-30_Sj1zX0yE0yUAn5La.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:06','2025-12-30 19:10:06','2025-12-30 19:10:06',0,1),(102,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_lj2mdwXmz2QnJpqr.avif','2025-12-30_lj2mdwXmz2QnJpqr.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2025-12-30 19:10:06','2025-12-30 19:10:06','2025-12-30 19:10:06',0,1),(103,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_JiRggJ0xzfNmFf6p.avif','2025-12-30_JiRggJ0xzfNmFf6p.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2025-12-30 19:10:06','2025-12-30 19:10:06','2025-12-30 19:10:06',0,1),(104,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_wqNcAPUWl891rjLT.avif','2025-12-30_wqNcAPUWl891rjLT.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:06','2025-12-30 19:10:06','2025-12-30 19:10:06',0,1),(105,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_oifOieN6lfzC5F2a.avif','2025-12-30_oifOieN6lfzC5F2a.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2025-12-30 19:10:17','2025-12-30 19:10:17','2025-12-30 19:10:17',0,1),(106,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_pgEmPT3vB1W7mr0s.avif','2025-12-30_pgEmPT3vB1W7mr0s.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2025-12-30 19:10:17','2025-12-30 19:10:17','2025-12-30 19:10:17',0,1),(107,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_5yH5SbBKR8RlIeyr.avif','2025-12-30_5yH5SbBKR8RlIeyr.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:17','2025-12-30 19:10:17','2025-12-30 19:10:17',0,1),(108,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_v5fjFxXIAOWHaO64.avif','2025-12-30_v5fjFxXIAOWHaO64.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:17','2025-12-30 19:10:17','2025-12-30 19:10:17',0,1),(109,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2025-12-30_UtjhGP8WZzLfNBRi.avif','2025-12-30_UtjhGP8WZzLfNBRi.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2025-12-30 19:10:17','2025-12-30 19:10:17','2025-12-30 19:10:17',0,1),(110,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2025-12-30_b6pv8gYhtu64rbrU.jpg','2025-12-30_b6pv8gYhtu64rbrU.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 19:10:21','2025-12-30 19:10:21','2025-12-30 19:10:20',0,1),(111,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2025-12-30_iKRFzX2YvZVHyx40.jpg','2025-12-30_iKRFzX2YvZVHyx40.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2025-12-30 19:19:57','2025-12-30 19:19:57','2025-12-30 19:19:56',0,1),(112,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_fvjBKWlny5SDVRKo.jpg','2026-01-05_fvjBKWlny5SDVRKo.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:02:14','2026-01-05 14:02:14','2026-01-05 14:02:13',0,1),(113,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_PvO9ft6QdxVkaEvt.avif','2026-01-05_PvO9ft6QdxVkaEvt.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:02:24','2026-01-05 14:02:24','2026-01-05 14:02:24',0,1),(114,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_t4aVDwrml9dTzgaF.avif','2026-01-05_t4aVDwrml9dTzgaF.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2026-01-05 14:02:25','2026-01-05 14:02:25','2026-01-05 14:02:24',0,1),(115,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_ib3Si2vGlq0CqFWK.avif','2026-01-05_ib3Si2vGlq0CqFWK.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:02:25','2026-01-05 14:02:25','2026-01-05 14:02:24',0,1),(116,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_6OGcv8iuIMGAjGeP.avif','2026-01-05_6OGcv8iuIMGAjGeP.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:02:25','2026-01-05 14:02:25','2026-01-05 14:02:24',0,1),(117,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_tkg2oBGMq1xiaAKn.avif','2026-01-05_tkg2oBGMq1xiaAKn.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2026-01-05 14:02:25','2026-01-05 14:02:25','2026-01-05 14:02:24',0,1),(118,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_wSkLWH7EF78mkO3z.jpg','2026-01-05_wSkLWH7EF78mkO3z.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:02:27','2026-01-05 14:02:27','2026-01-05 14:02:26',0,1),(119,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_KFaUnGyKAyEpIRnH.jpg','2026-01-05_KFaUnGyKAyEpIRnH.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:09:44','2026-01-05 14:09:44','2026-01-05 14:09:44',0,1),(120,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_jvmIMhdb2wIqQxmd.jpg','2026-01-05_jvmIMhdb2wIqQxmd.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:09:46','2026-01-05 14:09:46','2026-01-05 14:09:45',0,1),(121,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_AjpDHib5Ae7onSie.avif','2026-01-05_AjpDHib5Ae7onSie.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:09:52','2026-01-05 14:09:52','2026-01-05 14:09:52',0,1),(122,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_U8HkqV9hLRtMZNGH.avif','2026-01-05_U8HkqV9hLRtMZNGH.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:11:05','2026-01-05 14:11:05','2026-01-05 14:11:03',0,1),(123,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_TZchTVHViKAqrDm4.jpg','2026-01-05_TZchTVHViKAqrDm4.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:11:06','2026-01-05 14:11:06','2026-01-05 14:11:05',0,1),(124,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_EhzMuVoSPhr2yS0N.avif','2026-01-05_EhzMuVoSPhr2yS0N.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:14:25','2026-01-05 14:14:25','2026-01-05 14:14:25',0,1),(125,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_Zil68Dx9aWk7JaUE.jpg','2026-01-05_Zil68Dx9aWk7JaUE.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:14:27','2026-01-05 14:14:27','2026-01-05 14:14:27',0,1),(126,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2026-01-05_YzjRIj6GhN9oq4EP.avif','2026-01-05_YzjRIj6GhN9oq4EP.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:16:15','2026-01-05 14:16:15','2026-01-05 14:16:15',0,1),(127,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_y332OYp2szc6vdNb.avif','2026-01-05_y332OYp2szc6vdNb.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2026-01-05 14:18:12','2026-01-05 14:18:12','2026-01-05 14:18:12',0,1),(128,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_Nq6KNXv10PjmelM4.avif','2026-01-05_Nq6KNXv10PjmelM4.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:13','2026-01-05 14:18:13','2026-01-05 14:18:12',0,1),(129,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_AoIEva0J7f0EmLhp.avif','2026-01-05_AoIEva0J7f0EmLhp.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2026-01-05 14:18:13','2026-01-05 14:18:13','2026-01-05 14:18:12',0,1),(130,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_qrW9hyJTnldbDl7U.avif','2026-01-05_qrW9hyJTnldbDl7U.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:13','2026-01-05 14:18:13','2026-01-05 14:18:12',0,1),(131,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_f9bM1b6EP3ym1ux0.avif','2026-01-05_f9bM1b6EP3ym1ux0.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:13','2026-01-05 14:18:13','2026-01-05 14:18:12',0,1),(132,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_kZyXzoVlVvgYsai9.jpg','2026-01-05_kZyXzoVlVvgYsai9.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:18:16','2026-01-05 14:18:16','2026-01-05 14:18:15',0,1),(133,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_6xQJdxOlep0t4ypV.avif','2026-01-05_6xQJdxOlep0t4ypV.avif',NULL,NULL,75055,1440,1440,1,'AVIF',NULL,'2026-01-05 14:18:16','2026-01-05 14:18:16','2026-01-05 14:18:15',0,1),(134,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_k1qejQlFGfXlFdGo.avif','2026-01-05_k1qejQlFGfXlFdGo.avif',NULL,NULL,77125,1440,1440,1,'AVIF',NULL,'2026-01-05 14:18:16','2026-01-05 14:18:16','2026-01-05 14:18:15',0,1),(135,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_gdW3uC89EbMLf4pC.avif','2026-01-05_gdW3uC89EbMLf4pC.avif',NULL,NULL,75126,1440,1440,1,'AVIF',NULL,'2026-01-05 14:18:16','2026-01-05 14:18:16','2026-01-05 14:18:15',0,1),(136,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_rJ0FCvKp2dipsNm4.avif','2026-01-05_rJ0FCvKp2dipsNm4.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2026-01-05 14:18:26','2026-01-05 14:18:26','2026-01-05 14:18:26',0,1),(137,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_pbl8wkqaR6ARCBrr.avif','2026-01-05_pbl8wkqaR6ARCBrr.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2026-01-05 14:18:26','2026-01-05 14:18:26','2026-01-05 14:18:26',0,1),(138,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_4Pdo21kVvdTo2gbB.avif','2026-01-05_4Pdo21kVvdTo2gbB.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:26','2026-01-05 14:18:26','2026-01-05 14:18:27',0,1),(139,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_Nlec2B656klOjYlG.avif','2026-01-05_Nlec2B656klOjYlG.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:26','2026-01-05 14:18:26','2026-01-05 14:18:27',0,1),(140,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_cCiVT6Hm3eXoh9Uo.avif','2026-01-05_cCiVT6Hm3eXoh9Uo.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:18:26','2026-01-05 14:18:26','2026-01-05 14:18:27',0,1),(141,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_it76kCr4HqM1FVMd.jpg','2026-01-05_it76kCr4HqM1FVMd.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:23:41','2026-01-05 14:23:41','2026-01-05 14:23:41',0,1),(142,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_BB2XyEh3rczkt5Dq.jpg','2026-01-05_BB2XyEh3rczkt5Dq.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:23:42','2026-01-05 14:23:42','2026-01-05 14:23:42',0,1),(143,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2026-01-05_BSPICdvflS2arLGo.jpg','2026-01-05_BSPICdvflS2arLGo.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:27:40','2026-01-05 14:27:40','2026-01-05 14:27:39',0,1),(144,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2026-01-05_RHBZNi1R9A31Hph1.avif','2026-01-05_RHBZNi1R9A31Hph1.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:29:36','2026-01-05 14:29:36','2026-01-05 14:29:36',0,1),(145,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_hU9si6Wg121dWl9Z.avif','2026-01-05_hU9si6Wg121dWl9Z.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:38:51','2026-01-05 14:38:51','2026-01-05 14:38:51',0,1),(146,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_bY88yuIZmfEkY8x7.jpg','2026-01-05_bY88yuIZmfEkY8x7.jpg',NULL,NULL,70010,1440,1440,1,'AVIF',NULL,'2026-01-05 14:38:52','2026-01-05 14:38:52','2026-01-05 14:38:50',0,1),(147,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//undefined/2026-01-05_wlPIx6GBuDujrdPP.avif','2026-01-05_wlPIx6GBuDujrdPP.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 14:39:08','2026-01-05 14:39:08','2026-01-05 14:39:08',0,1),(148,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_GzRQLQAcuVZU6It7.avif','2026-01-05_GzRQLQAcuVZU6It7.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:06','2026-01-05 15:13:06','2026-01-05 15:13:05',0,1),(149,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_l8ZQml7mjZSi1wqN.avif','2026-01-05_l8ZQml7mjZSi1wqN.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2026-01-05 15:13:06','2026-01-05 15:13:06','2026-01-05 15:13:05',0,1),(150,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_aSu1o4B6Cl1sDdBU.avif','2026-01-05_aSu1o4B6Cl1sDdBU.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:06','2026-01-05 15:13:06','2026-01-05 15:13:05',0,1),(151,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_Cy4JuLTkySsvqqAx.avif','2026-01-05_Cy4JuLTkySsvqqAx.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2026-01-05 15:13:06','2026-01-05 15:13:06','2026-01-05 15:13:05',0,1),(152,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_ZdTeSwhbrkkVZ82H.avif','2026-01-05_ZdTeSwhbrkkVZ82H.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:06','2026-01-05 15:13:06','2026-01-05 15:13:05',0,1),(153,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_lKd8Vk7N1BRpZqkL.avif','2026-01-05_lKd8Vk7N1BRpZqkL.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:38','2026-01-05 15:13:38','2026-01-05 15:13:37',0,1),(154,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_fSs8SEcBtFLYtABE.avif','2026-01-05_fSs8SEcBtFLYtABE.avif',NULL,NULL,44615,790,1020,0.77,'AVIF',NULL,'2026-01-05 15:13:38','2026-01-05 15:13:38','2026-01-05 15:13:37',0,1),(155,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_5u0SuwKN4wcCpiX5.avif','2026-01-05_5u0SuwKN4wcCpiX5.avif',NULL,NULL,7480,790,1370,0.58,'AVIF',NULL,'2026-01-05 15:13:38','2026-01-05 15:13:38','2026-01-05 15:13:37',0,1),(156,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_ZGTTHIyLbKfhwQRT.avif','2026-01-05_ZGTTHIyLbKfhwQRT.avif',NULL,NULL,8800,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:38','2026-01-05 15:13:38','2026-01-05 15:13:37',0,1),(157,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_7vO03SlJZ0BwnWNq.avif','2026-01-05_7vO03SlJZ0BwnWNq.avif',NULL,NULL,31349,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:13:38','2026-01-05 15:13:38','2026-01-05 15:13:38',0,1),(158,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_rQ7emuUiX0K3Oh9p.avif','2026-01-05_rQ7emuUiX0K3Oh9p.avif',NULL,NULL,75126,1440,1440,1,'AVIF',NULL,'2026-01-05 15:13:52','2026-01-05 15:13:52','2026-01-05 15:13:50',0,1),(159,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_8caYZgSIgideUjxT.avif','2026-01-05_8caYZgSIgideUjxT.avif',NULL,NULL,74625,1440,1440,1,'AVIF',NULL,'2026-01-05 15:13:52','2026-01-05 15:13:52','2026-01-05 15:13:50',0,1),(160,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_LJTVTW1p97UavkCA.avif','2026-01-05_LJTVTW1p97UavkCA.avif',NULL,NULL,77125,1440,1440,1,'AVIF',NULL,'2026-01-05 15:13:52','2026-01-05 15:13:52','2026-01-05 15:13:50',0,1),(161,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_cvK8jcQbexVEEONX.avif','2026-01-05_cvK8jcQbexVEEONX.avif',NULL,NULL,75055,1440,1440,1,'AVIF',NULL,'2026-01-05 15:13:52','2026-01-05 15:13:52','2026-01-05 15:13:50',0,1),(162,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-05_yEvgYADEwCV3LBW8.avif','2026-01-05_yEvgYADEwCV3LBW8.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:57:28','2026-01-05 15:57:28','2026-01-05 15:57:28',0,1),(163,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-05_xY0z68X7Uzi5YWYo.avif','2026-01-05_xY0z68X7Uzi5YWYo.avif',NULL,NULL,30283,790,1580,0.5,'AVIF',NULL,'2026-01-05 15:57:30','2026-01-05 15:57:30','2026-01-05 15:57:29',0,1),(164,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//logo/2026-01-06_guvkXmdthhSHOmlB.png','2026-01-06_guvkXmdthhSHOmlB.png',NULL,NULL,1094,92,92,1,'PNG',NULL,'2026-01-06 16:02:36','2026-01-06 16:02:36','2026-01-06 16:02:35',0,1),(165,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_51azfdyCZzRj0Lbp.avif','2026-01-07_51azfdyCZzRj0Lbp.avif',NULL,NULL,63864,1440,1440,1,'AVIF',NULL,'2026-01-07 13:33:59','2026-01-07 13:33:59','2026-01-07 13:33:59',0,1),(166,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_ZJt3i4b77ZRyWsAP.avif','2026-01-07_ZJt3i4b77ZRyWsAP.avif',NULL,NULL,60738,1440,1440,1,'AVIF',NULL,'2026-01-07 13:33:59','2026-01-07 13:33:59','2026-01-07 13:33:59',0,1),(167,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_dzdE2OuhbI8OA2aG.avif','2026-01-07_dzdE2OuhbI8OA2aG.avif',NULL,NULL,62718,1440,1440,1,'AVIF',NULL,'2026-01-07 13:33:59','2026-01-07 13:33:59','2026-01-07 13:33:59',0,1),(168,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_M3ZeCV9Rje0xUEJP.avif','2026-01-07_M3ZeCV9Rje0xUEJP.avif',NULL,NULL,69921,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:00','2026-01-07 13:34:00','2026-01-07 13:33:59',0,1),(169,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_WDoP0iQrtAn4eUme.avif','2026-01-07_WDoP0iQrtAn4eUme.avif',NULL,NULL,47072,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:00','2026-01-07 13:34:00','2026-01-07 13:33:59',0,1),(170,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_uFoon0ndy1epUI8C.avif','2026-01-07_uFoon0ndy1epUI8C.avif',NULL,NULL,50310,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:00','2026-01-07 13:34:00','2026-01-07 13:33:59',0,1),(171,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_8XPwDYQ2hMBgwUIV.avif','2026-01-07_8XPwDYQ2hMBgwUIV.avif',NULL,NULL,43079,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:00','2026-01-07 13:34:00','2026-01-07 13:34:00',0,1),(172,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spudecript/2026-01-07_tmIl6qJGBLPqfcvm.avif','2026-01-07_tmIl6qJGBLPqfcvm.avif',NULL,NULL,110698,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:00','2026-01-07 13:34:00','2026-01-07 13:34:00',0,1),(173,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_XPxSWjrnS9Tpmw0f.avif','2026-01-07_XPxSWjrnS9Tpmw0f.avif',NULL,NULL,51769,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:12','2026-01-07 13:34:12','2026-01-07 13:34:12',0,1),(174,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_2xXUsmHZXjsMLLVq.avif','2026-01-07_2xXUsmHZXjsMLLVq.avif',NULL,NULL,49835,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:12','2026-01-07 13:34:12','2026-01-07 13:34:12',0,1),(175,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_rkdjjdA1M2MGBJc0.avif','2026-01-07_rkdjjdA1M2MGBJc0.avif',NULL,NULL,52411,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:12','2026-01-07 13:34:12','2026-01-07 13:34:12',0,1),(176,'https://glsc-1324858795.cos.ap-beijing.myqcloud.com//spuimages/2026-01-07_pUHWUVVmBsEu2rKC.avif','2026-01-07_pUHWUVVmBsEu2rKC.avif',NULL,NULL,51901,1440,1440,1,'AVIF',NULL,'2026-01-07 13:34:12','2026-01-07 13:34:12','2026-01-07 13:34:12',0,1);
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc-ums`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-ums` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-ums`;

--
-- Table structure for table `ums_growth_change_history`
--

DROP TABLE IF EXISTS `ums_growth_change_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_growth_change_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  `change_count` int DEFAULT NULL COMMENT '改变的值（正负计数）',
  `note` varchar(0) DEFAULT NULL COMMENT '备注',
  `source_type` tinyint DEFAULT NULL COMMENT '积分来源[0-购物，1-管理员修改]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='成长值变化历史记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_growth_change_history`
--

LOCK TABLES `ums_growth_change_history` WRITE;
/*!40000 ALTER TABLE `ums_growth_change_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_growth_change_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_integration_change_history`
--

DROP TABLE IF EXISTS `ums_integration_change_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_integration_change_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  `change_count` int DEFAULT NULL COMMENT '变化的值',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `source_tyoe` tinyint DEFAULT NULL COMMENT '来源[0->购物；1->管理员修改;2->活动]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='积分变化历史记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_integration_change_history`
--

LOCK TABLES `ums_integration_change_history` WRITE;
/*!40000 ALTER TABLE `ums_integration_change_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_integration_change_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member`
--

DROP TABLE IF EXISTS `ums_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `level_id` bigint DEFAULT NULL COMMENT '会员等级id',
  `username` char(64) DEFAULT NULL COMMENT '用户名',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `nickname` varchar(64) DEFAULT NULL COMMENT '昵称',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `header` varchar(500) DEFAULT NULL COMMENT '头像',
  `gender` tinyint DEFAULT NULL COMMENT '性别',
  `birth` date DEFAULT NULL COMMENT '生日',
  `city` varchar(500) DEFAULT NULL COMMENT '所在城市',
  `job` varchar(255) DEFAULT NULL COMMENT '职业',
  `sign` varchar(255) DEFAULT NULL COMMENT '个性签名',
  `source_type` tinyint DEFAULT NULL COMMENT '用户来源',
  `integration` int DEFAULT NULL COMMENT '积分',
  `growth` int DEFAULT NULL COMMENT '成长值',
  `status` tinyint DEFAULT NULL COMMENT '启用状态',
  `create_time` datetime DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member`
--

LOCK TABLES `ums_member` WRITE;
/*!40000 ALTER TABLE `ums_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_collect_spu`
--

DROP TABLE IF EXISTS `ums_member_collect_spu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_collect_spu` (
  `id` bigint NOT NULL COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT '会员id',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(500) DEFAULT NULL COMMENT 'spu_name',
  `spu_img` varchar(500) DEFAULT NULL COMMENT 'spu_img',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员收藏的商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_collect_spu`
--

LOCK TABLES `ums_member_collect_spu` WRITE;
/*!40000 ALTER TABLE `ums_member_collect_spu` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member_collect_spu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_collect_subject`
--

DROP TABLE IF EXISTS `ums_member_collect_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_collect_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `subject_id` bigint DEFAULT NULL COMMENT 'subject_id',
  `subject_name` varchar(255) DEFAULT NULL COMMENT 'subject_name',
  `subject_img` varchar(500) DEFAULT NULL COMMENT 'subject_img',
  `subject_urll` varchar(500) DEFAULT NULL COMMENT '活动url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员收藏的专题活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_collect_subject`
--

LOCK TABLES `ums_member_collect_subject` WRITE;
/*!40000 ALTER TABLE `ums_member_collect_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member_collect_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_level`
--

DROP TABLE IF EXISTS `ums_member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_level` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(100) DEFAULT NULL COMMENT '等级名称',
  `growth_point` int DEFAULT NULL COMMENT '等级需要的成长值',
  `default_status` tinyint DEFAULT NULL COMMENT '是否为默认等级[0->不是；1->是]',
  `free_freight_point` decimal(18,4) DEFAULT NULL COMMENT '免运费标准',
  `comment_growth_point` int DEFAULT NULL COMMENT '每次评价获取的成长值',
  `priviledge_free_freight` tinyint DEFAULT NULL COMMENT '是否有免邮特权',
  `priviledge_member_price` tinyint DEFAULT NULL COMMENT '是否有会员价格特权',
  `priviledge_birthday` tinyint DEFAULT NULL COMMENT '是否有生日特权',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员等级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_level`
--

LOCK TABLES `ums_member_level` WRITE;
/*!40000 ALTER TABLE `ums_member_level` DISABLE KEYS */;
INSERT INTO `ums_member_level` VALUES (1,'普通会员',0,1,299.0000,10,0,0,1,'初级会员'),(2,'铜牌会员',3000,0,100.0000,30,0,1,1,'铜牌会员'),(3,'银牌会员',5000,0,50.0000,50,0,1,1,'银牌会员'),(4,'铂金会员',8000,0,10.0000,70,1,1,1,'铂金会员');
/*!40000 ALTER TABLE `ums_member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_login_log`
--

DROP TABLE IF EXISTS `ums_member_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `ip` varchar(64) DEFAULT NULL COMMENT 'ip',
  `city` varchar(64) DEFAULT NULL COMMENT 'city',
  `login_type` tinyint(1) DEFAULT NULL COMMENT '登录类型[1-web，2-app]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员登录记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_login_log`
--

LOCK TABLES `ums_member_login_log` WRITE;
/*!40000 ALTER TABLE `ums_member_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_receive_address`
--

DROP TABLE IF EXISTS `ums_member_receive_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_receive_address` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT 'member_id',
  `name` varchar(255) DEFAULT NULL COMMENT '收货人姓名',
  `phone` varchar(64) DEFAULT NULL COMMENT '电话',
  `post_code` varchar(64) DEFAULT NULL COMMENT '邮政编码',
  `province` varchar(100) DEFAULT NULL COMMENT '省份/直辖市',
  `city` varchar(100) DEFAULT NULL COMMENT '城市',
  `region` varchar(100) DEFAULT NULL COMMENT '区',
  `detail_address` varchar(255) DEFAULT NULL COMMENT '详细地址(街道)',
  `areacode` varchar(15) DEFAULT NULL COMMENT '省市区代码',
  `default_status` tinyint(1) DEFAULT NULL COMMENT '是否默认',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员收货地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_receive_address`
--

LOCK TABLES `ums_member_receive_address` WRITE;
/*!40000 ALTER TABLE `ums_member_receive_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member_receive_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ums_member_statistics_info`
--

DROP TABLE IF EXISTS `ums_member_statistics_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ums_member_statistics_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint DEFAULT NULL COMMENT '会员id',
  `consume_amount` decimal(18,4) DEFAULT NULL COMMENT '累计消费金额',
  `coupon_amount` decimal(18,4) DEFAULT NULL COMMENT '累计优惠金额',
  `order_count` int DEFAULT NULL COMMENT '订单数量',
  `coupon_count` int DEFAULT NULL COMMENT '优惠券数量',
  `comment_count` int DEFAULT NULL COMMENT '评价数',
  `return_order_count` int DEFAULT NULL COMMENT '退货数量',
  `login_count` int DEFAULT NULL COMMENT '登录次数',
  `attend_count` int DEFAULT NULL COMMENT '关注数量',
  `fans_count` int DEFAULT NULL COMMENT '粉丝数量',
  `collect_product_count` int DEFAULT NULL COMMENT '收藏的商品数量',
  `collect_subject_count` int DEFAULT NULL COMMENT '收藏的专题活动数量',
  `collect_comment_count` int DEFAULT NULL COMMENT '收藏的评论数量',
  `invite_friend_count` int DEFAULT NULL COMMENT '邀请的朋友数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会员统计信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ums_member_statistics_info`
--

LOCK TABLES `ums_member_statistics_info` WRITE;
/*!40000 ALTER TABLE `ums_member_statistics_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `ums_member_statistics_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc-wms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc-wms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc-wms`;

--
-- Table structure for table `wms_purchase`
--

DROP TABLE IF EXISTS `wms_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_purchase` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购单id',
  `assignee_id` bigint DEFAULT NULL COMMENT '采购人id',
  `assignee_name` varchar(255) DEFAULT NULL COMMENT '采购人名',
  `phone` char(13) DEFAULT NULL COMMENT '联系方式',
  `priority` int DEFAULT NULL COMMENT '优先级',
  `status` int DEFAULT NULL COMMENT '状态',
  `ware_id` bigint DEFAULT NULL COMMENT '仓库id',
  `amount` decimal(18,4) DEFAULT NULL COMMENT '总金额',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `update_time` datetime DEFAULT NULL COMMENT '更新日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_purchase`
--

LOCK TABLES `wms_purchase` WRITE;
/*!40000 ALTER TABLE `wms_purchase` DISABLE KEYS */;
INSERT INTO `wms_purchase` VALUES (1,1,'admin','13612345678',1,4,NULL,NULL,NULL,'2026-01-09 14:20:19'),(2,2,'root','13945879541',2,3,NULL,NULL,'2026-01-08 15:55:34','2026-01-09 15:09:16'),(3,2,'root','13945879541',3,3,NULL,NULL,NULL,'2026-01-09 14:26:33'),(4,1,'admin','13612345678',NULL,3,NULL,NULL,'2026-01-09 14:47:01','2026-01-09 14:55:49');
/*!40000 ALTER TABLE `wms_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_purchase_detail`
--

DROP TABLE IF EXISTS `wms_purchase_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_purchase_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint DEFAULT NULL COMMENT '采购单id',
  `sku_id` bigint DEFAULT NULL COMMENT '采购商品id',
  `sku_num` int DEFAULT NULL COMMENT '采购数量',
  `sku_price` decimal(18,4) DEFAULT NULL COMMENT '采购金额',
  `ware_id` bigint DEFAULT NULL COMMENT '仓库id',
  `status` int DEFAULT NULL COMMENT '状态[0新建，1已分配，2正在采购，3已完成，4采购失败]',
  `reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_purchase_detail`
--

LOCK TABLES `wms_purchase_detail` WRITE;
/*!40000 ALTER TABLE `wms_purchase_detail` DISABLE KEYS */;
INSERT INTO `wms_purchase_detail` VALUES (1,1,50,10,54990.0000,1,3,''),(3,1,51,200,1039800.0000,1,4,'无货'),(6,2,50,1,5499.0000,2,3,''),(7,3,50,100,549900.0000,1,3,''),(8,4,52,10,49990.0000,2,3,''),(9,4,53,20,109980.0000,2,3,''),(10,2,54,10,51990.0000,2,4,'未买到货');
/*!40000 ALTER TABLE `wms_purchase_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_ware_info`
--

DROP TABLE IF EXISTS `wms_ware_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_ware_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '仓库名',
  `address` varchar(255) DEFAULT NULL COMMENT '仓库地址',
  `areacode` varchar(20) DEFAULT NULL COMMENT '区域编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='仓库信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_ware_info`
--

LOCK TABLES `wms_ware_info` WRITE;
/*!40000 ALTER TABLE `wms_ware_info` DISABLE KEYS */;
INSERT INTO `wms_ware_info` VALUES (1,'1号仓库','河南xx','123456'),(2,'2号仓库','北京xx','2345671');
/*!40000 ALTER TABLE `wms_ware_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_ware_order_task`
--

DROP TABLE IF EXISTS `wms_ware_order_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_ware_order_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint DEFAULT NULL COMMENT 'order_id',
  `order_sn` varchar(255) DEFAULT NULL COMMENT 'order_sn',
  `consignee` varchar(100) DEFAULT NULL COMMENT '收货人',
  `consignee_tel` char(15) DEFAULT NULL COMMENT '收货人电话',
  `delivery_address` varchar(500) DEFAULT NULL COMMENT '配送地址',
  `order_comment` varchar(200) DEFAULT NULL COMMENT '订单备注',
  `payment_way` tinyint(1) DEFAULT NULL COMMENT '付款方式【 1:在线付款 2:货到付款】',
  `task_status` tinyint DEFAULT NULL COMMENT '任务状态',
  `order_body` varchar(255) DEFAULT NULL COMMENT '订单描述',
  `tracking_no` char(30) DEFAULT NULL COMMENT '物流单号',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  `ware_id` bigint DEFAULT NULL COMMENT '仓库id',
  `task_comment` varchar(500) DEFAULT NULL COMMENT '工作单备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存工作单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_ware_order_task`
--

LOCK TABLES `wms_ware_order_task` WRITE;
/*!40000 ALTER TABLE `wms_ware_order_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_ware_order_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_ware_order_task_detail`
--

DROP TABLE IF EXISTS `wms_ware_order_task_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_ware_order_task_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku_name',
  `sku_num` int DEFAULT NULL COMMENT '购买个数',
  `task_id` bigint DEFAULT NULL COMMENT '工作单id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存工作单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_ware_order_task_detail`
--

LOCK TABLES `wms_ware_order_task_detail` WRITE;
/*!40000 ALTER TABLE `wms_ware_order_task_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_ware_order_task_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_ware_sku`
--

DROP TABLE IF EXISTS `wms_ware_sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_ware_sku` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `ware_id` bigint DEFAULT NULL COMMENT '仓库id',
  `stock` int DEFAULT NULL COMMENT '库存数',
  `sku_name` varchar(200) DEFAULT NULL COMMENT 'sku_name',
  `stock_locked` int DEFAULT NULL COMMENT '锁定库存',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_ware_sku`
--

LOCK TABLES `wms_ware_sku` WRITE;
/*!40000 ALTER TABLE `wms_ware_sku` DISABLE KEYS */;
INSERT INTO `wms_ware_sku` VALUES (2,50,1,110,NULL,0),(3,52,2,10,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB',0),(4,53,2,20,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB',0),(5,50,2,1,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB',0),(6,54,2,10,'HUAWEI Mate 80 麒麟9020 第二代红枫影像 鸿蒙AI 超可靠玄武架构 华为直屏鸿蒙手机 曜石黑 16GB+512GB',0);
/*!40000 ALTER TABLE `wms_ware_sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `glsc_admin`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `glsc_admin` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `glsc_admin`;

--
-- Table structure for table `QRTZ_BLOB_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_BLOB_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_BLOB_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_BLOB_TRIGGERS_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_BLOB_TRIGGERS`
--

LOCK TABLES `QRTZ_BLOB_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CALENDARS`
--

DROP TABLE IF EXISTS `QRTZ_CALENDARS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_CALENDARS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CALENDARS`
--

LOCK TABLES `QRTZ_CALENDARS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CRON_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_CRON_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_CRON_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(120) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_CRON_TRIGGERS_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CRON_TRIGGERS`
--

LOCK TABLES `QRTZ_CRON_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` DISABLE KEYS */;
INSERT INTO `QRTZ_CRON_TRIGGERS` VALUES ('RenrenScheduler','TASK_1','DEFAULT','0 0/30 * * * ?','Asia/Shanghai');
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_FIRED_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_FIRED_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_FIRED_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint NOT NULL,
  `SCHED_TIME` bigint NOT NULL,
  `PRIORITY` int NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IDX_QRTZ_FT_TRIG_INST_NAME` (`SCHED_NAME`,`INSTANCE_NAME`),
  KEY `IDX_QRTZ_FT_INST_JOB_REQ_RCVRY` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_FT_J_G` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_T_G` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_FT_TG` (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_FIRED_TRIGGERS`
--

LOCK TABLES `QRTZ_FIRED_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_JOB_DETAILS`
--

DROP TABLE IF EXISTS `QRTZ_JOB_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_JOB_DETAILS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_J_REQ_RECOVERY` (`SCHED_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_J_GRP` (`SCHED_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_JOB_DETAILS`
--

LOCK TABLES `QRTZ_JOB_DETAILS` WRITE;
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` DISABLE KEYS */;
INSERT INTO `QRTZ_JOB_DETAILS` VALUES ('RenrenScheduler','TASK_1','DEFAULT',NULL,'io.renren.modules.job.utils.ScheduleJob','0','0','0','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0\rJOB_PARAM_KEYsr\0.io.renren.modules.job.entity.ScheduleJobEntity\0\0\0\0\0\0\0\0L\0beanNamet\0Ljava/lang/String;L\0\ncreateTimet\0Ljava/util/Date;L\0cronExpressionq\0~\0	L\0jobIdt\0Ljava/lang/Long;L\0paramsq\0~\0	L\0remarkq\0~\0	L\0statust\0Ljava/lang/Integer;xpt\0testTasksr\0java.util.Datehj�KYt\0\0xpw\0\0�\�\�@xt\00 0/30 * * * ?sr\0java.lang.Long;�\�̏#\�\0J\0valuexr\0java.lang.Number����\��\0\0xp\0\0\0\0\0\0\0t\0renrent\0参数测试sr\0java.lang.Integer⠤\���8\0I\0valuexq\0~\0\0\0\0\0x\0');
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_LOCKS`
--

DROP TABLE IF EXISTS `QRTZ_LOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_LOCKS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_LOCKS`
--

LOCK TABLES `QRTZ_LOCKS` WRITE;
/*!40000 ALTER TABLE `QRTZ_LOCKS` DISABLE KEYS */;
INSERT INTO `QRTZ_LOCKS` VALUES ('RenrenScheduler','STATE_ACCESS'),('RenrenScheduler','TRIGGER_ACCESS');
/*!40000 ALTER TABLE `QRTZ_LOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

DROP TABLE IF EXISTS `QRTZ_PAUSED_TRIGGER_GRPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_PAUSED_TRIGGER_GRPS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

LOCK TABLES `QRTZ_PAUSED_TRIGGER_GRPS` WRITE;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SCHEDULER_STATE`
--

DROP TABLE IF EXISTS `QRTZ_SCHEDULER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SCHEDULER_STATE` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint NOT NULL,
  `CHECKIN_INTERVAL` bigint NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SCHEDULER_STATE`
--

LOCK TABLES `QRTZ_SCHEDULER_STATE` WRITE;
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` DISABLE KEYS */;
INSERT INTO `QRTZ_SCHEDULER_STATE` VALUES ('RenrenScheduler','BF-2025021710381768281913479',1768376951169,15000);
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SIMPLE_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_SIMPLE_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SIMPLE_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint NOT NULL,
  `REPEAT_INTERVAL` bigint NOT NULL,
  `TIMES_TRIGGERED` bigint NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_SIMPLE_TRIGGERS_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SIMPLE_TRIGGERS`
--

LOCK TABLES `QRTZ_SIMPLE_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SIMPROP_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_SIMPROP_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SIMPROP_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int DEFAULT NULL,
  `INT_PROP_2` int DEFAULT NULL,
  `LONG_PROP_1` bigint DEFAULT NULL,
  `LONG_PROP_2` bigint DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_SIMPROP_TRIGGERS_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SIMPROP_TRIGGERS`
--

LOCK TABLES `QRTZ_SIMPROP_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_SIMPROP_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SIMPROP_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint DEFAULT NULL,
  `PREV_FIRE_TIME` bigint DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint NOT NULL,
  `END_TIME` bigint DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_J` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_C` (`SCHED_NAME`,`CALENDAR_NAME`),
  KEY `IDX_QRTZ_T_G` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_STATE` (`SCHED_NAME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_STATE` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_G_STATE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NEXT_FIRE_TIME` (`SCHED_NAME`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST` (`SCHED_NAME`,`TRIGGER_STATE`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE_GRP` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  CONSTRAINT `QRTZ_TRIGGERS_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `QRTZ_JOB_DETAILS` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_TRIGGERS`
--

LOCK TABLES `QRTZ_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` DISABLE KEYS */;
INSERT INTO `QRTZ_TRIGGERS` VALUES ('RenrenScheduler','TASK_1','DEFAULT','TASK_1','DEFAULT',NULL,1768377600000,1768375800000,5,'WAITING','CRON',1764833422000,0,NULL,2,_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0\rJOB_PARAM_KEYsr\0.io.renren.modules.job.entity.ScheduleJobEntity\0\0\0\0\0\0\0\0L\0beanNamet\0Ljava/lang/String;L\0\ncreateTimet\0Ljava/util/Date;L\0cronExpressionq\0~\0	L\0jobIdt\0Ljava/lang/Long;L\0paramsq\0~\0	L\0remarkq\0~\0	L\0statust\0Ljava/lang/Integer;xpt\0testTasksr\0java.util.Datehj�KYt\0\0xpw\0\0�\�\�@xt\00 0/30 * * * ?sr\0java.lang.Long;�\�̏#\�\0J\0valuexr\0java.lang.Number����\��\0\0xp\0\0\0\0\0\0\0t\0renrent\0参数测试sr\0java.lang.Integer⠤\���8\0I\0valuexq\0~\0\0\0\0\0x\0');
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_job`
--

DROP TABLE IF EXISTS `schedule_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_job` (
  `job_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `cron_expression` varchar(100) DEFAULT NULL COMMENT 'cron表达式',
  `status` tinyint DEFAULT NULL COMMENT '任务状态  0：正常  1：暂停',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='定时任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_job`
--

LOCK TABLES `schedule_job` WRITE;
/*!40000 ALTER TABLE `schedule_job` DISABLE KEYS */;
INSERT INTO `schedule_job` VALUES (1,'testTask','renren','0 0/30 * * * ?',0,'参数测试','2025-12-04 07:28:40');
/*!40000 ALTER TABLE `schedule_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_job_log`
--

DROP TABLE IF EXISTS `schedule_job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_job_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务日志id',
  `job_id` bigint NOT NULL COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `status` tinyint NOT NULL COMMENT '任务状态    0：成功    1：失败',
  `error` varchar(2000) DEFAULT NULL COMMENT '失败信息',
  `times` int NOT NULL COMMENT '耗时(单位：毫秒)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`log_id`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=739 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='定时任务日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_job_log`
--

LOCK TABLES `schedule_job_log` WRITE;
/*!40000 ALTER TABLE `schedule_job_log` DISABLE KEYS */;
INSERT INTO `schedule_job_log` VALUES (1,1,'testTask','renren',0,NULL,0,'2025-12-04 16:00:00'),(2,1,'testTask','renren',0,NULL,1,'2025-12-04 16:30:00'),(3,1,'testTask','renren',0,NULL,0,'2025-12-04 17:00:00'),(4,1,'testTask','renren',0,NULL,1,'2025-12-04 17:30:00'),(5,1,'testTask','renren',0,NULL,1,'2025-12-04 18:00:00'),(6,1,'testTask','renren',0,NULL,0,'2025-12-04 18:30:00'),(7,1,'testTask','renren',0,NULL,1,'2025-12-04 19:00:00'),(8,1,'testTask','renren',0,NULL,2,'2025-12-04 19:30:00'),(9,1,'testTask','renren',0,NULL,0,'2025-12-04 20:00:00'),(10,1,'testTask','renren',0,NULL,0,'2025-12-04 20:30:00'),(11,1,'testTask','renren',0,NULL,1,'2025-12-04 21:00:00'),(12,1,'testTask','renren',0,NULL,1,'2025-12-04 21:30:00'),(13,1,'testTask','renren',0,NULL,1,'2025-12-04 22:00:00'),(14,1,'testTask','renren',0,NULL,0,'2025-12-04 22:30:00'),(15,1,'testTask','renren',0,NULL,0,'2025-12-04 23:00:00'),(16,1,'testTask','renren',0,NULL,0,'2025-12-04 23:30:00'),(17,1,'testTask','renren',0,NULL,4,'2025-12-05 00:00:00'),(18,1,'testTask','renren',0,NULL,0,'2025-12-05 00:30:00'),(19,1,'testTask','renren',0,NULL,1,'2025-12-05 01:00:00'),(20,1,'testTask','renren',0,NULL,1,'2025-12-05 01:30:00'),(21,1,'testTask','renren',0,NULL,0,'2025-12-05 02:00:00'),(22,1,'testTask','renren',0,NULL,1,'2025-12-05 02:30:00'),(23,1,'testTask','renren',0,NULL,1,'2025-12-05 03:00:00'),(24,1,'testTask','renren',0,NULL,0,'2025-12-05 03:30:00'),(25,1,'testTask','renren',0,NULL,0,'2025-12-05 04:00:00'),(26,1,'testTask','renren',0,NULL,0,'2025-12-05 04:30:00'),(27,1,'testTask','renren',0,NULL,1,'2025-12-05 05:00:00'),(28,1,'testTask','renren',0,NULL,0,'2025-12-05 05:30:00'),(29,1,'testTask','renren',0,NULL,0,'2025-12-05 06:00:00'),(30,1,'testTask','renren',0,NULL,1,'2025-12-05 06:30:00'),(31,1,'testTask','renren',0,NULL,0,'2025-12-05 07:00:00'),(32,1,'testTask','renren',0,NULL,1,'2025-12-05 07:30:00'),(33,1,'testTask','renren',0,NULL,1,'2025-12-05 08:00:00'),(34,1,'testTask','renren',0,NULL,1,'2025-12-05 08:30:00'),(35,1,'testTask','renren',0,NULL,1,'2025-12-05 09:00:00'),(36,1,'testTask','renren',0,NULL,1,'2025-12-05 09:30:00'),(37,1,'testTask','renren',0,NULL,1,'2025-12-12 16:00:00'),(38,1,'testTask','renren',0,NULL,1,'2025-12-12 16:30:00'),(39,1,'testTask','renren',0,NULL,1,'2025-12-12 17:00:00'),(40,1,'testTask','renren',0,NULL,0,'2025-12-12 17:30:00'),(41,1,'testTask','renren',0,NULL,1,'2025-12-12 18:00:00'),(42,1,'testTask','renren',0,NULL,0,'2025-12-12 18:30:00'),(43,1,'testTask','renren',0,NULL,1,'2025-12-12 19:00:00'),(44,1,'testTask','renren',0,NULL,0,'2025-12-12 19:30:00'),(45,1,'testTask','renren',0,NULL,0,'2025-12-12 20:00:00'),(46,1,'testTask','renren',0,NULL,0,'2025-12-12 20:30:00'),(47,1,'testTask','renren',0,NULL,0,'2025-12-12 21:00:00'),(48,1,'testTask','renren',0,NULL,1,'2025-12-12 21:30:00'),(49,1,'testTask','renren',0,NULL,0,'2025-12-12 22:00:00'),(50,1,'testTask','renren',0,NULL,0,'2025-12-12 22:30:00'),(51,1,'testTask','renren',0,NULL,0,'2025-12-12 23:00:00'),(52,1,'testTask','renren',0,NULL,0,'2025-12-12 23:30:00'),(53,1,'testTask','renren',0,NULL,1,'2025-12-13 00:00:00'),(54,1,'testTask','renren',0,NULL,0,'2025-12-13 00:30:00'),(55,1,'testTask','renren',0,NULL,1,'2025-12-13 01:00:00'),(56,1,'testTask','renren',0,NULL,1,'2025-12-13 01:30:00'),(57,1,'testTask','renren',0,NULL,1,'2025-12-13 02:00:00'),(58,1,'testTask','renren',0,NULL,0,'2025-12-13 02:30:00'),(59,1,'testTask','renren',0,NULL,1,'2025-12-13 03:00:00'),(60,1,'testTask','renren',0,NULL,0,'2025-12-13 03:30:00'),(61,1,'testTask','renren',0,NULL,0,'2025-12-13 04:00:00'),(62,1,'testTask','renren',0,NULL,0,'2025-12-13 04:30:00'),(63,1,'testTask','renren',0,NULL,1,'2025-12-13 05:00:00'),(64,1,'testTask','renren',0,NULL,0,'2025-12-13 05:30:00'),(65,1,'testTask','renren',0,NULL,0,'2025-12-13 06:00:00'),(66,1,'testTask','renren',0,NULL,0,'2025-12-13 06:30:00'),(67,1,'testTask','renren',0,NULL,1,'2025-12-13 07:00:00'),(68,1,'testTask','renren',0,NULL,1,'2025-12-13 07:30:00'),(69,1,'testTask','renren',0,NULL,0,'2025-12-13 08:00:00'),(70,1,'testTask','renren',0,NULL,0,'2025-12-13 08:30:00'),(71,1,'testTask','renren',0,NULL,0,'2025-12-13 09:00:00'),(72,1,'testTask','renren',0,NULL,0,'2025-12-13 09:30:00'),(73,1,'testTask','renren',0,NULL,1,'2025-12-13 10:00:00'),(74,1,'testTask','renren',0,NULL,0,'2025-12-13 10:30:00'),(75,1,'testTask','renren',0,NULL,1,'2025-12-13 11:00:00'),(76,1,'testTask','renren',0,NULL,0,'2025-12-13 11:30:00'),(77,1,'testTask','renren',0,NULL,0,'2025-12-13 12:00:00'),(78,1,'testTask','renren',0,NULL,1,'2025-12-13 12:30:00'),(79,1,'testTask','renren',0,NULL,0,'2025-12-13 13:00:00'),(80,1,'testTask','renren',0,NULL,0,'2025-12-13 13:30:00'),(81,1,'testTask','renren',0,NULL,1,'2025-12-13 14:00:00'),(82,1,'testTask','renren',0,NULL,0,'2025-12-13 14:30:00'),(83,1,'testTask','renren',0,NULL,1,'2025-12-13 15:00:00'),(84,1,'testTask','renren',0,NULL,0,'2025-12-13 15:30:00'),(85,1,'testTask','renren',0,NULL,0,'2025-12-13 16:00:00'),(86,1,'testTask','renren',0,NULL,0,'2025-12-13 16:30:00'),(87,1,'testTask','renren',0,NULL,0,'2025-12-13 17:00:00'),(88,1,'testTask','renren',0,NULL,0,'2025-12-13 17:30:00'),(89,1,'testTask','renren',0,NULL,1,'2025-12-13 18:00:00'),(90,1,'testTask','renren',0,NULL,0,'2025-12-13 18:30:00'),(91,1,'testTask','renren',0,NULL,0,'2025-12-13 19:00:00'),(92,1,'testTask','renren',0,NULL,1,'2025-12-13 19:30:00'),(93,1,'testTask','renren',0,NULL,1,'2025-12-13 20:00:00'),(94,1,'testTask','renren',0,NULL,1,'2025-12-13 20:30:00'),(95,1,'testTask','renren',0,NULL,1,'2025-12-13 21:00:00'),(96,1,'testTask','renren',0,NULL,0,'2025-12-13 21:30:00'),(97,1,'testTask','renren',0,NULL,0,'2025-12-13 22:00:00'),(98,1,'testTask','renren',0,NULL,0,'2025-12-13 22:30:00'),(99,1,'testTask','renren',0,NULL,1,'2025-12-13 23:00:00'),(100,1,'testTask','renren',0,NULL,1,'2025-12-13 23:30:00'),(101,1,'testTask','renren',0,NULL,4,'2025-12-14 00:00:00'),(102,1,'testTask','renren',0,NULL,0,'2025-12-14 00:30:00'),(103,1,'testTask','renren',0,NULL,0,'2025-12-14 01:00:00'),(104,1,'testTask','renren',0,NULL,0,'2025-12-14 01:30:00'),(105,1,'testTask','renren',0,NULL,0,'2025-12-14 02:00:00'),(106,1,'testTask','renren',0,NULL,1,'2025-12-14 02:30:00'),(107,1,'testTask','renren',0,NULL,0,'2025-12-14 03:00:00'),(108,1,'testTask','renren',0,NULL,0,'2025-12-14 03:30:00'),(109,1,'testTask','renren',0,NULL,1,'2025-12-14 04:00:00'),(110,1,'testTask','renren',0,NULL,1,'2025-12-14 04:30:00'),(111,1,'testTask','renren',0,NULL,1,'2025-12-14 05:00:00'),(112,1,'testTask','renren',0,NULL,1,'2025-12-14 05:30:00'),(113,1,'testTask','renren',0,NULL,1,'2025-12-14 06:00:00'),(114,1,'testTask','renren',0,NULL,1,'2025-12-14 06:30:00'),(115,1,'testTask','renren',0,NULL,1,'2025-12-14 07:00:00'),(116,1,'testTask','renren',0,NULL,1,'2025-12-14 07:30:00'),(117,1,'testTask','renren',0,NULL,1,'2025-12-14 08:00:00'),(118,1,'testTask','renren',0,NULL,0,'2025-12-14 08:30:00'),(119,1,'testTask','renren',0,NULL,0,'2025-12-14 09:00:00'),(120,1,'testTask','renren',0,NULL,1,'2025-12-14 09:30:00'),(121,1,'testTask','renren',0,NULL,0,'2025-12-14 10:00:00'),(122,1,'testTask','renren',0,NULL,0,'2025-12-14 10:30:00'),(123,1,'testTask','renren',0,NULL,0,'2025-12-14 11:00:00'),(124,1,'testTask','renren',0,NULL,0,'2025-12-14 11:30:00'),(125,1,'testTask','renren',0,NULL,1,'2025-12-14 12:00:00'),(126,1,'testTask','renren',0,NULL,0,'2025-12-14 12:30:00'),(127,1,'testTask','renren',0,NULL,0,'2025-12-14 13:00:00'),(128,1,'testTask','renren',0,NULL,1,'2025-12-14 13:30:00'),(129,1,'testTask','renren',0,NULL,1,'2025-12-14 14:00:00'),(130,1,'testTask','renren',0,NULL,0,'2025-12-14 14:30:00'),(131,1,'testTask','renren',0,NULL,1,'2025-12-14 15:00:00'),(132,1,'testTask','renren',0,NULL,0,'2025-12-14 15:30:00'),(133,1,'testTask','renren',0,NULL,0,'2025-12-14 16:00:00'),(134,1,'testTask','renren',0,NULL,1,'2025-12-14 16:30:00'),(135,1,'testTask','renren',0,NULL,0,'2025-12-14 17:00:00'),(136,1,'testTask','renren',0,NULL,0,'2025-12-14 17:30:00'),(137,1,'testTask','renren',0,NULL,0,'2025-12-14 18:00:00'),(138,1,'testTask','renren',0,NULL,0,'2025-12-14 18:30:00'),(139,1,'testTask','renren',0,NULL,1,'2025-12-14 19:00:00'),(140,1,'testTask','renren',0,NULL,1,'2025-12-14 19:30:00'),(141,1,'testTask','renren',0,NULL,1,'2025-12-14 20:00:00'),(142,1,'testTask','renren',0,NULL,0,'2025-12-14 20:30:00'),(143,1,'testTask','renren',0,NULL,0,'2025-12-14 21:00:00'),(144,1,'testTask','renren',0,NULL,1,'2025-12-14 21:30:00'),(145,1,'testTask','renren',0,NULL,0,'2025-12-14 22:00:00'),(146,1,'testTask','renren',0,NULL,1,'2025-12-14 22:30:00'),(147,1,'testTask','renren',0,NULL,0,'2025-12-14 23:00:00'),(148,1,'testTask','renren',0,NULL,0,'2025-12-14 23:30:00'),(149,1,'testTask','renren',0,NULL,3,'2025-12-15 00:00:00'),(150,1,'testTask','renren',0,NULL,1,'2025-12-15 00:30:00'),(151,1,'testTask','renren',0,NULL,1,'2025-12-15 01:00:00'),(152,1,'testTask','renren',0,NULL,0,'2025-12-15 01:30:00'),(153,1,'testTask','renren',0,NULL,0,'2025-12-15 02:00:00'),(154,1,'testTask','renren',0,NULL,2,'2025-12-15 02:30:00'),(155,1,'testTask','renren',0,NULL,1,'2025-12-15 03:00:00'),(156,1,'testTask','renren',0,NULL,1,'2025-12-15 03:30:00'),(157,1,'testTask','renren',0,NULL,0,'2025-12-15 04:00:00'),(158,1,'testTask','renren',0,NULL,1,'2025-12-15 04:30:00'),(159,1,'testTask','renren',0,NULL,0,'2025-12-15 05:00:00'),(160,1,'testTask','renren',0,NULL,0,'2025-12-15 05:30:00'),(161,1,'testTask','renren',0,NULL,0,'2025-12-15 06:00:00'),(162,1,'testTask','renren',0,NULL,0,'2025-12-15 06:30:00'),(163,1,'testTask','renren',0,NULL,0,'2025-12-15 07:00:00'),(164,1,'testTask','renren',0,NULL,0,'2025-12-15 07:30:00'),(165,1,'testTask','renren',0,NULL,1,'2025-12-15 08:00:00'),(166,1,'testTask','renren',0,NULL,1,'2025-12-15 08:30:00'),(167,1,'testTask','renren',0,NULL,0,'2025-12-15 09:00:00'),(168,1,'testTask','renren',0,NULL,1,'2025-12-15 09:30:00'),(169,1,'testTask','renren',0,NULL,1,'2025-12-15 11:00:00'),(170,1,'testTask','renren',0,NULL,1,'2025-12-15 11:30:00'),(171,1,'testTask','renren',0,NULL,2,'2025-12-15 12:00:00'),(172,1,'testTask','renren',0,NULL,2,'2025-12-15 12:30:00'),(173,1,'testTask','renren',0,NULL,1,'2025-12-15 13:00:00'),(174,1,'testTask','renren',0,NULL,1,'2025-12-15 13:30:00'),(175,1,'testTask','renren',0,NULL,1,'2025-12-15 14:00:00'),(176,1,'testTask','renren',0,NULL,0,'2025-12-15 14:30:00'),(177,1,'testTask','renren',0,NULL,0,'2025-12-15 15:00:00'),(178,1,'testTask','renren',0,NULL,0,'2025-12-15 15:30:00'),(179,1,'testTask','renren',0,NULL,1,'2025-12-15 16:00:00'),(180,1,'testTask','renren',0,NULL,0,'2025-12-15 16:30:00'),(181,1,'testTask','renren',0,NULL,0,'2025-12-15 17:00:00'),(182,1,'testTask','renren',0,NULL,0,'2025-12-15 17:30:00'),(183,1,'testTask','renren',0,NULL,0,'2025-12-15 18:00:00'),(184,1,'testTask','renren',0,NULL,1,'2025-12-15 18:30:00'),(185,1,'testTask','renren',0,NULL,0,'2025-12-15 19:00:00'),(186,1,'testTask','renren',0,NULL,1,'2025-12-15 19:30:00'),(187,1,'testTask','renren',0,NULL,1,'2025-12-15 20:00:00'),(188,1,'testTask','renren',0,NULL,1,'2025-12-15 20:30:00'),(189,1,'testTask','renren',0,NULL,1,'2025-12-15 21:00:00'),(190,1,'testTask','renren',0,NULL,0,'2025-12-15 21:30:00'),(191,1,'testTask','renren',0,NULL,1,'2025-12-15 22:00:00'),(192,1,'testTask','renren',0,NULL,0,'2025-12-15 22:30:00'),(193,1,'testTask','renren',0,NULL,1,'2025-12-15 23:00:00'),(194,1,'testTask','renren',0,NULL,0,'2025-12-15 23:30:00'),(195,1,'testTask','renren',0,NULL,4,'2025-12-16 00:00:00'),(196,1,'testTask','renren',0,NULL,0,'2025-12-16 00:30:00'),(197,1,'testTask','renren',0,NULL,0,'2025-12-16 01:00:00'),(198,1,'testTask','renren',0,NULL,0,'2025-12-16 01:30:00'),(199,1,'testTask','renren',0,NULL,1,'2025-12-16 02:00:00'),(200,1,'testTask','renren',0,NULL,0,'2025-12-16 02:30:00'),(201,1,'testTask','renren',0,NULL,1,'2025-12-16 03:00:00'),(202,1,'testTask','renren',0,NULL,1,'2025-12-16 03:30:00'),(203,1,'testTask','renren',0,NULL,0,'2025-12-16 04:00:00'),(204,1,'testTask','renren',0,NULL,1,'2025-12-16 04:30:00'),(205,1,'testTask','renren',0,NULL,0,'2025-12-16 05:00:00'),(206,1,'testTask','renren',0,NULL,0,'2025-12-16 05:30:00'),(207,1,'testTask','renren',0,NULL,1,'2025-12-16 06:00:00'),(208,1,'testTask','renren',0,NULL,0,'2025-12-16 06:30:00'),(209,1,'testTask','renren',0,NULL,0,'2025-12-16 07:00:00'),(210,1,'testTask','renren',0,NULL,1,'2025-12-16 07:30:00'),(211,1,'testTask','renren',0,NULL,0,'2025-12-16 08:00:00'),(212,1,'testTask','renren',0,NULL,0,'2025-12-16 08:30:00'),(213,1,'testTask','renren',0,NULL,0,'2025-12-16 09:00:00'),(214,1,'testTask','renren',0,NULL,0,'2025-12-16 09:30:00'),(215,1,'testTask','renren',0,NULL,1,'2025-12-16 10:00:00'),(216,1,'testTask','renren',0,NULL,0,'2025-12-16 10:30:00'),(217,1,'testTask','renren',0,NULL,1,'2025-12-16 11:00:00'),(218,1,'testTask','renren',0,NULL,0,'2025-12-16 11:30:00'),(219,1,'testTask','renren',0,NULL,1,'2025-12-16 12:00:00'),(220,1,'testTask','renren',0,NULL,1,'2025-12-16 12:30:00'),(221,1,'testTask','renren',0,NULL,1,'2025-12-16 14:00:00'),(222,1,'testTask','renren',0,NULL,1,'2025-12-16 14:30:00'),(223,1,'testTask','renren',0,NULL,0,'2025-12-16 15:00:00'),(224,1,'testTask','renren',0,NULL,0,'2025-12-16 15:30:00'),(225,1,'testTask','renren',0,NULL,0,'2025-12-16 16:00:00'),(226,1,'testTask','renren',0,NULL,0,'2025-12-16 16:30:00'),(227,1,'testTask','renren',0,NULL,0,'2025-12-16 17:00:00'),(228,1,'testTask','renren',0,NULL,1,'2025-12-16 17:30:00'),(229,1,'testTask','renren',0,NULL,1,'2025-12-16 18:00:00'),(230,1,'testTask','renren',0,NULL,0,'2025-12-16 18:30:00'),(231,1,'testTask','renren',0,NULL,1,'2025-12-16 19:00:00'),(232,1,'testTask','renren',0,NULL,0,'2025-12-16 19:30:00'),(233,1,'testTask','renren',0,NULL,1,'2025-12-16 20:00:00'),(234,1,'testTask','renren',0,NULL,1,'2025-12-16 20:30:00'),(235,1,'testTask','renren',0,NULL,1,'2025-12-16 21:00:00'),(236,1,'testTask','renren',0,NULL,1,'2025-12-16 21:30:00'),(237,1,'testTask','renren',0,NULL,1,'2025-12-16 22:00:00'),(238,1,'testTask','renren',0,NULL,0,'2025-12-16 22:30:00'),(239,1,'testTask','renren',0,NULL,2,'2025-12-16 23:00:00'),(240,1,'testTask','renren',0,NULL,1,'2025-12-16 23:30:00'),(241,1,'testTask','renren',0,NULL,2,'2025-12-17 00:00:00'),(242,1,'testTask','renren',0,NULL,0,'2025-12-17 00:30:00'),(243,1,'testTask','renren',0,NULL,1,'2025-12-17 01:00:00'),(244,1,'testTask','renren',0,NULL,1,'2025-12-17 01:30:00'),(245,1,'testTask','renren',0,NULL,1,'2025-12-17 02:00:00'),(246,1,'testTask','renren',0,NULL,0,'2025-12-17 02:30:00'),(247,1,'testTask','renren',0,NULL,0,'2025-12-17 03:00:00'),(248,1,'testTask','renren',0,NULL,0,'2025-12-17 03:30:00'),(249,1,'testTask','renren',0,NULL,0,'2025-12-17 04:00:00'),(250,1,'testTask','renren',0,NULL,0,'2025-12-17 04:30:00'),(251,1,'testTask','renren',0,NULL,1,'2025-12-17 05:00:00'),(252,1,'testTask','renren',0,NULL,1,'2025-12-17 05:30:00'),(253,1,'testTask','renren',0,NULL,0,'2025-12-17 06:00:00'),(254,1,'testTask','renren',0,NULL,0,'2025-12-17 06:30:00'),(255,1,'testTask','renren',0,NULL,0,'2025-12-17 07:00:00'),(256,1,'testTask','renren',0,NULL,0,'2025-12-17 07:30:00'),(257,1,'testTask','renren',0,NULL,0,'2025-12-17 08:00:00'),(258,1,'testTask','renren',0,NULL,0,'2025-12-17 08:30:00'),(259,1,'testTask','renren',0,NULL,2,'2025-12-17 09:00:00'),(260,1,'testTask','renren',0,NULL,1,'2025-12-17 09:30:00'),(261,1,'testTask','renren',0,NULL,1,'2025-12-17 10:00:00'),(262,1,'testTask','renren',0,NULL,0,'2025-12-17 10:30:00'),(263,1,'testTask','renren',0,NULL,1,'2025-12-17 11:00:00'),(264,1,'testTask','renren',0,NULL,0,'2025-12-17 11:30:00'),(265,1,'testTask','renren',0,NULL,0,'2025-12-17 12:00:00'),(266,1,'testTask','renren',0,NULL,0,'2025-12-17 12:30:00'),(267,1,'testTask','renren',0,NULL,2,'2025-12-17 13:00:00'),(268,1,'testTask','renren',0,NULL,0,'2025-12-17 13:30:00'),(269,1,'testTask','renren',0,NULL,1,'2025-12-17 14:00:00'),(270,1,'testTask','renren',0,NULL,1,'2025-12-17 14:30:00'),(271,1,'testTask','renren',0,NULL,1,'2025-12-17 15:00:00'),(272,1,'testTask','renren',0,NULL,0,'2025-12-17 15:30:00'),(273,1,'testTask','renren',0,NULL,1,'2025-12-17 16:00:00'),(274,1,'testTask','renren',0,NULL,1,'2025-12-17 16:30:00'),(275,1,'testTask','renren',0,NULL,1,'2025-12-18 10:00:00'),(276,1,'testTask','renren',0,NULL,0,'2025-12-18 12:00:00'),(277,1,'testTask','renren',0,NULL,0,'2025-12-18 12:30:00'),(278,1,'testTask','renren',0,NULL,1,'2025-12-18 13:00:00'),(279,1,'testTask','renren',0,NULL,1,'2025-12-18 13:30:00'),(280,1,'testTask','renren',0,NULL,0,'2025-12-18 14:00:00'),(281,1,'testTask','renren',0,NULL,1,'2025-12-18 14:30:00'),(282,1,'testTask','renren',0,NULL,0,'2025-12-18 15:00:00'),(283,1,'testTask','renren',0,NULL,0,'2025-12-18 15:30:00'),(284,1,'testTask','renren',0,NULL,1,'2025-12-19 16:30:00'),(285,1,'testTask','renren',0,NULL,1,'2025-12-19 17:00:00'),(286,1,'testTask','renren',0,NULL,0,'2025-12-19 17:30:00'),(287,1,'testTask','renren',0,NULL,0,'2025-12-19 18:00:00'),(288,1,'testTask','renren',0,NULL,0,'2025-12-19 18:30:00'),(289,1,'testTask','renren',0,NULL,0,'2025-12-19 19:00:00'),(290,1,'testTask','renren',0,NULL,1,'2025-12-19 19:30:00'),(291,1,'testTask','renren',0,NULL,0,'2025-12-19 20:00:00'),(292,1,'testTask','renren',0,NULL,0,'2025-12-19 20:30:00'),(293,1,'testTask','renren',0,NULL,1,'2025-12-19 21:00:00'),(294,1,'testTask','renren',0,NULL,0,'2025-12-22 14:00:00'),(295,1,'testTask','renren',0,NULL,1,'2025-12-22 14:30:00'),(296,1,'testTask','renren',0,NULL,0,'2025-12-22 15:00:00'),(297,1,'testTask','renren',0,NULL,1,'2025-12-22 15:30:00'),(298,1,'testTask','renren',0,NULL,0,'2025-12-22 16:00:00'),(299,1,'testTask','renren',0,NULL,0,'2025-12-22 16:30:00'),(300,1,'testTask','renren',0,NULL,0,'2025-12-22 17:00:00'),(301,1,'testTask','renren',0,NULL,0,'2025-12-22 17:30:00'),(302,1,'testTask','renren',0,NULL,1,'2025-12-22 18:00:00'),(303,1,'testTask','renren',0,NULL,1,'2025-12-22 18:30:00'),(304,1,'testTask','renren',0,NULL,1,'2025-12-22 19:00:00'),(305,1,'testTask','renren',0,NULL,1,'2025-12-22 19:30:00'),(306,1,'testTask','renren',0,NULL,0,'2025-12-22 20:00:00'),(307,1,'testTask','renren',0,NULL,0,'2025-12-22 20:30:00'),(308,1,'testTask','renren',0,NULL,1,'2025-12-22 21:00:00'),(309,1,'testTask','renren',0,NULL,0,'2025-12-22 21:30:00'),(310,1,'testTask','renren',0,NULL,1,'2025-12-22 22:00:00'),(311,1,'testTask','renren',0,NULL,1,'2025-12-22 22:30:00'),(312,1,'testTask','renren',0,NULL,0,'2025-12-22 23:00:00'),(313,1,'testTask','renren',0,NULL,0,'2025-12-22 23:30:00'),(314,1,'testTask','renren',0,NULL,3,'2025-12-23 00:00:00'),(315,1,'testTask','renren',0,NULL,1,'2025-12-23 00:30:00'),(316,1,'testTask','renren',0,NULL,0,'2025-12-23 01:00:00'),(317,1,'testTask','renren',0,NULL,0,'2025-12-23 01:30:00'),(318,1,'testTask','renren',0,NULL,0,'2025-12-23 02:00:00'),(319,1,'testTask','renren',0,NULL,2,'2025-12-23 02:30:00'),(320,1,'testTask','renren',0,NULL,1,'2025-12-23 03:00:00'),(321,1,'testTask','renren',0,NULL,1,'2025-12-23 03:30:00'),(322,1,'testTask','renren',0,NULL,0,'2025-12-23 04:00:00'),(323,1,'testTask','renren',0,NULL,1,'2025-12-23 04:30:00'),(324,1,'testTask','renren',0,NULL,1,'2025-12-23 05:00:00'),(325,1,'testTask','renren',0,NULL,0,'2025-12-23 05:30:00'),(326,1,'testTask','renren',0,NULL,0,'2025-12-23 06:00:00'),(327,1,'testTask','renren',0,NULL,0,'2025-12-23 06:30:00'),(328,1,'testTask','renren',0,NULL,1,'2025-12-23 07:00:00'),(329,1,'testTask','renren',0,NULL,0,'2025-12-23 07:30:00'),(330,1,'testTask','renren',0,NULL,0,'2025-12-23 08:00:00'),(331,1,'testTask','renren',0,NULL,0,'2025-12-23 08:30:00'),(332,1,'testTask','renren',0,NULL,1,'2025-12-23 09:00:00'),(333,1,'testTask','renren',0,NULL,0,'2025-12-23 09:30:00'),(334,1,'testTask','renren',0,NULL,0,'2025-12-23 10:00:00'),(335,1,'testTask','renren',0,NULL,1,'2025-12-23 10:30:00'),(336,1,'testTask','renren',0,NULL,0,'2025-12-23 11:00:00'),(337,1,'testTask','renren',0,NULL,0,'2025-12-23 11:30:00'),(338,1,'testTask','renren',0,NULL,2,'2025-12-23 12:00:00'),(339,1,'testTask','renren',0,NULL,1,'2025-12-23 12:30:00'),(340,1,'testTask','renren',0,NULL,0,'2025-12-23 13:00:00'),(341,1,'testTask','renren',0,NULL,1,'2025-12-23 13:30:00'),(342,1,'testTask','renren',0,NULL,0,'2025-12-23 14:00:00'),(343,1,'testTask','renren',0,NULL,1,'2025-12-23 14:30:00'),(344,1,'testTask','renren',0,NULL,1,'2025-12-23 15:00:00'),(345,1,'testTask','renren',0,NULL,1,'2025-12-23 15:30:00'),(346,1,'testTask','renren',0,NULL,0,'2025-12-23 16:00:00'),(347,1,'testTask','renren',0,NULL,3,'2025-12-23 16:30:00'),(348,1,'testTask','renren',0,NULL,1,'2025-12-24 12:30:00'),(349,1,'testTask','renren',0,NULL,1,'2025-12-24 13:00:00'),(350,1,'testTask','renren',0,NULL,1,'2025-12-24 13:30:00'),(351,1,'testTask','renren',0,NULL,0,'2025-12-24 14:00:00'),(352,1,'testTask','renren',0,NULL,1,'2025-12-24 14:30:00'),(353,1,'testTask','renren',0,NULL,0,'2025-12-24 15:00:00'),(354,1,'testTask','renren',0,NULL,1,'2025-12-24 15:30:00'),(355,1,'testTask','renren',0,NULL,1,'2025-12-24 16:00:00'),(356,1,'testTask','renren',0,NULL,2,'2025-12-24 16:30:00'),(357,1,'testTask','renren',0,NULL,1,'2025-12-24 17:00:00'),(358,1,'testTask','renren',0,NULL,0,'2025-12-24 17:30:00'),(359,1,'testTask','renren',0,NULL,0,'2025-12-24 18:00:00'),(360,1,'testTask','renren',0,NULL,1,'2025-12-24 18:30:00'),(361,1,'testTask','renren',0,NULL,0,'2025-12-24 19:00:00'),(362,1,'testTask','renren',0,NULL,1,'2025-12-24 19:30:00'),(363,1,'testTask','renren',0,NULL,0,'2025-12-24 20:00:00'),(364,1,'testTask','renren',0,NULL,1,'2025-12-24 20:30:00'),(365,1,'testTask','renren',0,NULL,0,'2025-12-24 21:00:00'),(366,1,'testTask','renren',0,NULL,1,'2025-12-24 21:30:00'),(367,1,'testTask','renren',0,NULL,1,'2025-12-24 22:00:00'),(368,1,'testTask','renren',0,NULL,0,'2025-12-24 22:30:00'),(369,1,'testTask','renren',0,NULL,0,'2025-12-24 23:00:00'),(370,1,'testTask','renren',0,NULL,0,'2025-12-24 23:30:00'),(371,1,'testTask','renren',0,NULL,3,'2025-12-25 00:00:00'),(372,1,'testTask','renren',0,NULL,1,'2025-12-25 00:30:00'),(373,1,'testTask','renren',0,NULL,0,'2025-12-25 01:00:00'),(374,1,'testTask','renren',0,NULL,1,'2025-12-25 01:30:00'),(375,1,'testTask','renren',0,NULL,1,'2025-12-25 02:00:00'),(376,1,'testTask','renren',0,NULL,0,'2025-12-25 02:30:00'),(377,1,'testTask','renren',0,NULL,0,'2025-12-25 03:00:00'),(378,1,'testTask','renren',0,NULL,1,'2025-12-25 03:30:00'),(379,1,'testTask','renren',0,NULL,1,'2025-12-25 04:00:00'),(380,1,'testTask','renren',0,NULL,1,'2025-12-25 04:30:00'),(381,1,'testTask','renren',0,NULL,0,'2025-12-25 05:00:00'),(382,1,'testTask','renren',0,NULL,0,'2025-12-25 05:30:00'),(383,1,'testTask','renren',0,NULL,0,'2025-12-25 06:00:00'),(384,1,'testTask','renren',0,NULL,0,'2025-12-25 06:30:00'),(385,1,'testTask','renren',0,NULL,0,'2025-12-25 07:00:00'),(386,1,'testTask','renren',0,NULL,0,'2025-12-25 07:30:00'),(387,1,'testTask','renren',0,NULL,0,'2025-12-25 08:00:00'),(388,1,'testTask','renren',0,NULL,0,'2025-12-25 08:30:00'),(389,1,'testTask','renren',0,NULL,0,'2025-12-25 09:00:00'),(390,1,'testTask','renren',0,NULL,1,'2025-12-25 09:30:00'),(391,1,'testTask','renren',0,NULL,0,'2025-12-25 10:00:00'),(392,1,'testTask','renren',0,NULL,0,'2025-12-25 10:30:00'),(393,1,'testTask','renren',0,NULL,1,'2025-12-25 11:00:00'),(394,1,'testTask','renren',0,NULL,0,'2025-12-25 11:30:00'),(395,1,'testTask','renren',0,NULL,1,'2025-12-25 12:00:00'),(396,1,'testTask','renren',0,NULL,0,'2025-12-25 12:30:00'),(397,1,'testTask','renren',0,NULL,0,'2025-12-25 13:00:00'),(398,1,'testTask','renren',0,NULL,1,'2025-12-25 13:30:00'),(399,1,'testTask','renren',0,NULL,0,'2025-12-25 14:00:00'),(400,1,'testTask','renren',0,NULL,1,'2025-12-25 14:30:00'),(401,1,'testTask','renren',0,NULL,1,'2025-12-25 15:00:00'),(402,1,'testTask','renren',0,NULL,0,'2025-12-25 15:30:00'),(403,1,'testTask','renren',0,NULL,0,'2025-12-25 16:00:00'),(404,1,'testTask','renren',0,NULL,1,'2025-12-25 16:30:00'),(405,1,'testTask','renren',0,NULL,0,'2025-12-25 17:00:00'),(406,1,'testTask','renren',0,NULL,1,'2025-12-25 17:30:00'),(407,1,'testTask','renren',0,NULL,1,'2025-12-25 18:00:00'),(408,1,'testTask','renren',0,NULL,2,'2025-12-25 18:30:00'),(409,1,'testTask','renren',0,NULL,1,'2025-12-25 19:00:00'),(410,1,'testTask','renren',0,NULL,1,'2025-12-25 19:30:00'),(411,1,'testTask','renren',0,NULL,1,'2025-12-25 20:00:00'),(412,1,'testTask','renren',0,NULL,1,'2025-12-25 20:30:00'),(413,1,'testTask','renren',0,NULL,1,'2025-12-25 21:00:00'),(414,1,'testTask','renren',0,NULL,0,'2025-12-25 21:30:00'),(415,1,'testTask','renren',0,NULL,0,'2025-12-25 22:00:00'),(416,1,'testTask','renren',0,NULL,1,'2025-12-25 22:30:00'),(417,1,'testTask','renren',0,NULL,1,'2025-12-25 23:00:00'),(418,1,'testTask','renren',0,NULL,0,'2025-12-25 23:30:00'),(419,1,'testTask','renren',0,NULL,2,'2025-12-26 00:00:00'),(420,1,'testTask','renren',0,NULL,0,'2025-12-26 00:30:00'),(421,1,'testTask','renren',0,NULL,0,'2025-12-26 01:00:00'),(422,1,'testTask','renren',0,NULL,2,'2025-12-26 01:30:00'),(423,1,'testTask','renren',0,NULL,0,'2025-12-26 02:00:00'),(424,1,'testTask','renren',0,NULL,0,'2025-12-26 02:30:00'),(425,1,'testTask','renren',0,NULL,1,'2025-12-26 03:00:00'),(426,1,'testTask','renren',0,NULL,0,'2025-12-26 03:30:00'),(427,1,'testTask','renren',0,NULL,0,'2025-12-26 04:00:00'),(428,1,'testTask','renren',0,NULL,0,'2025-12-26 04:30:00'),(429,1,'testTask','renren',0,NULL,1,'2025-12-26 05:00:00'),(430,1,'testTask','renren',0,NULL,0,'2025-12-26 05:30:00'),(431,1,'testTask','renren',0,NULL,0,'2025-12-26 06:00:00'),(432,1,'testTask','renren',0,NULL,0,'2025-12-26 06:30:00'),(433,1,'testTask','renren',0,NULL,0,'2025-12-26 07:00:00'),(434,1,'testTask','renren',0,NULL,0,'2025-12-26 07:30:00'),(435,1,'testTask','renren',0,NULL,0,'2025-12-26 08:00:00'),(436,1,'testTask','renren',0,NULL,0,'2025-12-26 08:30:00'),(437,1,'testTask','renren',0,NULL,1,'2025-12-26 09:00:00'),(438,1,'testTask','renren',0,NULL,1,'2025-12-26 09:30:00'),(439,1,'testTask','renren',0,NULL,2,'2025-12-26 10:00:00'),(440,1,'testTask','renren',0,NULL,1,'2025-12-26 10:30:00'),(441,1,'testTask','renren',0,NULL,0,'2025-12-26 11:00:00'),(442,1,'testTask','renren',0,NULL,1,'2025-12-26 11:30:00'),(443,1,'testTask','renren',0,NULL,0,'2025-12-26 12:00:00'),(444,1,'testTask','renren',0,NULL,1,'2025-12-26 12:30:00'),(445,1,'testTask','renren',0,NULL,0,'2025-12-26 13:00:00'),(446,1,'testTask','renren',0,NULL,1,'2025-12-26 13:30:00'),(447,1,'testTask','renren',0,NULL,0,'2025-12-26 14:00:00'),(448,1,'testTask','renren',0,NULL,0,'2025-12-26 15:00:00'),(449,1,'testTask','renren',0,NULL,0,'2025-12-26 15:30:00'),(450,1,'testTask','renren',0,NULL,0,'2025-12-26 16:00:00'),(451,1,'testTask','renren',0,NULL,2,'2025-12-26 16:30:00'),(452,1,'testTask','renren',0,NULL,1,'2025-12-29 13:30:00'),(453,1,'testTask','renren',0,NULL,1,'2025-12-29 14:00:00'),(454,1,'testTask','renren',0,NULL,1,'2025-12-29 14:30:00'),(455,1,'testTask','renren',0,NULL,1,'2025-12-29 15:00:00'),(456,1,'testTask','renren',0,NULL,0,'2025-12-29 15:30:00'),(457,1,'testTask','renren',0,NULL,0,'2025-12-29 16:00:00'),(458,1,'testTask','renren',0,NULL,1,'2025-12-29 16:30:00'),(459,1,'testTask','renren',0,NULL,0,'2025-12-29 17:00:00'),(460,1,'testTask','renren',0,NULL,2,'2025-12-29 17:30:00'),(461,1,'testTask','renren',0,NULL,1,'2025-12-29 18:00:00'),(462,1,'testTask','renren',0,NULL,2,'2025-12-29 18:30:00'),(463,1,'testTask','renren',0,NULL,0,'2025-12-29 19:00:00'),(464,1,'testTask','renren',0,NULL,1,'2025-12-29 19:30:00'),(465,1,'testTask','renren',0,NULL,0,'2025-12-29 20:00:00'),(466,1,'testTask','renren',0,NULL,0,'2025-12-29 20:30:00'),(467,1,'testTask','renren',0,NULL,1,'2025-12-29 21:00:00'),(468,1,'testTask','renren',0,NULL,1,'2025-12-29 21:30:00'),(469,1,'testTask','renren',0,NULL,0,'2025-12-29 22:00:00'),(470,1,'testTask','renren',0,NULL,0,'2025-12-29 22:30:00'),(471,1,'testTask','renren',0,NULL,0,'2025-12-29 23:00:00'),(472,1,'testTask','renren',0,NULL,0,'2025-12-29 23:30:00'),(473,1,'testTask','renren',0,NULL,4,'2025-12-30 00:00:00'),(474,1,'testTask','renren',0,NULL,0,'2025-12-30 00:30:00'),(475,1,'testTask','renren',0,NULL,0,'2025-12-30 01:00:00'),(476,1,'testTask','renren',0,NULL,1,'2025-12-30 01:30:00'),(477,1,'testTask','renren',0,NULL,0,'2025-12-30 02:00:00'),(478,1,'testTask','renren',0,NULL,0,'2025-12-30 02:30:00'),(479,1,'testTask','renren',0,NULL,1,'2025-12-30 03:00:00'),(480,1,'testTask','renren',0,NULL,0,'2025-12-30 03:30:00'),(481,1,'testTask','renren',0,NULL,0,'2025-12-30 04:00:00'),(482,1,'testTask','renren',0,NULL,1,'2025-12-30 04:30:00'),(483,1,'testTask','renren',0,NULL,2,'2025-12-30 05:00:00'),(484,1,'testTask','renren',0,NULL,1,'2025-12-30 05:30:00'),(485,1,'testTask','renren',0,NULL,0,'2025-12-30 06:00:00'),(486,1,'testTask','renren',0,NULL,1,'2025-12-30 06:30:00'),(487,1,'testTask','renren',0,NULL,0,'2025-12-30 07:00:00'),(488,1,'testTask','renren',0,NULL,0,'2025-12-30 07:30:00'),(489,1,'testTask','renren',0,NULL,1,'2025-12-30 08:00:00'),(490,1,'testTask','renren',0,NULL,0,'2025-12-30 08:30:00'),(491,1,'testTask','renren',0,NULL,1,'2025-12-30 09:00:00'),(492,1,'testTask','renren',0,NULL,0,'2025-12-30 09:30:00'),(493,1,'testTask','renren',0,NULL,0,'2025-12-30 10:00:00'),(494,1,'testTask','renren',0,NULL,1,'2025-12-30 10:30:00'),(495,1,'testTask','renren',0,NULL,0,'2025-12-30 11:00:00'),(496,1,'testTask','renren',0,NULL,0,'2025-12-30 11:30:00'),(497,1,'testTask','renren',0,NULL,1,'2025-12-30 12:00:00'),(498,1,'testTask','renren',0,NULL,0,'2025-12-30 12:30:00'),(499,1,'testTask','renren',0,NULL,0,'2025-12-30 13:00:00'),(500,1,'testTask','renren',0,NULL,0,'2025-12-30 13:30:00'),(501,1,'testTask','renren',0,NULL,0,'2025-12-30 14:00:00'),(502,1,'testTask','renren',0,NULL,0,'2025-12-30 14:30:00'),(503,1,'testTask','renren',0,NULL,0,'2025-12-30 15:00:00'),(504,1,'testTask','renren',0,NULL,0,'2025-12-30 15:30:00'),(505,1,'testTask','renren',0,NULL,0,'2025-12-30 16:00:00'),(506,1,'testTask','renren',0,NULL,1,'2025-12-30 16:30:00'),(507,1,'testTask','renren',0,NULL,0,'2025-12-30 17:00:00'),(508,1,'testTask','renren',0,NULL,0,'2025-12-30 17:30:00'),(509,1,'testTask','renren',0,NULL,0,'2025-12-30 18:00:00'),(510,1,'testTask','renren',0,NULL,0,'2025-12-30 18:30:00'),(511,1,'testTask','renren',0,NULL,0,'2025-12-30 19:00:00'),(512,1,'testTask','renren',0,NULL,0,'2025-12-30 19:30:00'),(513,1,'testTask','renren',0,NULL,1,'2025-12-30 20:00:00'),(514,1,'testTask','renren',0,NULL,1,'2025-12-30 20:30:00'),(515,1,'testTask','renren',0,NULL,1,'2025-12-30 21:00:00'),(516,1,'testTask','renren',0,NULL,2,'2025-12-30 21:30:00'),(517,1,'testTask','renren',0,NULL,1,'2025-12-30 22:00:00'),(518,1,'testTask','renren',0,NULL,0,'2025-12-30 22:30:00'),(519,1,'testTask','renren',0,NULL,0,'2025-12-30 23:00:00'),(520,1,'testTask','renren',0,NULL,0,'2025-12-30 23:30:00'),(521,1,'testTask','renren',0,NULL,2,'2025-12-31 00:00:00'),(522,1,'testTask','renren',0,NULL,1,'2025-12-31 00:30:00'),(523,1,'testTask','renren',0,NULL,1,'2025-12-31 01:00:00'),(524,1,'testTask','renren',0,NULL,0,'2025-12-31 01:30:00'),(525,1,'testTask','renren',0,NULL,0,'2026-01-05 14:00:00'),(526,1,'testTask','renren',0,NULL,0,'2026-01-05 14:30:00'),(527,1,'testTask','renren',0,NULL,0,'2026-01-05 15:00:00'),(528,1,'testTask','renren',0,NULL,0,'2026-01-05 15:30:00'),(529,1,'testTask','renren',0,NULL,0,'2026-01-05 16:00:00'),(530,1,'testTask','renren',0,NULL,0,'2026-01-05 16:30:00'),(531,1,'testTask','renren',0,NULL,1,'2026-01-05 17:00:00'),(532,1,'testTask','renren',0,NULL,1,'2026-01-05 17:30:00'),(533,1,'testTask','renren',0,NULL,0,'2026-01-05 18:00:00'),(534,1,'testTask','renren',0,NULL,0,'2026-01-05 18:30:00'),(535,1,'testTask','renren',0,NULL,1,'2026-01-05 19:00:00'),(536,1,'testTask','renren',0,NULL,1,'2026-01-05 19:30:00'),(537,1,'testTask','renren',0,NULL,1,'2026-01-05 20:00:00'),(538,1,'testTask','renren',0,NULL,1,'2026-01-05 20:30:00'),(539,1,'testTask','renren',0,NULL,1,'2026-01-05 21:00:00'),(540,1,'testTask','renren',0,NULL,1,'2026-01-05 21:30:00'),(541,1,'testTask','renren',0,NULL,0,'2026-01-05 22:00:00'),(542,1,'testTask','renren',0,NULL,0,'2026-01-05 22:30:00'),(543,1,'testTask','renren',0,NULL,0,'2026-01-05 23:00:00'),(544,1,'testTask','renren',0,NULL,1,'2026-01-05 23:30:00'),(545,1,'testTask','renren',0,NULL,7,'2026-01-06 00:00:00'),(546,1,'testTask','renren',0,NULL,1,'2026-01-06 00:30:00'),(547,1,'testTask','renren',0,NULL,0,'2026-01-06 01:00:00'),(548,1,'testTask','renren',0,NULL,0,'2026-01-06 01:30:00'),(549,1,'testTask','renren',0,NULL,1,'2026-01-06 02:00:00'),(550,1,'testTask','renren',0,NULL,0,'2026-01-06 02:30:00'),(551,1,'testTask','renren',0,NULL,1,'2026-01-06 03:00:00'),(552,1,'testTask','renren',0,NULL,0,'2026-01-06 03:30:00'),(553,1,'testTask','renren',0,NULL,1,'2026-01-06 04:00:00'),(554,1,'testTask','renren',0,NULL,0,'2026-01-06 04:30:00'),(555,1,'testTask','renren',0,NULL,1,'2026-01-06 05:00:00'),(556,1,'testTask','renren',0,NULL,0,'2026-01-06 05:30:00'),(557,1,'testTask','renren',0,NULL,0,'2026-01-06 06:00:00'),(558,1,'testTask','renren',0,NULL,0,'2026-01-06 06:30:00'),(559,1,'testTask','renren',0,NULL,0,'2026-01-06 07:00:00'),(560,1,'testTask','renren',0,NULL,1,'2026-01-06 07:30:00'),(561,1,'testTask','renren',0,NULL,0,'2026-01-06 08:00:00'),(562,1,'testTask','renren',0,NULL,1,'2026-01-06 08:30:00'),(563,1,'testTask','renren',0,NULL,1,'2026-01-06 09:00:00'),(564,1,'testTask','renren',0,NULL,0,'2026-01-06 09:30:00'),(565,1,'testTask','renren',0,NULL,0,'2026-01-06 10:00:00'),(566,1,'testTask','renren',0,NULL,0,'2026-01-06 10:30:00'),(567,1,'testTask','renren',0,NULL,0,'2026-01-06 11:00:00'),(568,1,'testTask','renren',0,NULL,0,'2026-01-06 11:30:00'),(569,1,'testTask','renren',0,NULL,1,'2026-01-06 12:00:00'),(570,1,'testTask','renren',0,NULL,0,'2026-01-06 12:30:00'),(571,1,'testTask','renren',0,NULL,0,'2026-01-06 13:00:00'),(572,1,'testTask','renren',0,NULL,0,'2026-01-06 13:30:00'),(573,1,'testTask','renren',0,NULL,1,'2026-01-06 14:00:00'),(574,1,'testTask','renren',0,NULL,0,'2026-01-06 14:30:00'),(575,1,'testTask','renren',0,NULL,0,'2026-01-06 15:00:00'),(576,1,'testTask','renren',0,NULL,1,'2026-01-06 15:30:00'),(577,1,'testTask','renren',0,NULL,0,'2026-01-06 16:00:00'),(578,1,'testTask','renren',0,NULL,2,'2026-01-06 16:30:00'),(579,1,'testTask','renren',0,NULL,1,'2026-01-06 17:00:00'),(580,1,'testTask','renren',0,NULL,2,'2026-01-06 17:30:00'),(581,1,'testTask','renren',0,NULL,1,'2026-01-06 18:00:00'),(582,1,'testTask','renren',0,NULL,0,'2026-01-06 18:30:00'),(583,1,'testTask','renren',0,NULL,0,'2026-01-06 19:00:00'),(584,1,'testTask','renren',0,NULL,0,'2026-01-06 19:30:00'),(585,1,'testTask','renren',0,NULL,0,'2026-01-06 20:00:00'),(586,1,'testTask','renren',0,NULL,0,'2026-01-06 20:30:00'),(587,1,'testTask','renren',0,NULL,0,'2026-01-06 21:00:00'),(588,1,'testTask','renren',0,NULL,0,'2026-01-06 21:30:00'),(589,1,'testTask','renren',0,NULL,1,'2026-01-06 22:00:00'),(590,1,'testTask','renren',0,NULL,0,'2026-01-06 22:30:00'),(591,1,'testTask','renren',0,NULL,1,'2026-01-06 23:00:00'),(592,1,'testTask','renren',0,NULL,0,'2026-01-06 23:30:00'),(593,1,'testTask','renren',0,NULL,10,'2026-01-07 00:00:00'),(594,1,'testTask','renren',0,NULL,1,'2026-01-07 00:30:00'),(595,1,'testTask','renren',0,NULL,1,'2026-01-07 01:00:00'),(596,1,'testTask','renren',0,NULL,0,'2026-01-07 01:30:00'),(597,1,'testTask','renren',0,NULL,1,'2026-01-07 02:00:00'),(598,1,'testTask','renren',0,NULL,0,'2026-01-07 02:30:00'),(599,1,'testTask','renren',0,NULL,1,'2026-01-07 03:00:00'),(600,1,'testTask','renren',0,NULL,1,'2026-01-07 03:30:00'),(601,1,'testTask','renren',0,NULL,0,'2026-01-07 04:00:00'),(602,1,'testTask','renren',0,NULL,1,'2026-01-07 04:30:00'),(603,1,'testTask','renren',0,NULL,1,'2026-01-07 05:00:00'),(604,1,'testTask','renren',0,NULL,0,'2026-01-07 05:30:00'),(605,1,'testTask','renren',0,NULL,0,'2026-01-07 06:00:00'),(606,1,'testTask','renren',0,NULL,0,'2026-01-07 06:30:00'),(607,1,'testTask','renren',0,NULL,1,'2026-01-07 07:00:00'),(608,1,'testTask','renren',0,NULL,1,'2026-01-07 07:30:00'),(609,1,'testTask','renren',0,NULL,0,'2026-01-07 08:00:00'),(610,1,'testTask','renren',0,NULL,0,'2026-01-07 08:30:00'),(611,1,'testTask','renren',0,NULL,0,'2026-01-07 09:00:00'),(612,1,'testTask','renren',0,NULL,1,'2026-01-07 09:30:00'),(613,1,'testTask','renren',0,NULL,0,'2026-01-07 10:00:00'),(614,1,'testTask','renren',0,NULL,0,'2026-01-07 10:30:00'),(615,1,'testTask','renren',0,NULL,1,'2026-01-07 11:00:00'),(616,1,'testTask','renren',0,NULL,1,'2026-01-07 11:30:00'),(617,1,'testTask','renren',0,NULL,0,'2026-01-07 12:00:00'),(618,1,'testTask','renren',0,NULL,1,'2026-01-07 12:30:00'),(619,1,'testTask','renren',0,NULL,1,'2026-01-07 13:00:00'),(620,1,'testTask','renren',0,NULL,1,'2026-01-07 13:30:00'),(621,1,'testTask','renren',0,NULL,0,'2026-01-07 14:00:00'),(622,1,'testTask','renren',0,NULL,0,'2026-01-07 14:30:00'),(623,1,'testTask','renren',0,NULL,0,'2026-01-07 15:00:00'),(624,1,'testTask','renren',0,NULL,0,'2026-01-07 15:30:00'),(625,1,'testTask','renren',0,NULL,0,'2026-01-07 16:00:00'),(626,1,'testTask','renren',0,NULL,0,'2026-01-07 16:30:00'),(627,1,'testTask','renren',0,NULL,0,'2026-01-07 17:30:00'),(628,1,'testTask','renren',0,NULL,0,'2026-01-07 18:00:00'),(629,1,'testTask','renren',0,NULL,0,'2026-01-07 18:30:00'),(630,1,'testTask','renren',0,NULL,0,'2026-01-07 19:00:00'),(631,1,'testTask','renren',0,NULL,0,'2026-01-07 19:30:00'),(632,1,'testTask','renren',0,NULL,1,'2026-01-07 20:00:00'),(633,1,'testTask','renren',0,NULL,1,'2026-01-07 20:30:00'),(634,1,'testTask','renren',0,NULL,1,'2026-01-07 21:00:00'),(635,1,'testTask','renren',0,NULL,1,'2026-01-07 21:30:00'),(636,1,'testTask','renren',0,NULL,0,'2026-01-07 22:00:00'),(637,1,'testTask','renren',0,NULL,1,'2026-01-07 22:30:00'),(638,1,'testTask','renren',0,NULL,1,'2026-01-07 23:00:00'),(639,1,'testTask','renren',0,NULL,2,'2026-01-07 23:30:00'),(640,1,'testTask','renren',0,NULL,3,'2026-01-08 00:00:00'),(641,1,'testTask','renren',0,NULL,1,'2026-01-08 00:30:00'),(642,1,'testTask','renren',0,NULL,0,'2026-01-08 01:00:00'),(643,1,'testTask','renren',0,NULL,1,'2026-01-08 01:30:00'),(644,1,'testTask','renren',0,NULL,1,'2026-01-08 02:00:00'),(645,1,'testTask','renren',0,NULL,1,'2026-01-08 02:30:00'),(646,1,'testTask','renren',0,NULL,0,'2026-01-08 03:00:00'),(647,1,'testTask','renren',0,NULL,0,'2026-01-08 03:30:00'),(648,1,'testTask','renren',0,NULL,0,'2026-01-08 04:00:00'),(649,1,'testTask','renren',0,NULL,1,'2026-01-08 04:30:00'),(650,1,'testTask','renren',0,NULL,2,'2026-01-08 05:00:00'),(651,1,'testTask','renren',0,NULL,0,'2026-01-08 05:30:00'),(652,1,'testTask','renren',0,NULL,0,'2026-01-08 06:00:00'),(653,1,'testTask','renren',0,NULL,0,'2026-01-08 06:30:00'),(654,1,'testTask','renren',0,NULL,2,'2026-01-08 07:00:00'),(655,1,'testTask','renren',0,NULL,1,'2026-01-08 07:30:00'),(656,1,'testTask','renren',0,NULL,1,'2026-01-08 08:00:00'),(657,1,'testTask','renren',0,NULL,1,'2026-01-08 08:30:00'),(658,1,'testTask','renren',0,NULL,0,'2026-01-08 09:00:00'),(659,1,'testTask','renren',0,NULL,0,'2026-01-08 09:30:00'),(660,1,'testTask','renren',0,NULL,0,'2026-01-08 10:00:00'),(661,1,'testTask','renren',0,NULL,0,'2026-01-08 10:30:00'),(662,1,'testTask','renren',0,NULL,1,'2026-01-08 11:00:00'),(663,1,'testTask','renren',0,NULL,1,'2026-01-08 11:30:00'),(664,1,'testTask','renren',0,NULL,1,'2026-01-08 12:00:00'),(665,1,'testTask','renren',0,NULL,1,'2026-01-08 12:30:00'),(666,1,'testTask','renren',0,NULL,1,'2026-01-08 13:00:00'),(667,1,'testTask','renren',0,NULL,2,'2026-01-08 13:30:00'),(668,1,'testTask','renren',0,NULL,0,'2026-01-08 14:00:00'),(669,1,'testTask','renren',0,NULL,0,'2026-01-08 14:30:00'),(670,1,'testTask','renren',0,NULL,1,'2026-01-08 15:00:00'),(671,1,'testTask','renren',0,NULL,0,'2026-01-08 15:30:00'),(672,1,'testTask','renren',0,NULL,0,'2026-01-08 16:00:00'),(673,1,'testTask','renren',0,NULL,0,'2026-01-08 16:30:00'),(674,1,'testTask','renren',0,NULL,0,'2026-01-08 17:00:00'),(675,1,'testTask','renren',0,NULL,0,'2026-01-08 17:30:00'),(676,1,'testTask','renren',0,NULL,0,'2026-01-08 18:00:00'),(677,1,'testTask','renren',0,NULL,1,'2026-01-08 18:30:00'),(678,1,'testTask','renren',0,NULL,0,'2026-01-09 13:30:00'),(679,1,'testTask','renren',0,NULL,0,'2026-01-09 14:00:00'),(680,1,'testTask','renren',0,NULL,1,'2026-01-09 14:30:00'),(681,1,'testTask','renren',0,NULL,0,'2026-01-09 15:00:00'),(682,1,'testTask','renren',0,NULL,1,'2026-01-09 15:30:00'),(683,1,'testTask','renren',0,NULL,0,'2026-01-09 16:00:00'),(684,1,'testTask','renren',0,NULL,0,'2026-01-09 16:30:00'),(685,1,'testTask','renren',0,NULL,0,'2026-01-09 17:00:00'),(686,1,'testTask','renren',0,NULL,1,'2026-01-13 13:30:00'),(687,1,'testTask','renren',0,NULL,0,'2026-01-13 14:00:00'),(688,1,'testTask','renren',0,NULL,1,'2026-01-13 14:30:00'),(689,1,'testTask','renren',0,NULL,0,'2026-01-13 15:00:00'),(690,1,'testTask','renren',0,NULL,0,'2026-01-13 15:30:00'),(691,1,'testTask','renren',0,NULL,0,'2026-01-13 16:00:00'),(692,1,'testTask','renren',0,NULL,0,'2026-01-13 16:30:00'),(693,1,'testTask','renren',0,NULL,1,'2026-01-13 17:00:00'),(694,1,'testTask','renren',0,NULL,1,'2026-01-13 17:30:00'),(695,1,'testTask','renren',0,NULL,0,'2026-01-13 18:00:00'),(696,1,'testTask','renren',0,NULL,0,'2026-01-13 18:30:00'),(697,1,'testTask','renren',0,NULL,1,'2026-01-13 19:00:00'),(698,1,'testTask','renren',0,NULL,1,'2026-01-13 19:30:00'),(699,1,'testTask','renren',0,NULL,1,'2026-01-13 20:00:00'),(700,1,'testTask','renren',0,NULL,1,'2026-01-13 20:30:00'),(701,1,'testTask','renren',0,NULL,1,'2026-01-13 21:00:00'),(702,1,'testTask','renren',0,NULL,0,'2026-01-13 21:30:00'),(703,1,'testTask','renren',0,NULL,0,'2026-01-13 22:00:00'),(704,1,'testTask','renren',0,NULL,1,'2026-01-13 22:30:00'),(705,1,'testTask','renren',0,NULL,0,'2026-01-13 23:00:00'),(706,1,'testTask','renren',0,NULL,0,'2026-01-13 23:30:00'),(707,1,'testTask','renren',0,NULL,5,'2026-01-14 00:00:00'),(708,1,'testTask','renren',0,NULL,0,'2026-01-14 00:30:00'),(709,1,'testTask','renren',0,NULL,0,'2026-01-14 01:00:00'),(710,1,'testTask','renren',0,NULL,1,'2026-01-14 01:30:00'),(711,1,'testTask','renren',0,NULL,0,'2026-01-14 02:00:00'),(712,1,'testTask','renren',0,NULL,0,'2026-01-14 02:30:00'),(713,1,'testTask','renren',0,NULL,1,'2026-01-14 03:00:00'),(714,1,'testTask','renren',0,NULL,0,'2026-01-14 03:30:00'),(715,1,'testTask','renren',0,NULL,0,'2026-01-14 04:00:00'),(716,1,'testTask','renren',0,NULL,0,'2026-01-14 04:30:00'),(717,1,'testTask','renren',0,NULL,1,'2026-01-14 05:00:00'),(718,1,'testTask','renren',0,NULL,1,'2026-01-14 05:30:00'),(719,1,'testTask','renren',0,NULL,1,'2026-01-14 06:00:00'),(720,1,'testTask','renren',0,NULL,1,'2026-01-14 06:30:00'),(721,1,'testTask','renren',0,NULL,0,'2026-01-14 07:00:00'),(722,1,'testTask','renren',0,NULL,1,'2026-01-14 07:30:00'),(723,1,'testTask','renren',0,NULL,1,'2026-01-14 08:00:00'),(724,1,'testTask','renren',0,NULL,0,'2026-01-14 08:30:00'),(725,1,'testTask','renren',0,NULL,0,'2026-01-14 09:00:00'),(726,1,'testTask','renren',0,NULL,0,'2026-01-14 09:30:00'),(727,1,'testTask','renren',0,NULL,0,'2026-01-14 10:00:00'),(728,1,'testTask','renren',0,NULL,1,'2026-01-14 10:30:00'),(729,1,'testTask','renren',0,NULL,0,'2026-01-14 11:00:00'),(730,1,'testTask','renren',0,NULL,1,'2026-01-14 11:30:00'),(731,1,'testTask','renren',0,NULL,1,'2026-01-14 12:00:00'),(732,1,'testTask','renren',0,NULL,0,'2026-01-14 12:30:00'),(733,1,'testTask','renren',0,NULL,0,'2026-01-14 13:00:00'),(734,1,'testTask','renren',0,NULL,0,'2026-01-14 13:30:00'),(735,1,'testTask','renren',0,NULL,1,'2026-01-14 14:00:00'),(736,1,'testTask','renren',0,NULL,0,'2026-01-14 14:30:00'),(737,1,'testTask','renren',0,NULL,0,'2026-01-14 15:00:00'),(738,1,'testTask','renren',0,NULL,0,'2026-01-14 15:30:00');
/*!40000 ALTER TABLE `schedule_job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_captcha`
--

DROP TABLE IF EXISTS `sys_captcha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_captcha` (
  `uuid` char(36) NOT NULL COMMENT 'uuid',
  `code` varchar(6) NOT NULL COMMENT '验证码',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统验证码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_captcha`
--

LOCK TABLES `sys_captcha` WRITE;
/*!40000 ALTER TABLE `sys_captcha` DISABLE KEYS */;
INSERT INTO `sys_captcha` VALUES ('03c0235a-c85b-443e-8c93-e9dbb3ee4502','edndn','2025-12-24 14:01:09'),('0baa9286-8f4b-40d5-83cd-f56cdb2ec101','denfm','2025-12-15 11:38:17'),('10203890-0e61-48b6-8c18-3b843d80d52f','b7wd5','2025-12-24 12:34:17'),('47d7a78b-afd0-472a-8c0b-fc8560ad3be8','ympp2','2026-01-13 13:30:53'),('6e71e255-9131-4fab-8b4e-d6bb9fc1a5ee','7m6yp','2025-12-15 11:26:01'),('7900a7e1-3843-4dd2-8708-770e1a0e7b39','ed5dn','2025-12-05 10:11:32'),('92a8c344-df55-45c6-8571-4f27c73e5656','b8afp','2025-12-16 17:32:19'),('b3681ac6-64ef-4d38-887e-7e69647c6dba','dbp72','2025-12-15 11:25:22'),('cbf38255-f819-4d03-8241-81a6876a2317','wxany','2025-12-16 17:36:07'),('cc66e1fa-d4d0-47d0-8b87-aaeb81c92dc8','3x6xn','2025-12-29 14:37:05'),('d3f678fe-7888-494e-852d-d886380b5ad8','nyn2g','2026-01-09 13:10:38'),('d6e2c1b9-071a-4f52-8a0e-5138a5115628','2pn5d','2025-12-04 16:56:35'),('dae829f4-e9a8-4fba-8d77-f0634b4da3cb','8g4we','2025-12-15 11:39:11');
/*!40000 ALTER TABLE `sys_captcha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `param_key` varchar(50) DEFAULT NULL COMMENT 'key',
  `param_value` varchar(2000) DEFAULT NULL COMMENT 'value',
  `status` tinyint DEFAULT '1' COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param_key` (`param_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统配置信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES (1,'CLOUD_STORAGE_CONFIG_KEY','{\"aliyunAccessKeyId\":\"\",\"aliyunAccessKeySecret\":\"\",\"aliyunBucketName\":\"\",\"aliyunDomain\":\"\",\"aliyunEndPoint\":\"\",\"aliyunPrefix\":\"\",\"qcloudBucketName\":\"\",\"qcloudDomain\":\"\",\"qcloudPrefix\":\"\",\"qcloudSecretId\":\"\",\"qcloudSecretKey\":\"\",\"qiniuAccessKey\":\"NrgMfABZxWLo5B-YYSjoE8-AZ1EISdi1Z3ubLOeZ\",\"qiniuBucketName\":\"ios-app\",\"qiniuDomain\":\"http://7xqbwh.dl1.z0.glb.clouddn.com\",\"qiniuPrefix\":\"upload\",\"qiniuSecretKey\":\"uIwJHevMRWU0VLxFvgy0tAcOdGqasdtVlJkdy6vV\",\"type\":1}',0,'云存储配置信息');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `time` bigint NOT NULL COMMENT '执行时长(毫秒)',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,'admin','保存菜单','io.renren.modules.sys.controller.SysMenuController.save()','[{\"menuId\":31,\"parentId\":0,\"name\":\"商品系统\",\"url\":\"\",\"perms\":\"\",\"type\":0,\"icon\":\"editor\",\"orderNum\":0,\"list\":[]}]',13,'0:0:0:0:0:0:0:1','2025-12-12 15:50:00'),(2,'admin','保存菜单','io.renren.modules.sys.controller.SysMenuController.save()','[{\"menuId\":32,\"parentId\":31,\"name\":\"分类维护\",\"url\":\"product/category\",\"perms\":\"\",\"type\":1,\"icon\":\"menu\",\"orderNum\":0,\"list\":[]}]',12,'0:0:0:0:0:0:0:1','2025-12-12 15:51:02'),(3,'admin','保存菜单','io.renren.modules.sys.controller.SysMenuController.save()','[{\"menuId\":33,\"parentId\":31,\"name\":\"品牌管理\",\"url\":\"product/brand\",\"perms\":\"\",\"type\":1,\"icon\":\"editor\",\"orderNum\":0,\"list\":[]}]',24,'0:0:0:0:0:0:0:1','2025-12-17 15:27:43'),(4,'admin','保存用户','io.renren.modules.sys.controller.SysUserController.save()','[{\"userId\":2,\"username\":\"root\",\"password\":\"58340278d00686d85ecd86416d32111d1970ff8cdb1ccc735268ab5a4fa0602c\",\"salt\":\"SSSRZEvxwUpkwrC0iut5\",\"email\":\"13945879541@qq.com\",\"mobile\":\"13945879541\",\"status\":1,\"roleIdList\":[],\"createUserId\":1,\"createTime\":\"Jan 8, 2026, 4:29:30 PM\"}]',66,'127.0.0.1','2026-01-08 16:29:30');
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单图标',
  `order_num` int DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='菜单管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,0,'系统管理',NULL,NULL,0,'system',0),(2,1,'管理员列表','sys/user',NULL,1,'admin',1),(3,1,'角色管理','sys/role',NULL,1,'role',2),(4,1,'菜单管理','sys/menu',NULL,1,'menu',3),(5,1,'SQL监控','http://localhost:8080/renren-fast/druid/sql.html',NULL,1,'sql',4),(6,1,'定时任务','job/schedule',NULL,1,'job',5),(7,6,'查看',NULL,'sys:schedule:list,sys:schedule:info',2,NULL,0),(8,6,'新增',NULL,'sys:schedule:save',2,NULL,0),(9,6,'修改',NULL,'sys:schedule:update',2,NULL,0),(10,6,'删除',NULL,'sys:schedule:delete',2,NULL,0),(11,6,'暂停',NULL,'sys:schedule:pause',2,NULL,0),(12,6,'恢复',NULL,'sys:schedule:resume',2,NULL,0),(13,6,'立即执行',NULL,'sys:schedule:run',2,NULL,0),(14,6,'日志列表',NULL,'sys:schedule:log',2,NULL,0),(15,2,'查看',NULL,'sys:user:list,sys:user:info',2,NULL,0),(16,2,'新增',NULL,'sys:user:save,sys:role:select',2,NULL,0),(17,2,'修改',NULL,'sys:user:update,sys:role:select',2,NULL,0),(18,2,'删除',NULL,'sys:user:delete',2,NULL,0),(19,3,'查看',NULL,'sys:role:list,sys:role:info',2,NULL,0),(20,3,'新增',NULL,'sys:role:save,sys:menu:list',2,NULL,0),(21,3,'修改',NULL,'sys:role:update,sys:menu:list',2,NULL,0),(22,3,'删除',NULL,'sys:role:delete',2,NULL,0),(23,4,'查看',NULL,'sys:menu:list,sys:menu:info',2,NULL,0),(24,4,'新增',NULL,'sys:menu:save,sys:menu:select',2,NULL,0),(25,4,'修改',NULL,'sys:menu:update,sys:menu:select',2,NULL,0),(26,4,'删除',NULL,'sys:menu:delete',2,NULL,0),(27,1,'参数管理','sys/config','sys:config:list,sys:config:info,sys:config:save,sys:config:update,sys:config:delete',1,'config',6),(29,1,'系统日志','sys/log','sys:log:list',1,'log',7),(30,1,'文件上传','oss/oss','sys:oss:all',1,'oss',6),(31,0,'商品系统','','',0,'editor',0),(32,31,'分类维护','product/category','',1,'menu',0),(33,31,'品牌管理','product/brand','',1,'editor',0),(37,31,'平台属性','','',0,'system',0),(38,37,'属性分组','product/attrgroup','',1,'tubiao',0),(39,37,'规格参数','product/baseattr','',1,'log',0),(40,37,'销售属性','product/saleattr','',1,'zonghe',0),(41,31,'商品维护','product/spu','',0,'zonghe',0),(42,0,'优惠营销','','',0,'mudedi',0),(43,0,'库存系统','','',0,'shouye',0),(44,0,'订单系统','','',0,'config',0),(45,0,'用户系统','','',0,'admin',0),(46,0,'内容管理','','',0,'sousuo',0),(47,42,'优惠券管理','coupon/coupon','',1,'zhedie',0),(48,42,'发放记录','coupon/history','',1,'sql',0),(49,42,'专题活动','coupon/subject','',1,'tixing',0),(50,42,'秒杀活动','coupon/seckill','',1,'daohang',0),(51,42,'积分维护','coupon/bounds','',1,'geren',0),(52,42,'满减折扣','coupon/full','',1,'shoucang',0),(53,43,'仓库维护','ware/wareinfo','',1,'shouye',0),(54,43,'库存工作单','ware/task','',1,'log',0),(55,43,'商品库存','ware/sku','',1,'jiesuo',0),(56,44,'订单查询','order/order','',1,'zhedie',0),(57,44,'退货单处理','order/return','',1,'shanchu',0),(58,44,'等级规则','order/settings','',1,'system',0),(59,44,'支付流水查询','order/payment','',1,'job',0),(60,44,'退款流水查询','order/refund','',1,'mudedi',0),(61,45,'会员列表','member/member','',1,'geren',0),(62,45,'会员等级','member/level','',1,'tubiao',0),(63,45,'积分变化','member/growth','',1,'bianji',0),(64,45,'统计信息','member/statistics','',1,'sql',0),(65,46,'首页推荐','content/index','',1,'shouye',0),(66,46,'分类热门','content/category','',1,'zhedie',0),(67,46,'评论管理','content/comments','',1,'pinglun',0),(68,41,'spu管理','product/spu','',1,'config',0),(69,41,'发布商品','product/spuadd','',1,'bianji',0),(70,43,'采购单维护','','',0,'tubiao',0),(71,70,'采购需求','ware/purchaseitem','',1,'editor',0),(72,70,'采购单','ware/purchase','',1,'menu',0),(73,41,'商品管理','product/manager','',1,'zonghe',0),(74,42,'会员价格','coupon/memberprice','',1,'admin',0),(75,42,'每日秒杀','coupon/seckillsession','',1,'job',0),(76,37,'规格维护','product/attrupdate','',2,'log',0);
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_oss`
--

DROP TABLE IF EXISTS `sys_oss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_oss` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='文件上传';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_oss`
--

LOCK TABLES `sys_oss` WRITE;
/*!40000 ALTER TABLE `sys_oss` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_oss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `role_id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_user_id` bigint DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` bigint DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色与菜单对应关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_menu`
--

LOCK TABLES `sys_role_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) DEFAULT NULL COMMENT '密码',
  `salt` varchar(20) DEFAULT NULL COMMENT '盐',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) DEFAULT NULL COMMENT '手机号',
  `status` tinyint DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_user_id` bigint DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','9ec9750e709431dad22365cabc5c625482e574c74adaebba7dd02f1129e4ce1d','YzcmCZNvbXocrsz9dm8e','root@renren.io','13612345678',1,1,'2016-11-11 11:11:11'),(2,'root','58340278d00686d85ecd86416d32111d1970ff8cdb1ccc735268ab5a4fa0602c','SSSRZEvxwUpkwrC0iut5','13945879541@qq.com','13945879541',1,1,'2026-01-08 16:29:30');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户与角色对应关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_token`
--

DROP TABLE IF EXISTS `sys_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_token` (
  `user_id` bigint NOT NULL,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统用户Token';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_token`
--

LOCK TABLES `sys_user_token` WRITE;
/*!40000 ALTER TABLE `sys_user_token` DISABLE KEYS */;
INSERT INTO `sys_user_token` VALUES (1,'927e281aeb08507475f53bde79dba716','2026-01-10 01:05:44','2026-01-09 13:05:44');
/*!40000 ALTER TABLE `sys_user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `mobile` varchar(20) NOT NULL COMMENT '手机号',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user`
--

LOCK TABLES `tb_user` WRITE;
/*!40000 ALTER TABLE `tb_user` DISABLE KEYS */;
INSERT INTO `tb_user` VALUES (1,'mark','13612345678','8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918','2017-03-23 22:37:41');
/*!40000 ALTER TABLE `tb_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `nacos`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nacos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `nacos`;

--
-- Table structure for table `config_info`
--

DROP TABLE IF EXISTS `config_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  `app_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  `c_desc` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `c_use` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `effect` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `type` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `c_schema` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfo_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info`
--

LOCK TABLES `config_info` WRITE;
/*!40000 ALTER TABLE `config_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_aggr`
--

DROP TABLE IF EXISTS `config_info_aggr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_aggr` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `datum_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'datum_id',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT '内容',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `app_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfoaggr_datagrouptenantdatum` (`data_id`,`group_id`,`tenant_id`,`datum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='增加租户字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_aggr`
--

LOCK TABLES `config_info_aggr` WRITE;
/*!40000 ALTER TABLE `config_info_aggr` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_aggr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_beta`
--

DROP TABLE IF EXISTS `config_info_beta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_beta` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `app_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `beta_ips` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'betaIps',
  `md5` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfobeta_datagrouptenant` (`data_id`,`group_id`,`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info_beta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_beta`
--

LOCK TABLES `config_info_beta` WRITE;
/*!40000 ALTER TABLE `config_info_beta` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_beta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_info_tag`
--

DROP TABLE IF EXISTS `config_info_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_info_tag` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `tag_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'tag_id',
  `app_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'source ip',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_configinfotag_datagrouptenanttag` (`data_id`,`group_id`,`tenant_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_info_tag';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_info_tag`
--

LOCK TABLES `config_info_tag` WRITE;
/*!40000 ALTER TABLE `config_info_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_info_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_tags_relation`
--

DROP TABLE IF EXISTS `config_tags_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_tags_relation` (
  `id` bigint NOT NULL COMMENT 'id',
  `tag_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'tag_name',
  `tag_type` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'tag_type',
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `nid` bigint NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nid`),
  UNIQUE KEY `uk_configtagrelation_configidtag` (`id`,`tag_name`,`tag_type`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='config_tag_relation';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_tags_relation`
--

LOCK TABLES `config_tags_relation` WRITE;
/*!40000 ALTER TABLE `config_tags_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_tags_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_capacity`
--

DROP TABLE IF EXISTS `group_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_capacity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '' COMMENT 'Group ID，空字符表示整个集群',
  `quota` int unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数，，0表示使用默认值',
  `max_aggr_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='集群、各Group容量信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_capacity`
--

LOCK TABLES `group_capacity` WRITE;
/*!40000 ALTER TABLE `group_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `his_config_info`
--

DROP TABLE IF EXISTS `his_config_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `his_config_info` (
  `id` bigint unsigned NOT NULL,
  `nid` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `group_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `app_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `md5` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `src_user` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin,
  `src_ip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `op_type` char(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`nid`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_gmt_modified` (`gmt_modified`),
  KEY `idx_did` (`data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='多租户改造';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `his_config_info`
--

LOCK TABLES `his_config_info` WRITE;
/*!40000 ALTER TABLE `his_config_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `his_config_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `role` varchar(50) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `action` varchar(8) NOT NULL,
  UNIQUE KEY `uk_role_permission` (`role`,`resource`,`action`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  UNIQUE KEY `idx_user_role` (`username`,`role`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('nacos','ROLE_ADMIN');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_capacity`
--

DROP TABLE IF EXISTS `tenant_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_capacity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '' COMMENT 'Tenant ID',
  `quota` int unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数',
  `max_aggr_size` int unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='租户容量信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_capacity`
--

LOCK TABLES `tenant_capacity` WRITE;
/*!40000 ALTER TABLE `tenant_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_info`
--

DROP TABLE IF EXISTS `tenant_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_info_kptenantid` (`kp`,`tenant_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='tenant_info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_info`
--

LOCK TABLES `tenant_info` WRITE;
/*!40000 ALTER TABLE `tenant_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('nacos','$2a$10$EuWPZHzz32dJN7jexM34MOeYirDdFAZm2kuWj7VEOJhhZkDrxfvUu',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-14 15:49:14
